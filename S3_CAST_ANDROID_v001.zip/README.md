# S3 CAST // DEX BRIDGE v001

A purpose-built phone-to-Waveshare casting bridge for the **ESP32-S3-Touch-LCD-7B (1024×600)**.

## What v001 does

- The 7B creates its own Wi-Fi access point: **S3-CAST**
- Password: **S3CAST77**
- Android captures the screen through the official MediaProjection API.
- The phone renders to **512×300 RGB565 at 5 FPS**.
- The S3 expands it exactly **2×** into its native **1024×600** framebuffer.
- GT911 touch events travel back to the phone over UDP.
- Optional Android Accessibility service converts 7B taps/drags into phone gestures.

This is intentionally a low-dependency first version. There is no MJPEG/H.264 decoder and no LVGL dependency in the receiver path.

## Hardware target

Waveshare ESP32-S3-Touch-LCD-7B:

- ESP32-S3-WROOM-1-N16R8
- 16 MB flash
- 8 MB OPI PSRAM
- 1024×600 RGB565 panel
- GT911 capacitive touch
- 2.4 GHz Wi-Fi

## Flash the receiver

Arduino IDE settings:

- Board: **ESP32S3 Dev Module**
- ESP32 core: **3.3.x** (workflow pins 3.3.0)
- PSRAM: **OPI PSRAM**
- Flash size: **16 MB**
- Partition: **Huge APP**
- USB CDC on boot: **Enabled**

Open:

`firmware/S3_CAST_RECEIVER_v001/S3_CAST_RECEIVER_v001.ino`

Compile and flash it. The display should show a dark waiting frame with mint/blue trim. Serial at 115200 will report the SoftAP IP and caster connection.

## Phone setup

1. Install the S3 CAST APK.
2. Flash the receiver and power the 7B.
3. In the app tap **OPEN WI-FI // JOIN S3-CAST**.
4. Join `S3-CAST` using password `S3CAST77`.
5. If Android warns the network has no internet, choose to stay connected.
6. Optional: tap **ENABLE 7B TOUCH CONTROL** and enable S3 CAST in Accessibility.
7. Return to S3 CAST and tap **START CAST**.
8. Approve Android's screen-capture prompt.
9. Rotate the phone landscape for the closest desktop/DeX-style presentation.

The receiver is at `192.168.4.1:7070`. Touch-back uses UDP port `7071` on the phone.

## Build the APK from a phone with GitHub Actions

The bundle includes `.github/workflows/build.yml`. Put the unzipped project in a GitHub repository and run **Actions → Build S3 CAST → Run workflow**. It builds both:

- `S3_CAST_APK_v001` containing `app-debug.apk`
- `S3_CAST_FIRMWARE_v001` containing the compiled ESP32 binaries

No Android Studio is required on the phone for that route.

## What this is, and what it is not

This creates a **DeX-like remote display**, but it does not electrically identify itself as a Samsung DeX DisplayPort/HDMI monitor. Samsung DeX itself normally expects a real external display path. S3 CAST instead mirrors Android's screen into the ESP32 framebuffer.

Android may blank DRM-protected or FLAG_SECURE content during MediaProjection. That is expected platform behavior.

## Performance target

v001 uses about 307,200 bytes per video frame. At five frames per second the raw video stream is around 1.54 MB/s before TCP overhead. This is intentionally aimed at UI, maps, dashboards, terminals and desktop navigation rather than high-frame-rate video.

## Touch notes

The touch bridge is deliberately conservative:

- tap = immediate Android tap after release
- drag = Android swipe generated on release
- multitouch/pinch is not implemented yet

The Accessibility service is configured only to perform gestures. It does not request window-content retrieval.

## Next engineering passes

Good candidates for v002 are tile-delta compression, live drag continuation, adaptive frame rate, phone-side scaling modes (FIT/FILL), and a proper S3 CAST connection/status overlay.
