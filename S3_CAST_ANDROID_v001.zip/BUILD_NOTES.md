# Build notes

This execution environment does not contain Android SDK/Gradle or Arduino CLI, so the binaries were not locally compiled here. The included GitHub Actions workflow is the reproducible build path for both outputs.

Android project characteristics:
- Java, no AndroidX dependency
- compile/target SDK 35
- min SDK 29
- foreground service type: mediaProjection
- Android 14/15-compatible projection permission flow

Receiver characteristics:
- self-contained Arduino sketch
- no external Arduino libraries beyond the ESP32 core
- uses ESP-IDF RGB LCD driver exposed by Arduino-ESP32
- uses the Waveshare 7B documented 30 MHz RGB timing and GPIO map
