from pathlib import Path
import sys
root=Path(__file__).resolve().parents[1]
app=root/'app'/'build.gradle.kts'
manifest=root/'app'/'src'/'main'/'AndroidManifest.xml'
errors=[]
if not app.exists(): errors.append('app/build.gradle.kts missing')
else:
    s=app.read_text()
    for needle in ['namespace = "hevel.truckfit.loader"','applicationId = "hevel.truckfit.loader"','compileSdk = 36','targetSdk = 36','minSdk = 26','versionCode = 230025']:
        if needle not in s: errors.append(f'missing {needle}')
    if 'signingConfig = signingConfigs.getByName("debug")' in s: errors.append('release falls back to debug signing key')
if not manifest.exists(): errors.append('AndroidManifest.xml missing')
else:
    s=manifest.read_text()
    if 'android:label="TruckFit"' not in s and '@string/app_name' not in s: errors.append('TruckFit app label missing')
for bad in list(root.rglob('*.jks'))+list(root.rglob('*.keystore')):
    errors.append(f'committed key material present: {bad}')
if errors:
    print('FAIL')
    for e in errors: print('-',e)
    sys.exit(1)
print('PASS build identity')
