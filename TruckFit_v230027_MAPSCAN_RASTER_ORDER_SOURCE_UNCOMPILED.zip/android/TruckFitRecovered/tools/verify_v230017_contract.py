from pathlib import Path
root=Path(__file__).resolve().parents[1]
def read(rel): return (root/rel).read_text()
main=read('app/src/main/java/hevel/truckfit/loader/MainActivity.kt')
organizer=read('app/src/main/java/hevel/truckfit/loader/skin/SkinOrganizerActivity.kt')
editor=read('app/src/main/java/hevel/truckfit/loader/skin/SkinEditorActivity.kt')
repo=read('app/src/main/java/hevel/truckfit/loader/skin/SkinRepository.kt')
normalizer=read('app/src/main/java/hevel/truckfit/loader/skin/VehicleImageNormalizer.kt')
chrome=read('app/src/main/java/hevel/truckfit/loader/TruckFitChrome.kt')
header=read('app/src/main/java/hevel/truckfit/loader/radarfield/RadarFieldHeader.kt')
lib=read('app/src/main/java/hevel/truckfit/loader/radarfield/RadarFieldLibraryActivity.kt')
client=read('app/src/main/java/hevel/truckfit/loader/radarfield/RadarFieldPreviewClient.kt')
assert 'action("ADD VEHICLE")' in main and 'createVehicleDialog' in main
assert 'fun createVehicle' in repo and 'RecoveredSkinPack.empty' in repo
assert '+  ADD VEHICLE' in organizer and 'setOnDragListener' in organizer
assert 'slotWidth' in organizer and 'repo.reorderPack(draggedId, chunk[slot].id)' in organizer
assert 'VehicleImageNormalizer.normalize' in editor and 'image/*' in editor
assert 'removeConnectedBackground' in normalizer and 'Bitmap.CompressFormat.PNG' in normalizer
assert ('alreadyTransparent' in normalizer or 'opaqueEdgeRatio' in normalizer)
assert 'Gravity.CENTER' in lib and 'MAPSCAN/MAIN' in lib
assert 'flashCyan' in chrome and '0xFF00E5FF' in chrome
assert 'TruckFitChrome.flashCyan(this)' in main and (header.count('TruckFitChrome.flashCyan(this)') >= 2 or 'setBackgroundColor(Color.TRANSPARENT)' in header)
assert 'action("SCAN / COMPARE")' not in main and 'action("SCAN / COMPARE BY LOCATION")' not in lib
assert 'action("Import")' in lib
assert ('mapbox.satellite/${tile.zoom}/${tile.x}/${tile.y}@2x.jpg90' in client or '/styles/v1/mapbox/satellite-v9/tiles/256/' in client)
assert 'val tileScale = 2' in client and 'JPEG, 98' in client
print('PASS v230017 vehicle creation + full-grid DnD + permissive image cleanup + cyan pulse + Mapbox HiDPI contract')
