from pathlib import Path
import sys
root=Path(__file__).resolve().parents[1]
build=(root/'app'/'build.gradle.kts').read_text() if (root/'app'/'build.gradle.kts').exists() else ''
readme=(root/'README_RECOVERY_AND_SIGNING.md').read_text() if (root/'README_RECOVERY_AND_SIGNING.md').exists() else ''
errors=[]
for needle in ['applicationId = "hevel.truckfit.loader"','TRUCKFIT_KEYSTORE_PATH','TRUCKFIT_KEYSTORE_PASSWORD','TRUCKFIT_KEY_ALIAS','TRUCKFIT_KEY_PASSWORD','requestedRelease','GradleException']:
    if needle not in build: errors.append(f'missing build contract: {needle}')
for phrase in ['two user-controlled copies','same applicationId','same signing key','increment versionCode','never commit']:
    if phrase.lower() not in readme.lower(): errors.append(f'missing README guidance: {phrase}')
for bad in list(root.rglob('*.jks'))+list(root.rglob('*.keystore')): errors.append(f'key material must remain untracked: {bad}')
if errors:
    print('FAIL'); [print('-',e) for e in errors]; sys.exit(1)
print('PASS release contract source audit')
