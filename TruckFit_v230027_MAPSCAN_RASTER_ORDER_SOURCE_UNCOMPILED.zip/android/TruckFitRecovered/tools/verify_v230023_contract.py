from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def read(p): return (ROOT/p).read_text()
gradle=read('app/build.gradle.kts')
api=read('app/src/main/java/hevel/truckfit/loader/hevel/HevelApiClient.kt')
sync=read('app/src/main/java/hevel/truckfit/loader/transfer/RadarMapSyncManager.kt')
lib=read('app/src/main/java/hevel/truckfit/loader/radarfield/RadarFieldLibraryActivity.kt')
repo=read('app/src/main/java/hevel/truckfit/loader/radarfield/RadarFieldRepository.kt')
geom=read('app/src/main/java/hevel/truckfit/loader/radarfield/RadarFieldGeometry.kt')
crop=read('app/src/main/java/hevel/truckfit/loader/radarfield/RadarFieldCropView.kt')
assert (('versionCode = 230023' in gradle and '23.0.23-map-sync-default-rounded-prox' in gradle) or ('versionCode = 230024' in gradle and '23.0.24-s3-map-render-menu' in gradle) or ('versionCode = 230025' in gradle and '23.0.25-auto-trim-center' in gradle))
assert 'ConnectionPool(0,1,TimeUnit.MILLISECONDS)' in api and 'header("Connection","close")' in api
assert 'mapStage(id:String)' in api and '/api/maps/stage?map=' in api
assert 'uploadImageVerified' in sync and 'stagedAssetMatches' in sync
assert 'proximityCornerRadiusFt' in sync
assert 'fun useDefault()' in repo and 'activateDefault()' in lib and 'DEACTIVATE' in lib
assert 'const val proximityCornerRadiusFt: Double = sensorRangeFt' in geom
assert 'canvas.drawRoundRect(guide, cornerRadiusPx, cornerRadiusPx, guidePaint)' in crop
assert '68 × 48 FT PROX • R20 FT' in crop
print('PASS v230023 map sync + DEFAULT deactivation + rounded proximity contract')
