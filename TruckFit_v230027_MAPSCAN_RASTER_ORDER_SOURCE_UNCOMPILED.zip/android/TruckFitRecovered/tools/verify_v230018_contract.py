from pathlib import Path
root = Path(__file__).resolve().parents[1]
def read(rel): return (root / rel).read_text()

main = read("app/src/main/java/hevel/truckfit/loader/MainActivity.kt")
chrome = read("app/src/main/java/hevel/truckfit/loader/TruckFitChrome.kt")
org = read("app/src/main/java/hevel/truckfit/loader/skin/SkinOrganizerActivity.kt")
rad = read("app/src/main/java/hevel/truckfit/loader/radarfield/RadarFieldLibraryActivity.kt")
head = read("app/src/main/java/hevel/truckfit/loader/radarfield/RadarFieldHeader.kt")
scan = read("app/src/main/java/hevel/truckfit/loader/radarfield/RadarFieldScanActivity.kt")
keys = read("app/src/main/java/hevel/truckfit/loader/radarfield/ProviderSetupActivity.kt")
hot = read("app/src/main/java/hevel/truckfit/loader/HotspotConnector.kt")
manifest = read("app/src/main/AndroidManifest.xml")
ident = read("app/build.gradle.kts")

assert (("versionCode = 230021" in ident and "23.0.21-link-satellite-calibration" in ident) or ("versionCode = 230022" in ident and "23.0.22-map-catalog-fitment" in ident)) or ("versionCode = 230023" in ident and "23.0.23-map-sync-default-rounded-prox" in ident) or ("versionCode = 230024" in ident and "23.0.24-s3-map-render-menu" in ident) or ("versionCode = 230025" in ident and "23.0.25-auto-trim-center" in ident)
assert "BLUE = 0xFF2F6D8FL" in chrome and "BLUE_DARK = 0xFF2F6D8FL" in chrome
assert "PANEL = 0xFFF0F4F7L" in chrome
assert 'action("NEW FOLDER")' in main and 'action("Hotspot")' in main
assert ('action("Satallite")' in main or 'action("MapScan")' in main) and 'action("Complete")' in main
assert "Switch to MapScan" in main and "garage_organize_backdrop" in org
assert "Switch to Garage" in head and "flashCyan" in head
assert 'action("GPS KEYS")' in rad and 'action("GARAGE")' in rad
assert 'action("Hotspot")' in rad and 'action("Complete")' in rad
assert "mapscan_scan_backdrop" in scan and 'text = "GPS KEYS"' in scan
assert 'RadarFieldHeader.create(this, "GPS Keys")' in keys
assert "WifiNetworkSpecifier.Builder()" in hot and ("HEVEL_SKIN_LOADER" in hot or "HevelFitment" in hot)
assert "NEARBY_WIFI_DEVICES" in manifest and "CHANGE_WIFI_STATE" in manifest
assert (root / "app/src/main/res/values-v31/themes.xml").exists()
assert (root / "app/src/main/res/drawable-nodpi/truckfit_launcher_art.png").exists()
assert (root / "app/src/main/res/drawable-nodpi/mapscan_scan_backdrop.jpg").exists()
assert (root / "app/src/main/res/drawable-nodpi/garage_organize_backdrop.jpg").exists()
print("PASS v230018 Garage/MapScan polish contract")
