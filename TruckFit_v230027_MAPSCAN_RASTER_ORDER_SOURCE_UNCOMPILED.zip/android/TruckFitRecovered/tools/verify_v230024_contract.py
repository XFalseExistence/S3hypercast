from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def read(p): return (ROOT/p).read_text()
gradle=read('app/build.gradle.kts')
api=read('app/src/main/java/hevel/truckfit/loader/hevel/HevelApiClient.kt')
sync=read('app/src/main/java/hevel/truckfit/loader/transfer/RadarMapSyncManager.kt')
lib=read('app/src/main/java/hevel/truckfit/loader/radarfield/RadarFieldLibraryActivity.kt')
assert ('versionCode = 230024' in gradle and '23.0.24-s3-map-render-menu' in gradle) or ('versionCode = 230025' in gradle and '23.0.25-auto-trim-center' in gradle)
assert 'mapRasterStatus(id:String)' in api and '/api/maps/raster?map=' in api
assert 'uploadMapRaster(id:String,bytes:ByteArray)' in api
for token in ['rasterBytes','rasterSha256','rasterCrc32','RGB565LE','uploadRasterVerified','rasterStatusMatches']:
    assert token in sync, token
assert 'TAP TO ACTIVATE' in lib and 'if(field.active) openCalibration(field) else activateField(field)' in lib
assert 'RadarMapSyncManager(this@RadarFieldLibraryActivity).syncOne(field.id, activate = true)' in lib
print('PASS v230024 S3 map render transfer + explicit activation contract')
