from pathlib import Path
root=Path(__file__).resolve().parents[1]
def read(rel): return (root/rel).read_text()
hot=read('app/src/main/java/hevel/truckfit/loader/HotspotConnector.kt')
main=read('app/src/main/java/hevel/truckfit/loader/MainActivity.kt')
sync=read('app/src/main/java/hevel/truckfit/loader/transfer/S3SyncManager.kt')
ident=read('app/build.gradle.kts')
assert (('versionCode = 230021' in ident and '23.0.21-link-satellite-calibration' in ident) or ('versionCode = 230022' in ident and '23.0.22-map-catalog-fitment' in ident)) or ("versionCode = 230023" in ident and "23.0.23-map-sync-default-rounded-prox" in ident) or ("versionCode = 230024" in ident and "23.0.24-s3-map-render-menu" in ident) or ("versionCode = 230025" in ident and "23.0.25-auto-trim-center" in ident)
assert (('DEFAULT_SSID = "HEVEL_SKIN_LOADER"' in hot and 'DEFAULT_PASSWORD = "hevelskins"' in hot) or ('DEFAULT_SSID = "HevelFitment"' in hot and 'DEFAULT_PASSWORD = "hevel369!"' in hot))
assert 'PERMISSION_REQUEST = 714' in hot and 'onPermissionResult' in hot and 'bindProcessToNetwork' in hot
assert 'action("Sync")' in main and 'UNLINK' in main and 'LINK' in main and 'DELETE? TAP AGAIN TO CONFIRM' in main
assert 'fetchRemoteManifest' in sync and 'api.skinManifest(packId)' in sync and 'RemoteManifestSnapshot(emptyMap())' in sync
assert 'transfer.uploadSkin(pack, remote)' in sync
print('PASS v230020 HEVEL hotspot + incremental S3 sync contract')
