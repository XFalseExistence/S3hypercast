from pathlib import Path
root=Path(__file__).resolve().parents[1]
def read(rel): return (root/rel).read_text()
main=read('app/src/main/java/hevel/truckfit/loader/MainActivity.kt')
model=read('app/src/main/java/hevel/truckfit/loader/skin/SkinModels.kt')
repo=read('app/src/main/java/hevel/truckfit/loader/skin/SkinRepository.kt')
sync=read('app/src/main/java/hevel/truckfit/loader/transfer/S3SyncManager.kt')
rad=read('app/src/main/java/hevel/truckfit/loader/radarfield/RadarFieldLibraryActivity.kt')
rmodel=read('app/src/main/java/hevel/truckfit/loader/radarfield/RadarFieldModels.kt')
rrepo=read('app/src/main/java/hevel/truckfit/loader/radarfield/RadarFieldRepository.kt')
geom=read('app/src/main/java/hevel/truckfit/loader/radarfield/RadarFieldGeometry.kt')
ident=read('app/build.gradle.kts')
assert (('versionCode = 230021' in ident and '23.0.21-link-satellite-calibration' in ident) or ('versionCode = 230022' in ident and '23.0.22-map-catalog-fitment' in ident)) or ("versionCode = 230023" in ident and "23.0.23-map-sync-default-rounded-prox" in ident) or ("versionCode = 230024" in ident and "23.0.24-s3-map-render-menu" in ident) or ("versionCode = 230025" in ident and "23.0.25-auto-trim-center" in ident)
assert 'linkedToS3: Boolean = true' in model and 'setLinkedToS3' in repo
assert 'filter { it.linkedToS3 }' in sync and 'filterNot { it.linkedToS3 }' in sync and 'pruneOne' in sync
assert 'action(if (pack.linkedToS3) "UNLINK" else "LINK")' in main
assert 'setBackgroundColor(Color.BLACK)' in main and 'setTextColor(Color.WHITE)' in main
assert 'listOf(2, 4, 8)' in main and 'setSingleLine(true)' in main and 'setAutoSizeTextTypeUniformWithConfiguration' in main
for label in ['action("Import")','action("Export")','action("Hotspot")','action("Sync")','action("Complete")']:
    assert label in main
assert ('action("Satallite")' in rad or 'action("Satellite")' in rad) and 'action("Import")' in rad
assert 'onEyeClick = { cycleGrid() }' in rad and 'setOf(2,4,8)' in rad
assert 'active: Boolean = false' in rmodel and 'mapProximityEnabled: Boolean = true' in rmodel and 'calibrationRevision' in rmodel
assert 'setActive' in rrepo and 'setMapProximity' in rrepo
assert 'masterWidthFt = field.masterWidthFt' in rrepo and 'northDeg = 0.0' not in rrepo
assert 'sensorEnvelopeLengthFt: Double = 68.0' in geom and 'sensorEnvelopeWidthFt: Double = 48.0' in geom
assert 'exitLoader()' in main and 'HotspotConnector.release' in main
assert 'openAbove' in main and 'popupHeight' in main
print('PASS v230021 link + satellite + calibration contract')
