from pathlib import Path
root = Path(__file__).resolve().parents[1]
gradle = (root/'app/build.gradle.kts').read_text()
normalizer = (root/'app/src/main/java/hevel/truckfit/loader/skin/VehicleImageNormalizer.kt').read_text()
migration = (root/'app/src/main/java/hevel/truckfit/loader/skin/VehicleImageMigration.kt').read_text()
organizer = (root/'app/src/main/java/hevel/truckfit/loader/skin/SkinOrganizerActivity.kt').read_text()
main = (root/'app/src/main/java/hevel/truckfit/loader/MainActivity.kt').read_text()
editor = (root/'app/src/main/java/hevel/truckfit/loader/skin/SkinEditorActivity.kt').read_text()
assert 'versionCode = 230025' in gradle and '23.0.25-auto-trim-center' in gradle
for token in ['opaqueEdgeRatio', 'removeConnectedBackground', 'trimAndCenter', '0.045f', 'Color.alpha(pixels[row + x]) >= 4']:
    assert token in normalizer, token
for token in ['trim_center_v230025_done', 'sourceSha = null', 'renderSha = null', 'VehicleImageNormalizer.normalize']:
    assert token in migration, token
assert 'ScaleType.CENTER_CROP' not in organizer and 'ScaleType.FIT_CENTER' in organizer
assert 'ScaleType.CENTER_CROP' not in main and 'ScaleType.FIT_CENTER' in main
assert 'VehicleImageMigration.start(this, repo)' in organizer
assert 'VehicleImageMigration.start(this, repo)' in main
assert 'sourceSha = null' in editor and 'renderSha = null' in editor
print('PASS v230025 auto-trim/center contract')
