from pathlib import Path
root = Path(__file__).resolve().parents[1]
def read(rel): return (root / rel).read_text()
scan = read('app/src/main/java/hevel/truckfit/loader/radarfield/RadarFieldScanActivity.kt')
client = read('app/src/main/java/hevel/truckfit/loader/radarfield/RadarFieldPreviewClient.kt')
req = read('app/src/main/java/hevel/truckfit/loader/radarfield/RadarProviderRequests.kt')
lib = read('app/src/main/java/hevel/truckfit/loader/radarfield/RadarFieldLibraryActivity.kt')
repo = read('app/src/main/java/hevel/truckfit/loader/radarfield/RadarFieldRepository.kt')
assert 'BROWSE_FOOTPRINT_FT = 480.0' in client
assert 'fetchBrowse(' in client and 'provider: RadarProviderId' in client
assert 'openProviderBrowse(provider' in scan
assert 'cacheBrowsePreview(provider' in scan
assert 'footprintFt: Double = RadarFieldGeometry.masterWidthFt' in req
assert 'googleZoomAndSize(center.lat, footprintFt)' in req
assert '"DELETE"' in lib and 'deleteField(field)' in lib
assert 'fun delete(id: String): Boolean' in repo
print('PASS v230011 wide provider browse + delete contract')
