from pathlib import Path
root = Path(__file__).resolve().parents[1]
def read(rel): return (root / rel).read_text()
chrome = read('app/src/main/java/hevel/truckfit/loader/TruckFitChrome.kt')
main = read('app/src/main/java/hevel/truckfit/loader/MainActivity.kt')
editor = read('app/src/main/java/hevel/truckfit/loader/skin/SkinEditorActivity.kt')
header = read('app/src/main/java/hevel/truckfit/loader/radarfield/RadarFieldHeader.kt')
scan = read('app/src/main/java/hevel/truckfit/loader/radarfield/RadarFieldScanActivity.kt')
req = read('app/src/main/java/hevel/truckfit/loader/radarfield/RadarProviderRequests.kt')
client = read('app/src/main/java/hevel/truckfit/loader/radarfield/RadarFieldPreviewClient.kt')
tiles = read('app/src/main/java/hevel/truckfit/loader/radarfield/EsriTileWindow.kt')
crop = read('app/src/main/java/hevel/truckfit/loader/radarfield/RadarFieldCropActivity.kt')
library = read('app/src/main/java/hevel/truckfit/loader/radarfield/RadarFieldLibraryActivity.kt')
crop_view = read('app/src/main/java/hevel/truckfit/loader/radarfield/RadarFieldCropView.kt')
session = read('app/src/main/java/hevel/truckfit/loader/radarfield/RadarPreviewSession.kt')

assert 'FIT_CENTER' in editor and 'CENTER_CROP' not in editor
assert 'styleLibraryScreen' in main and '0xFF2B2D31' in chrome
assert 'if (currentFolderId != null) goUp()' in main
assert 'radar_field_header_icon' in header
assert ('RadarFieldHeader.create(this, "Satallite")' in scan or 'RadarFieldHeader.create(this, "Satellite")' in scan)
assert 'GPS Keys' in scan and 'LOAD PREVIEWS' in scan
assert 'EsriTileWindow.tileTemplate' in req
assert '/export' not in req
assert 'World_Imagery/MapServer/tile/{z}/{y}/{x}' in tiles
assert 'fetchEsriTiles' in client and 'Canvas(mosaic)' in client and 'createScaledBitmap' in client
assert 'previewZoom = 21' in tiles and 'tileCount' in tiles
print('PASS v230007 UI/provider contract')

assert '.putExtra("image_uri", Uri.fromFile(file).toString())' in scan
assert 'getStringExtra("image_uri")' in crop and 'decodeScaled(uri' in crop
assert 'CROP & SAVE AS' in crop and 'repo.save(saved)' in crop
assert 'restorePreviewSession()' in scan and 'previewSession.edit()' in scan
assert 'object : Dns' in client and 'builder.dns(Dns {' not in client
assert 'field_id' in library and 'RadarFieldCropActivity' in library
assert 'renderCrop' in crop_view and 'cropView.renderCrop' in crop
assert 'object RadarPreviewSession' in session
print('PASS v230007 crop/session/save compatibility contract')
