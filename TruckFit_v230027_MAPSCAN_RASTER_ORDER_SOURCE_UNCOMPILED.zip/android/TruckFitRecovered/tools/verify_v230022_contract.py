from pathlib import Path
root=Path(__file__).resolve().parents[1]
def read(rel): return (root/rel).read_text()
ident=read('app/build.gradle.kts')
hot=read('app/src/main/java/hevel/truckfit/loader/HotspotConnector.kt')
main=read('app/src/main/java/hevel/truckfit/loader/MainActivity.kt')
rad=read('app/src/main/java/hevel/truckfit/loader/radarfield/RadarFieldLibraryActivity.kt')
scan=read('app/src/main/java/hevel/truckfit/loader/radarfield/RadarFieldScanActivity.kt')
header=read('app/src/main/java/hevel/truckfit/loader/radarfield/RadarFieldHeader.kt')
preview=read('app/src/main/java/hevel/truckfit/loader/radarfield/RadarFieldPreviewClient.kt')
api=read('app/src/main/java/hevel/truckfit/loader/hevel/HevelApiClient.kt')
sync=read('app/src/main/java/hevel/truckfit/loader/transfer/RadarMapSyncManager.kt')
geom=read('app/src/main/java/hevel/truckfit/loader/radarfield/RadarFieldGeometry.kt')
assert (('versionCode = 230022' in ident and '23.0.22-map-catalog-fitment' in ident) or ('versionCode = 230023' in ident and '23.0.23-map-sync-default-rounded-prox' in ident)) or ("versionCode = 230024" in ident and "23.0.24-s3-map-render-menu" in ident) or ("versionCode = 230025" in ident and "23.0.25-auto-trim-center" in ident)
assert 'DEFAULT_SSID = "HevelFitment"' in hot and 'DEFAULT_PASSWORD = "hevel369!"' in hot
assert 'storedSsid == "HEVEL_SKIN_LOADER"' in hot and 'putString("ssid", DEFAULT_SSID)' in hot
assert 'action("MapScan")' in main and 'action("Satallite")' not in main
assert 'action("Satellite")' in rad and rad.index('action("Satellite")') < rad.index('action("MAIN")')
assert 'RadarFieldHeader.create(this, "Satellite")' in scan
assert 'setBackgroundColor(Color.TRANSPARENT)' in header and 'TruckFitChrome.flashCyan(this)\n                    onEyeClick()' not in header
assert '/styles/v1/mapbox/satellite-v9/tiles/256/' in preview and 'Mapbox token rejected (HTTP 401)' in preview
for route in ['/api/maps/status','/api/maps/index','/api/maps/manifest','/api/maps/upload','/api/maps/activate','/api/maps/default','/api/maps/delete']:
    assert route in api
for token in ['imageSha256','imageCrc32','calibrationRevision','mapProximityEnabled','proximityWidthFt','proximityHeightFt']:
    assert token in sync
assert 'RadarFieldGeometry.sensorEnvelopeLengthFt' in sync and 'RadarFieldGeometry.sensorEnvelopeWidthFt' in sync
assert 'api.uploadMapImage' in sync and 'api.postMapManifest' in sync and 'api.postMapIndex' in sync
assert 'remoteRev != field.calibrationRevision' in sync
assert 'RadarMapSyncManager(this@MainActivity).syncAll' in main
assert 'RadarMapSyncManager(this@RadarFieldLibraryActivity).syncAll' in rad
assert 'RadarMapSyncManager(this@RadarFieldLibraryActivity).syncOne(field.id, activate = true)' in rad
assert 'sensorEnvelopeLengthFt: Double = 68.0' in geom and 'sensorEnvelopeWidthFt: Double = 48.0' in geom
print('PASS v230022 dedicated map catalog + S3 transfer contract')
