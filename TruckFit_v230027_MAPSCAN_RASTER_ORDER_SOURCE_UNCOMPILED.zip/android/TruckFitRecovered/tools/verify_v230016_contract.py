from pathlib import Path
root=Path(__file__).resolve().parents[1]
def read(rel): return (root/rel).read_text()
main=read('app/src/main/java/hevel/truckfit/loader/MainActivity.kt')
organizer=read('app/src/main/java/hevel/truckfit/loader/skin/SkinOrganizerActivity.kt')
editor=read('app/src/main/java/hevel/truckfit/loader/skin/SkinEditorActivity.kt')
repo=read('app/src/main/java/hevel/truckfit/loader/skin/SkinRepository.kt')
chrome=read('app/src/main/java/hevel/truckfit/loader/TruckFitChrome.kt')
lib=read('app/src/main/java/hevel/truckfit/loader/radarfield/RadarFieldLibraryActivity.kt')
header=read('app/src/main/java/hevel/truckfit/loader/radarfield/RadarFieldHeader.kt')
scan=read('app/src/main/java/hevel/truckfit/loader/radarfield/RadarFieldScanActivity.kt')
crop=read('app/src/main/java/hevel/truckfit/loader/radarfield/RadarFieldCropActivity.kt')
assert 'card.setOnClickListener' in main and 'SkinEditorActivity::class.java' in main
assert 'card.setOnLongClickListener' in main and 'showVehicleMenu' in main and 'activate(pack)' in main
assert 'tap opens 6 POVs • hold opens vehicle menu' in main
assert 'action("SCAN / COMPARE")' not in main
assert 'garageColumns' in organizer and 'garage_view' in organizer and 'vehicleCard' in organizer
assert 'startDragAndDrop' in organizer and 'ACTION_DROP' in organizer
assert 'repo.reorderPack' in organizer and 'repo.moveToFolder' in organizer
assert 'fun reorderPack' in repo
assert '6-VIEW VEHICLE COLLECTION' in editor and 'pickImage' in editor and 'updateSlot' in editor
assert 'button.setTextColor(Color.BLACK)' in chrome
assert 'setTextColor(Color.BLACK)' in header and 'garage_mode_eye' in header
assert 'onEyeClick = { cycleGrid() }' in lib
assert 'action("SCAN / COMPARE BY LOCATION")' not in lib
assert 'action("Import")' in lib
assert 'IMPORT SATELLITE IMAGE / CROP' not in scan and 'IMPORT SATELLITE IMAGE / CROP' not in crop
print('PASS v230016 organizer + interactions + MapScan eye/black text contract')
