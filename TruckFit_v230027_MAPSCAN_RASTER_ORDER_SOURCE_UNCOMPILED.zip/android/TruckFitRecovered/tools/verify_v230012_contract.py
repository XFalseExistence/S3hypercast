from pathlib import Path

root = Path(__file__).resolve().parents[1]
def read(rel): return (root / rel).read_text()

view = read("app/src/main/java/hevel/truckfit/loader/radarfield/RadarFieldCropView.kt")
activity = read("app/src/main/java/hevel/truckfit/loader/radarfield/RadarFieldCropActivity.kt")
geometry = read("app/src/main/java/hevel/truckfit/loader/radarfield/RadarFieldGeometry.kt")

assert "vehicleLengthFt: Double = 22.0" in geometry
assert "vehicleWidthFt: Double = 8.0" in geometry
assert "sensorRangeFt: Double = 20.0" in geometry
assert "sensorEnvelopeLengthFt: Double = 68.0" in geometry
assert "sensorEnvelopeWidthFt: Double = 48.0" in geometry
assert "selectedCenterOffsetFeet" in view
assert "canvas.drawCircle(centerX, centerY, dp(2.5f), cropPaint)" in view
assert 'canvas.drawText("N"' not in view
assert '"40 × 40 FT RADAR VIEW"' not in view
assert '"68 × 48 FT PROX • R20 FT"' in view
assert "crop.bottom + dp(22f)" in view
assert '"PROX FIELD: OFF"' in activity
assert '"80 × 80 DETAIL"' in activity
assert "openSelectedDetail()" in activity
assert "RadarFieldGeometry.offsetCenterFeet" in activity
assert "previewClient.fetchDetail(provider, selectedCenter" in activity
print("PASS v230012 sensor envelope / reticle / detail contract")
