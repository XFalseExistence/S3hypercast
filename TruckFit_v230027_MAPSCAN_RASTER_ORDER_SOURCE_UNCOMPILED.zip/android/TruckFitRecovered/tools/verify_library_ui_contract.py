from pathlib import Path
root=Path(__file__).resolve().parents[1]
main=(root/'app/src/main/java/hevel/truckfit/loader/MainActivity.kt').read_text()
editor=(root/'app/src/main/java/hevel/truckfit/loader/skin/SkinEditorActivity.kt').read_text()
models=(root/'app/src/main/java/hevel/truckfit/loader/skin/SkinModels.kt').read_text()
manifest=(root/'app/src/main/AndroidManifest.xml').read_text()
radar=(root/'app/src/main/java/hevel/truckfit/loader/radarfield/RadarFieldLibraryActivity.kt').read_text()
crop=(root/'app/src/main/java/hevel/truckfit/loader/radarfield/RadarFieldCropView.kt').read_text()
assert 'showGarageMenu' in main and 'garage_menu_lines' in main and 'GARAGE/MAIN' in main
assert 'SkinSlot.REAR_3D' in main
assert 'setOnLongClickListener' in main and 'SkinEditorActivity' in main
assert 'parentId: String? = null' in models
assert '6/6 LINKED' not in main
assert 'SkinLibraryRules.status' in editor
assert 'showMapScanMenu' in radar and 'MAPSCAN/MAIN' in radar and 'action("GARAGE")' in radar
assert 'SCAN / COMPARE BY LOCATION' not in radar
assert 'action("Import")' in radar
assert '80 × 80 FT CROP' in crop and 'radarGuideEnabled = false' in crop
assert 'ACCESS_FINE_LOCATION' in manifest and 'RadarFieldCropActivity' in manifest
print('PASS library/radar UI contract')
