from pathlib import Path
root=Path(__file__).resolve().parents[1]
def read(rel): return (root/rel).read_text()
main=read('app/src/main/java/hevel/truckfit/loader/MainActivity.kt')
chrome=read('app/src/main/java/hevel/truckfit/loader/TruckFitChrome.kt')
lib=read('app/src/main/java/hevel/truckfit/loader/radarfield/RadarFieldLibraryActivity.kt')
header=read('app/src/main/java/hevel/truckfit/loader/radarfield/RadarFieldHeader.kt')
client=read('app/src/main/java/hevel/truckfit/loader/radarfield/RadarFieldPreviewClient.kt')
req=read('app/src/main/java/hevel/truckfit/loader/radarfield/RadarProviderRequests.kt')
assert 'garage_mode_eye' in main and 'garage_menu_lines' in main
assert 'showGarageMenu' in main and 'GARAGE/MAIN' in main
assert 'tabs.addView' not in main
assert 'ORGANIZE' in main and ('action("Satallite")' in main or 'action("MapScan")' in main) and 'action("SCAN / COMPARE")' not in main
assert 'renderExpandedFolder' in main and 'repo.folders(currentFolderId).forEach' in main
assert 'BLUE = 0xFF2F6D8FL' in chrome and 'JADE = 0xFF52C7A5L' in chrome
assert 'styleMapScanHeader' in chrome and 'styleMapScanSecondary' in chrome and 'installMapScanSafeArea' in chrome
assert 'onEyeClick = { cycleGrid() }' in lib and 'onMenuClick = { showMapScanMenu(it) }' in lib
assert 'tabs.addView' not in lib and 'showMapScanMenu' in lib
assert 'styleMapScanHeader' in header and 'garage_menu_lines' in header
assert 'MAPBOX_DETAIL_ZOOM = 22' in client and 'fetchMapboxTiles' in client
assert '/640x640@2x' in req
assert (root/'app/src/main/res/drawable-nodpi/garage_mode_eye.png').exists()
assert (root/'app/src/main/res/drawable/garage_menu_lines.xml').exists()
assert (root/'app/src/main/res/drawable-nodpi/radar_field_header_icon.png').exists()
print('PASS v230015 Garage menu/theme + MapScan split + Mapbox detail contract')
