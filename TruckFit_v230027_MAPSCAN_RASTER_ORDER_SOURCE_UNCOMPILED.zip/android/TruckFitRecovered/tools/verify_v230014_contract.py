from pathlib import Path
root = Path(__file__).resolve().parents[1]
def read(rel): return (root / rel).read_text()
chrome = read('app/src/main/java/hevel/truckfit/loader/TruckFitChrome.kt')
colors = read('app/src/main/res/values/colors.xml')
theme = read('app/src/main/res/values/themes.xml')
view = read('app/src/main/java/hevel/truckfit/loader/radarfield/RadarFieldCropView.kt')
assert 'JADE = 0xFF52C7A5L' in chrome and 'JADE_LIGHT = 0xFF9BE6CBL' in chrome
assert 'stylePrimary' in chrome and 'styleSecondary' in chrome and 'styleMapScanPrimary' in chrome and 'applyTypography(root)' in chrome
assert '#2F6D8F' in colors and '#52C7A5' in colors
assert 'TruckFitTextViewStyle' in theme and 'sans-serif-medium' in theme
assert 'TruckFitChrome.displayTypeface()' in view
print('PASS v230014 mint-jade + HEVEL SF-style typography contract')

req = read('app/src/main/java/hevel/truckfit/loader/radarfield/RadarProviderRequests.kt')
client = read('app/src/main/java/hevel/truckfit/loader/radarfield/RadarFieldPreviewClient.kt')
assert '/640x640@2x' in req and 'padding=0' in req
assert 'ESRI_DETAIL_ZOOM = 21' in client and 'DETAIL_SIZE_PX = 1280' in client
print('PASS v230014 provider detail regression repair contract')
