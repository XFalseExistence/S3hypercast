#!/usr/bin/env python3
from pathlib import Path
import hashlib

root = Path(__file__).resolve().parents[1]
main = root / 'app/src/main'
manifest = (main / 'AndroidManifest.xml').read_text()
theme = (main / 'res/values/themes.xml').read_text()
layout = (main / 'res/layout/activity_main.xml').read_text()
chrome = (main / 'java/hevel/truckfit/loader/TruckFitChrome.kt').read_text()
old_icon = main / 'res/drawable-nodpi/truckfit_launcher_art.png'

assert 'android:icon="@mipmap/ic_launcher"' in manifest
assert 'android:roundIcon="@mipmap/ic_launcher_round"' in manifest
assert '#2F6D8F' in (main / 'res/values/colors.xml').read_text() and '#52C7A5' in (main / 'res/values/colors.xml').read_text()
assert '#F0F4F7' in (main / 'res/values/colors.xml').read_text()
assert '@drawable/xp_titlebar' in layout
assert '@drawable/xp_button_green' in layout
assert '@drawable/truckfit_launcher_art' in layout
assert 'WindowInsetsCompat.Type.systemBars()' in chrome
assert 'WindowInsetsCompat.Type.displayCutout()' in chrome
assert 'baseBottom + bars.bottom' in chrome
assert 'windowLightNavigationBar">true' in theme
assert hashlib.sha256(old_icon.read_bytes()).hexdigest() == 'c8a5b56831477edb788af550c7b568fc02a59cbc3ae3313a9af0ec60373be592'
print('PASS TruckFit W222 visual + safe-area contract')
