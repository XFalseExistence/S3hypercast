from pathlib import Path
root = Path(__file__).resolve().parents[1]
read = lambda p: (root / p).read_text()
editor = read('app/src/main/java/hevel/truckfit/loader/skin/SkinEditorActivity.kt')
main = read('app/src/main/java/hevel/truckfit/loader/MainActivity.kt')
rf = read('app/src/main/java/hevel/truckfit/loader/radarfield/RadarFieldLibraryActivity.kt')
scan = read('app/src/main/java/hevel/truckfit/loader/radarfield/RadarFieldScanActivity.kt')
header = read('app/src/main/java/hevel/truckfit/loader/radarfield/RadarFieldHeader.kt')
chrome = read('app/src/main/java/hevel/truckfit/loader/TruckFitChrome.kt')
manifest = read('app/src/main/AndroidManifest.xml')
assert 'ScaleType.FIT_CENTER' in editor and 'ScaleType.CENTER_CROP' not in editor
assert 'styleLibraryScreen' in chrome
assert 'styleLibraryScreen(this)' in main
assert 'styleLibraryScreen(this)' in rf
assert 'OnBackPressedCallback' in main and 'currentFolderId != null' in main
assert 'OnBackPressedCallback' in rf and 'currentFolderId != null' in rf
assert 'RadarFieldHeader.create' in rf and 'radar_field_header_icon' in header
assert 'TruckFit • Radar Fields' not in rf
assert 'RadarFieldPreviewClient' in scan
assert 'ProviderCredentialStore' in scan
assert 'ProviderSetupActivity' in manifest
print('PASS v230006 UI/provider contract')

assert (root / 'app/src/main/res/drawable-nodpi/radar_field_header_icon.png').is_file()
print('PASS v230006 header asset')
