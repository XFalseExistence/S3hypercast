from pathlib import Path

root = Path(__file__).resolve().parents[1]
radar = root / "app/src/main/java/hevel/truckfit/loader/radarfield"

crop_view = (radar / "RadarFieldCropView.kt").read_text()
crop = (radar / "RadarFieldCropActivity.kt").read_text()
scan = (radar / "RadarFieldScanActivity.kt").read_text()
client = (radar / "RadarFieldPreviewClient.kt").read_text()

checks = {
    "browser crop selection": "configureBrowser" in crop_view and "selectionFootprintFt" in crop_view and "cropRect()" in crop_view,
    "real crop render": "val crop = cropRect()" in crop_view and "crop.left" in crop_view and "crop.top" in crop_view,
    "orange radar guide opt-in": "radarGuideEnabled = false" in crop_view and ("68 × 48 FT PROX • R20 FT" in crop_view or "68 × 48 FT PROX • R20 FT" in crop_view),
    "clean view": "CLEAN VIEW" in crop and "setGuidesEnabled" in crop,
    "explicit crop save": "CROP & SAVE AS" in crop,
    "large Esri browse": "BROWSE_FOOTPRINT_FT = 480.0" in client and "ESRI_BROWSE_SIZE_PX = 1280" in client,
    "browse fetch": "fetchBrowse" in client and "openProviderBrowse" in scan,
    "browse intent": 'putExtra("browse_mode", browseMode)' in scan and 'putExtra("source_footprint_ft", sourceFootprintFt)' in scan,
    "preview session preserved": "restorePreviewSession" in scan and "radar_preview_session_v230008" in scan,
}

missing = [name for name, ok in checks.items() if not ok]
if missing:
    raise SystemExit("v230010 contract failed: " + ", ".join(missing))
print("PASS v230010 browse/crop/guide contract")
