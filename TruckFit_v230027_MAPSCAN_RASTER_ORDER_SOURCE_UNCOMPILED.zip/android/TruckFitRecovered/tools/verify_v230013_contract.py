from pathlib import Path
root = Path(__file__).resolve().parents[1]
def read(rel): return (root / rel).read_text()
req = read('app/src/main/java/hevel/truckfit/loader/radarfield/RadarProviderRequests.kt')
client = read('app/src/main/java/hevel/truckfit/loader/radarfield/RadarFieldPreviewClient.kt')
crop = read('app/src/main/java/hevel/truckfit/loader/radarfield/RadarFieldCropActivity.kt')
view = read('app/src/main/java/hevel/truckfit/loader/radarfield/RadarFieldCropView.kt')
assert 'detailRequestFor' in req
assert '/640x640@2x' in req and 'padding=0' in req
assert 'fetchDetail' in client and 'ESRI_DETAIL_ZOOM = 21' in client and 'DETAIL_SIZE_PX = 1280' in client
assert 'previewClient.fetchDetail' in crop and '.putExtra("detail_mode", true)' in crop
assert 'LOCKED 80×80 FT DETAIL' in crop
assert 'configureLockedDetail' in view and 'lockedDetailMode' in view
assert '68 × 48 FT PROX • R20 FT' in view
print('PASS v230013 locked provider detail contract')
