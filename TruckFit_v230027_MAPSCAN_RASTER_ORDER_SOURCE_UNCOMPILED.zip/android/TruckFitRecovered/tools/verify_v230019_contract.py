from pathlib import Path
root=Path(__file__).resolve().parents[1]
def read(rel): return (root/rel).read_text()
main=read('app/src/main/java/hevel/truckfit/loader/MainActivity.kt')
repo=read('app/src/main/java/hevel/truckfit/loader/skin/SkinRepository.kt')
edit=read('app/src/main/java/hevel/truckfit/loader/skin/SkinEditorActivity.kt')
hot=read('app/src/main/java/hevel/truckfit/loader/HotspotConnector.kt')
sync=read('app/src/main/java/hevel/truckfit/loader/transfer/S3SyncManager.kt')
ident=read('app/build.gradle.kts')
assert (('versionCode = 230021' in ident and '23.0.21-link-satellite-calibration' in ident) or ('versionCode = 230022' in ident and '23.0.22-map-catalog-fitment' in ident)) or ("versionCode = 230023" in ident and "23.0.23-map-sync-default-rounded-prox" in ident) or ("versionCode = 230024" in ident and "23.0.24-s3-map-render-menu" in ident) or ("versionCode = 230025" in ident and "23.0.25-auto-trim-center" in ident)
assert 'action("Sync")' in main and 'SYNC THIS VEHICLE TO S3' in edit
assert 'showVehicleMenu' in main and 'ACTIVATE' in main and 'UNLINK' in main and 'LINK' in main and 'RENAME' in main
assert 'DELETE? TAP AGAIN TO CONFIRM' in main
assert 'deletePack' in repo and 'clearRemoteMetadata' in repo and 'applyUploadHashes' in repo
assert 'class S3SyncManager' in sync and 'uploadSkin' in sync and 'postIndex' in sync
assert ((('DEFAULT_SSID = "HEVEL_SKIN_LOADER"' in hot and 'DEFAULT_PASSWORD = "hevelskins"' in hot) or ('DEFAULT_SSID = "HevelFitment"' in hot and 'DEFAULT_PASSWORD = "hevel369!"' in hot)) and 'SAVE + RETRY' in hot and 'bindProcessToNetwork' in hot)
print('PASS v230019 S3 sync + vehicle hold-menu contract')
