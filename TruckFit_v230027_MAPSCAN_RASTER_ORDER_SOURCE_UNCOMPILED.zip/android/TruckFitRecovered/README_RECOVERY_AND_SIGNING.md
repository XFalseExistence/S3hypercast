# TruckFit Recovered — install, recovery, and permanent signing

This recovered line intentionally uses the new package ID `hevel.truckfit.loader`, so it installs beside the legacy W222 package `hevel.skin.loader`. Keep W222 installed until the recovered catalog has been imported from HEVEL and verified.

## Permanent signing rule

The first production TruckFit Recovered APK must be signed with one permanent key. Keep at least **two user-controlled copies** of that keystore in separate places. Never commit the keystore or any password to GitHub, source archives, chat attachments, or the APK repository.

Release builds read only these secret values:

- `TRUCKFIT_KEYSTORE_PATH`
- `TRUCKFIT_KEYSTORE_PASSWORD`
- `TRUCKFIT_KEY_ALIAS`
- `TRUCKFIT_KEY_PASSWORD`

A release build deliberately fails if any are absent. Future builds must keep the **same applicationId** (`hevel.truckfit.loader`) and the **same signing key**, and must **increment versionCode**. Never replace the permanent key unless you are willing to uninstall the recovered app and lose package-private state.

## Zero-reload recovery

1. Install TruckFit Recovered while W222 remains installed.
2. Open `RECOVER LIBRARY`.
3. `IMPORT FROM HEVEL` reconstructs IDs, SKN/LZR banks, menu/folder structure, and remote hashes without uploading or deleting any skin assets.
4. `AUTO RELINK EXISTING PHONE IMAGES` hashes readable phone images and links exact SHA-256 matches.
5. If MediaStore cannot see everything, use `SELECT SKIN ROOT FOLDER` once and choose the common skin-image directory.
6. `REMOTE_ONLY` skins remain activatable on HEVEL even when their original phone PNG is not linked.
7. Export `TruckFit Library Backup` after verification.

Do not use `UPLOAD ALL` during migration. Uploads are explicit normal editing actions only.
