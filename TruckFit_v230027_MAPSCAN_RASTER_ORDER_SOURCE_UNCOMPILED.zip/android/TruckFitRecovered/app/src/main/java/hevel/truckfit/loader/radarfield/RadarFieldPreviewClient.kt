package hevel.truckfit.loader.radarfield

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Dns
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.ByteArrayOutputStream
import java.net.InetAddress
import java.util.concurrent.TimeUnit
import kotlin.math.ceil
import kotlin.math.floor

sealed class ProviderFetchResult {
    data class Success(val request: ProviderRequest, val bytes: ByteArray, val contentType: String?) : ProviderFetchResult()
    data class Unavailable(val request: ProviderRequest) : ProviderFetchResult()
    data class Error(val request: ProviderRequest, val message: String) : ProviderFetchResult()
}

class RadarFieldPreviewClient(private val context: Context) {
    suspend fun fetch(
        provider: RadarProviderId,
        center: GeoCenter,
        credentials: ProviderCredentials
    ): ProviderFetchResult = withContext(Dispatchers.IO) {
        val bounds = RadarFieldGeometry.boundsForFeet(center)
        val spec = RadarProviderRequests.requestFor(provider, center, bounds, credentials, RadarFieldGeometry.masterWidthFt)
        if (spec.unavailableReason != null) return@withContext ProviderFetchResult.Unavailable(spec)
        if (provider == RadarProviderId.ESRI) return@withContext fetchEsriTiles(spec, bounds, EsriTileWindow.previewZoom, EsriTileWindow.previewSizePx)
        fetchSingleImage(spec)
    }

    /** Locked, high-resolution 80x80-ft detail fetch. This path must never reuse browse framing. */
    suspend fun fetchDetail(
        provider: RadarProviderId,
        center: GeoCenter,
        credentials: ProviderCredentials
    ): ProviderFetchResult = withContext(Dispatchers.IO) {
        val bounds = RadarFieldGeometry.boundsForFeet(center)
        val spec = RadarProviderRequests.detailRequestFor(provider, center, credentials)
        if (spec.unavailableReason != null) return@withContext ProviderFetchResult.Unavailable(spec)
        if (provider == RadarProviderId.ESRI) {
            return@withContext fetchEsriTiles(spec, bounds, ESRI_DETAIL_ZOOM, DETAIL_SIZE_PX)
        }
        if (provider == RadarProviderId.MAPBOX) {
            return@withContext fetchMapboxTiles(spec, bounds, credentials.mapboxToken.trim(), MAPBOX_DETAIL_ZOOM, DETAIL_SIZE_PX)
        }
        fetchSingleImage(spec)
    }

    /**
     * Expanded browsing fetch used by every provider. Comparison cards stay 80x80 ft;
     * Crop / Inspect gets a 480x480-ft source that can slide under the fixed 80x80 crop frame.
     */
    suspend fun fetchBrowse(
        provider: RadarProviderId,
        center: GeoCenter,
        credentials: ProviderCredentials,
        footprintFt: Double = BROWSE_FOOTPRINT_FT
    ): ProviderFetchResult = withContext(Dispatchers.IO) {
        val bounds = RadarFieldGeometry.boundsForFeet(center, footprintFt, footprintFt)
        val spec = RadarProviderRequests.requestFor(provider, center, bounds, credentials, footprintFt)
        if (spec.unavailableReason != null) return@withContext ProviderFetchResult.Unavailable(spec)
        if (provider == RadarProviderId.ESRI) {
            fetchEsriTiles(spec, bounds, ESRI_BROWSE_ZOOM, ESRI_BROWSE_SIZE_PX)
        } else {
            fetchSingleImage(spec)
        }
    }

    private fun fetchEsriTiles(
        spec: ProviderRequest,
        bounds: GeoBounds,
        zoom: Int,
        outputSizePx: Int
    ): ProviderFetchResult = runCatching {
        val window = EsriTileWindow.forBounds(bounds, zoom)
        val client = internetClient()
        val mosaic = Bitmap.createBitmap(window.mosaicWidthPx, window.mosaicHeightPx, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(mosaic)
        window.tiles.forEach { tile ->
            val request = Request.Builder().url(EsriTileWindow.tileUrl(tile)).get().build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) error("Esri tile HTTP ${response.code}")
                val bytes = response.body?.bytes() ?: error("Empty Esri tile")
                val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: error("Esri tile decode failed")
                val left = (tile.x - window.minTileX) * 256f
                val top = (tile.y - window.minTileY) * 256f
                canvas.drawBitmap(bitmap, left, top, null)
                bitmap.recycle()
            }
        }

        val left = floor(window.cropLeftPx).toInt().coerceIn(0, mosaic.width - 1)
        val top = floor(window.cropTopPx).toInt().coerceIn(0, mosaic.height - 1)
        val right = ceil(window.cropRightPx).toInt().coerceIn(left + 1, mosaic.width)
        val bottom = ceil(window.cropBottomPx).toInt().coerceIn(top + 1, mosaic.height)
        val crop = Bitmap.createBitmap(mosaic, left, top, right - left, bottom - top)
        val scaled = Bitmap.createScaledBitmap(crop, outputSizePx, outputSizePx, true)
        val out = ByteArrayOutputStream()
        check(scaled.compress(Bitmap.CompressFormat.JPEG, 94, out)) { "Esri preview encode failed" }
        if (crop !== scaled) crop.recycle()
        scaled.recycle()
        mosaic.recycle()
        ProviderFetchResult.Success(spec, out.toByteArray(), "image/jpeg")
    }.getOrElse {
        ProviderFetchResult.Error(spec, it.message ?: it.javaClass.simpleName)
    }

    private fun fetchMapboxTiles(
        spec: ProviderRequest,
        bounds: GeoBounds,
        token: String,
        zoom: Int,
        outputSizePx: Int
    ): ProviderFetchResult = runCatching {
        require(token.isNotBlank()) { "Mapbox token missing" }
        val window = EsriTileWindow.forBounds(bounds, zoom)
        val client = internetClient()
        val tileScale = 2
        val tileSizePx = 256 * tileScale
        val mosaic = Bitmap.createBitmap(window.mosaicWidthPx * tileScale, window.mosaicHeightPx * tileScale, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(mosaic)
        window.tiles.forEach { tile ->
            val url = "https://api.mapbox.com/styles/v1/mapbox/satellite-v9/tiles/256/${tile.zoom}/${tile.x}/${tile.y}@2x" +
                "?access_token=${java.net.URLEncoder.encode(token.removePrefix("Bearer ").trim(), Charsets.UTF_8.name())}"
            val request = Request.Builder().url(url).get().build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) error(if (response.code == 401) "Mapbox token rejected (HTTP 401) • replace token in GPS Keys" else "Mapbox tile HTTP ${response.code}")
                val bytes = response.body?.bytes() ?: error("Empty Mapbox tile")
                val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: error("Mapbox tile decode failed")
                val left = (tile.x - window.minTileX) * tileSizePx.toFloat()
                val top = (tile.y - window.minTileY) * tileSizePx.toFloat()
                canvas.drawBitmap(bitmap, left, top, null)
                bitmap.recycle()
            }
        }

        val left = floor(window.cropLeftPx * tileScale).toInt().coerceIn(0, mosaic.width - 1)
        val top = floor(window.cropTopPx * tileScale).toInt().coerceIn(0, mosaic.height - 1)
        val right = ceil(window.cropRightPx * tileScale).toInt().coerceIn(left + 1, mosaic.width)
        val bottom = ceil(window.cropBottomPx * tileScale).toInt().coerceIn(top + 1, mosaic.height)
        val crop = Bitmap.createBitmap(mosaic, left, top, right - left, bottom - top)
        val scaled = Bitmap.createScaledBitmap(crop, outputSizePx, outputSizePx, true)
        val out = ByteArrayOutputStream()
        check(scaled.compress(Bitmap.CompressFormat.JPEG, 98, out)) { "Mapbox detail encode failed" }
        if (crop !== scaled) crop.recycle()
        scaled.recycle()
        mosaic.recycle()
        ProviderFetchResult.Success(spec, out.toByteArray(), "image/jpeg")
    }.getOrElse {
        ProviderFetchResult.Error(spec, it.message ?: it.javaClass.simpleName)
    }

    private fun fetchSingleImage(spec: ProviderRequest): ProviderFetchResult = runCatching {
        val builder = Request.Builder().url(spec.url).get()
        spec.headers.forEach { (name, value) -> builder.header(name, value) }
        internetClient().newCall(builder.build()).execute().use { response ->
            if (!response.isSuccessful) error(if (spec.provider == RadarProviderId.MAPBOX && response.code == 401) "Mapbox token rejected (HTTP 401) • replace token in GPS Keys" else "HTTP ${response.code}")
            val body = response.body ?: error("Empty response")
            val bytes = body.bytes()
            if (bytes.isEmpty()) error("Empty image")
            ProviderFetchResult.Success(spec, bytes, response.header("Content-Type"))
        }
    }.getOrElse {
        ProviderFetchResult.Error(spec, it.message ?: it.javaClass.simpleName)
    }

    /** Prefer a validated Internet network (usually cellular while HEVEL Wi-Fi stays connected). */
    private fun internetClient(): OkHttpClient {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.allNetworks.firstOrNull { n ->
            cm.getNetworkCapabilities(n)?.let { caps ->
                caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                    caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
            } == true
        }
        val builder = OkHttpClient.Builder()
            .connectTimeout(12, TimeUnit.SECONDS)
            .readTimeout(25, TimeUnit.SECONDS)
            .callTimeout(35, TimeUnit.SECONDS)
        if (network != null) {
            builder.socketFactory(network.socketFactory)
            builder.dns(object : Dns {
                override fun lookup(hostname: String): List<InetAddress> = network.getAllByName(hostname).toList()
            })
        }
        return builder.build()
    }

    companion object {
        const val BROWSE_FOOTPRINT_FT = 480.0
        const val ESRI_BROWSE_ZOOM = 20
        const val ESRI_BROWSE_SIZE_PX = 1280
        const val ESRI_DETAIL_ZOOM = 21
        const val MAPBOX_DETAIL_ZOOM = 22
        const val DETAIL_SIZE_PX = 1280
    }
}
