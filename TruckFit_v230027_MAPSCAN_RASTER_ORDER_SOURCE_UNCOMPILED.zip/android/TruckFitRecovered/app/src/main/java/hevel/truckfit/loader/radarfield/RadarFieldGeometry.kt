package hevel.truckfit.loader.radarfield

import kotlin.math.PI
import kotlin.math.cos

object RadarFieldGeometry {
    const val masterWidthFt: Double = 80.0
    const val masterHeightFt: Double = 80.0
    const val vehicleLengthFt: Double = 22.0
    const val vehicleWidthFt: Double = 8.0
    const val sensorRangeFt: Double = 20.0
    const val sensorEnvelopeLengthFt: Double = 68.0
    const val sensorEnvelopeWidthFt: Double = 48.0
    // 20-ft physical sensor buffer. The 68×48-ft proximity boundary is a rounded rectangle
    // with true quarter-circle corners; the 80×80-ft master crop remains square.
    const val proximityCornerRadiusFt: Double = sensorRangeFt
    val zoomLevels: List<Double> = listOf(0.5, 1.0, 1.5, 2.0)
    private const val FEET_TO_METERS = 0.3048
    private const val EARTH_RADIUS_METERS = 6378137.0

    fun visibleFieldFeet(zoom: Double): Double {
        require(zoom in zoomLevels) { "Unsupported MapScan zoom: $zoom" }
        return 20.0 / zoom
    }

    fun offsetCenterFeet(center: GeoCenter, eastFt: Double, northFt: Double): GeoCenter {
        val eastMeters = eastFt * FEET_TO_METERS
        val northMeters = northFt * FEET_TO_METERS
        val latRadians = center.lat * PI / 180.0
        val latDelta = northMeters / EARTH_RADIUS_METERS * 180.0 / PI
        val cosLat = cos(latRadians).coerceAtLeast(1e-6)
        val lonDelta = eastMeters / (EARTH_RADIUS_METERS * cosLat) * 180.0 / PI
        return GeoCenter(center.lat + latDelta, center.lon + lonDelta)
    }

    fun boundsForFeet(center: GeoCenter, widthFt: Double = masterWidthFt, heightFt: Double = masterHeightFt): GeoBounds {
        require(widthFt > 0.0 && heightFt > 0.0)
        val halfHeightMeters = heightFt * FEET_TO_METERS / 2.0
        val halfWidthMeters = widthFt * FEET_TO_METERS / 2.0
        val latRadians = center.lat * PI / 180.0
        val latDelta = halfHeightMeters / EARTH_RADIUS_METERS * 180.0 / PI
        val cosLat = cos(latRadians).coerceAtLeast(1e-6)
        val lonDelta = halfWidthMeters / (EARTH_RADIUS_METERS * cosLat) * 180.0 / PI
        return GeoBounds(
            west = center.lon - lonDelta,
            south = center.lat - latDelta,
            east = center.lon + lonDelta,
            north = center.lat + latDelta
        )
    }
}
