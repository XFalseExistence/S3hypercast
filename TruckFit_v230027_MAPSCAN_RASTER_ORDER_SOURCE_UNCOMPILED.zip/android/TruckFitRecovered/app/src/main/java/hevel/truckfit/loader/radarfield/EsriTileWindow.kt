package hevel.truckfit.loader.radarfield

import kotlin.math.PI
import kotlin.math.asinh
import kotlin.math.floor
import kotlin.math.tan

/** Exact XYZ tile window and pixel crop for one north-up geographic Radar Field footprint. */
data class EsriTileRef(val zoom: Int, val x: Int, val y: Int)

data class EsriTileWindowResult(
    val zoom: Int,
    val minTileX: Int,
    val maxTileX: Int,
    val minTileY: Int,
    val maxTileY: Int,
    val cropLeftPx: Double,
    val cropTopPx: Double,
    val cropRightPx: Double,
    val cropBottomPx: Double
) {
    val tiles: List<EsriTileRef> = buildList {
        for (y in minTileY..maxTileY) for (x in minTileX..maxTileX) add(EsriTileRef(zoom, x, y))
    }
    val tileCount: Int get() = tiles.size
    val mosaicWidthPx: Int get() = (maxTileX - minTileX + 1) * 256
    val mosaicHeightPx: Int get() = (maxTileY - minTileY + 1) * 256
    val cropWidthPx: Double get() = cropRightPx - cropLeftPx
    val cropHeightPx: Double get() = cropBottomPx - cropTopPx
}

object EsriTileWindow {
    const val previewZoom = 21
    const val previewSizePx = 640
    private const val TILE = 256.0
    private const val MAX_LAT = 85.05112878
    const val tileTemplate = "https://services.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}"

    fun forBounds(bounds: GeoBounds, zoom: Int = previewZoom): EsriTileWindowResult {
        require(zoom in 0..23)
        require(bounds.west < bounds.east && bounds.south < bounds.north)
        val westPx = globalPixelX(bounds.west, zoom)
        val eastPx = globalPixelX(bounds.east, zoom)
        val northPx = globalPixelY(bounds.north, zoom)
        val southPx = globalPixelY(bounds.south, zoom)
        val minX = floor(westPx / TILE).toInt()
        val maxX = floor((eastPx - 1e-9) / TILE).toInt()
        val minY = floor(northPx / TILE).toInt()
        val maxY = floor((southPx - 1e-9) / TILE).toInt()
        val originX = minX * TILE
        val originY = minY * TILE
        return EsriTileWindowResult(
            zoom = zoom,
            minTileX = minX,
            maxTileX = maxX,
            minTileY = minY,
            maxTileY = maxY,
            cropLeftPx = westPx - originX,
            cropTopPx = northPx - originY,
            cropRightPx = eastPx - originX,
            cropBottomPx = southPx - originY
        )
    }

    fun tileUrl(tile: EsriTileRef): String = tileTemplate
        .replace("{z}", tile.zoom.toString())
        .replace("{y}", tile.y.toString())
        .replace("{x}", tile.x.toString())

    private fun globalPixelX(lon: Double, zoom: Int): Double {
        val world = TILE * (1L shl zoom)
        return ((lon + 180.0) / 360.0) * world
    }

    private fun globalPixelY(latRaw: Double, zoom: Int): Double {
        val lat = latRaw.coerceIn(-MAX_LAT, MAX_LAT)
        val rad = lat * PI / 180.0
        val world = TILE * (1L shl zoom)
        val normalized = (1.0 - asinh(tan(rad)) / PI) / 2.0
        return normalized * world
    }
}
