package hevel.truckfit.loader

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.wifi.WifiNetworkSpecifier
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

object HotspotConnector {
    private const val DEFAULT_SSID = "HevelFitment"
    private const val DEFAULT_PASSWORD = "hevel369!"
    private const val PREFS = "hevel_hotspot"
    const val PERMISSION_REQUEST = 714
    private var callback: ConnectivityManager.NetworkCallback? = null
    private var connectedNetwork: Network? = null

    fun release(activity: Activity) {
        val cm = activity.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        callback?.let { runCatching { cm.unregisterNetworkCallback(it) } }
        callback = null
        connectedNetwork = null
        runCatching { cm.bindProcessToNetwork(null) }
    }

    fun connect(activity: Activity, status: (String) -> Unit = {}) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(activity, Manifest.permission.NEARBY_WIFI_DEVICES) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(activity, arrayOf(Manifest.permission.NEARBY_WIFI_DEVICES), PERMISSION_REQUEST)
            Toast.makeText(activity, "Allow Nearby Wi-Fi, then tap Hotspot again", Toast.LENGTH_LONG).show()
            return
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            status("Opening Wi-Fi • connect to the HEVEL S3 hotspot")
            activity.startActivity(Intent(Settings.ACTION_WIFI_SETTINGS))
            return
        }
        val prefs = activity.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val storedSsid = prefs.getString("ssid", null)
        val storedPass = prefs.getString("password", null)
        if (storedSsid == "HEVEL_SKIN_LOADER" || storedSsid == null) {
            prefs.edit().putString("ssid", DEFAULT_SSID).putString("password", DEFAULT_PASSWORD).apply()
        }
        val ssid = prefs.getString("ssid", DEFAULT_SSID).orEmpty().ifBlank { DEFAULT_SSID }
        val password = prefs.getString("password", DEFAULT_PASSWORD).orEmpty().ifBlank { DEFAULT_PASSWORD }
        request(activity, ssid, password, status)
    }

    fun onPermissionResult(
        activity: Activity,
        requestCode: Int,
        grantResults: IntArray,
        status: (String) -> Unit = {}
    ): Boolean {
        if (requestCode != PERMISSION_REQUEST) return false
        if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            status("Nearby Wi-Fi allowed • connecting to HevelFitment…")
            connect(activity, status)
        } else {
            status("Nearby Wi-Fi permission is required for HEVEL hotspot connection")
        }
        return true
    }

    private fun request(activity: Activity, ssid: String, password: String, status: (String) -> Unit) {
        val cm = activity.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        callback?.let { runCatching { cm.unregisterNetworkCallback(it) } }
        connectedNetwork = null

        val specBuilder = WifiNetworkSpecifier.Builder().setSsid(ssid)
        if (password.isNotBlank()) specBuilder.setWpa2Passphrase(password)
        val request = NetworkRequest.Builder()
            .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
            .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .setNetworkSpecifier(specBuilder.build())
            .build()

        status("Requesting " + ssid + "… Android may show one local-network approval")
        val handler = Handler(Looper.getMainLooper())
        var completed = false
        val timeout = Runnable {
            if (!completed) {
                status(ssid + " not found • check hotspot name/password")
                showConnectionHelp(activity, ssid, password, status)
            }
        }
        handler.postDelayed(timeout, 12000)

        callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                completed = true
                handler.removeCallbacks(timeout)
                connectedNetwork = network
                cm.bindProcessToNetwork(network)
                activity.runOnUiThread {
                    status("Connected to " + ssid + " • TruckFit traffic bound to HEVEL 192.168.4.1")
                    Toast.makeText(activity, "HEVEL hotspot connected", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onUnavailable() {
                completed = true
                handler.removeCallbacks(timeout)
                activity.runOnUiThread {
                    status(ssid + " unavailable")
                    showConnectionHelp(activity, ssid, password, status)
                }
            }

            override fun onLost(network: Network) {
                if (connectedNetwork == network) connectedNetwork = null
                cm.bindProcessToNetwork(null)
                activity.runOnUiThread { status(ssid + " disconnected • normal Wi-Fi restored") }
            }
        }
        cm.requestNetwork(request, callback!!)
    }

    private fun showConnectionHelp(activity: Activity, ssid: String, password: String, status: (String) -> Unit) {
        val ssidInput = EditText(activity).apply { hint = "Hotspot SSID"; setText(ssid) }
        val passInput = EditText(activity).apply { hint = "Hotspot password"; setText(password) }
        val box = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            val pad = (16 * resources.displayMetrics.density).toInt()
            setPadding(pad, pad / 2, pad, 0)
            addView(ssidInput)
            addView(passInput)
        }
        AlertDialog.Builder(activity)
            .setTitle("HevelFitment hotspot")
            .setMessage("TruckFit is targeting HevelFitment at 192.168.4.1. Android keeps your normal network policy intact; TruckFit binds its own traffic to the S3 local network. Default password: hevel369!.")
            .setView(box)
            .setNegativeButton("CANCEL", null)
            .setNeutralButton("WI-FI PANEL") { _, _ ->
                activity.startActivity(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY))
            }
            .setPositiveButton("SAVE + RETRY") { _, _ ->
                val nextSsid = ssidInput.text.toString().trim().ifBlank { DEFAULT_SSID }
                val nextPass = passInput.text.toString()
                activity.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                    .putString("ssid", nextSsid)
                    .putString("password", nextPass)
                    .apply()
                request(activity, nextSsid, nextPass, status)
            }.show()
    }
}
