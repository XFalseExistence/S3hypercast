package hevel.truckfit.loader.radarfield

data class RadarPreviewEntry(
    val filePath: String,
    val attribution: String
)

data class RadarPreviewSnapshot(
    val center: GeoCenter?,
    val previews: Map<RadarProviderId, RadarPreviewEntry>
)

/** In-process Scan / Compare state so navigation does not trigger provider re-fetches. */
object RadarPreviewSession {
    private var currentCenter: GeoCenter? = null
    private val currentPreviews = linkedMapOf<RadarProviderId, RadarPreviewEntry>()

    @Synchronized
    fun begin(center: GeoCenter) {
        if (currentCenter != center) {
            currentCenter = center
            currentPreviews.clear()
        }
    }

    @Synchronized
    fun put(provider: RadarProviderId, filePath: String, attribution: String) {
        currentPreviews[provider] = RadarPreviewEntry(filePath, attribution)
    }

    @Synchronized
    fun remove(provider: RadarProviderId) {
        currentPreviews.remove(provider)
    }

    @Synchronized
    fun clear() {
        currentCenter = null
        currentPreviews.clear()
    }

    @Synchronized
    fun snapshot(): RadarPreviewSnapshot = RadarPreviewSnapshot(currentCenter, currentPreviews.toMap())
}
