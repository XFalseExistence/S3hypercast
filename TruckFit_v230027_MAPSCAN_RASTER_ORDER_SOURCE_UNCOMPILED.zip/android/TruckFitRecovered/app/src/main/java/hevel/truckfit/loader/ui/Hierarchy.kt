package hevel.truckfit.loader.ui

object Hierarchy {
    fun parentOf(id: String, parents: Map<String, String?>): String? = parents[id]

    fun pathToRoot(id: String, parents: Map<String, String?>): List<String> {
        val out = mutableListOf<String>()
        val seen = mutableSetOf<String>()
        var cursor: String? = id
        while (cursor != null && seen.add(cursor)) {
            out += cursor
            cursor = parents[cursor]
        }
        return out.asReversed()
    }

    fun canMove(id: String, newParentId: String?, parents: Map<String, String?>): Boolean {
        if (newParentId == null) return true
        if (id == newParentId) return false
        var cursor: String? = newParentId
        val seen = mutableSetOf<String>()
        while (cursor != null && seen.add(cursor)) {
            if (cursor == id) return false
            cursor = parents[cursor]
        }
        return true
    }
}
