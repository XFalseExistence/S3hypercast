package hevel.truckfit.loader.transfer

import hevel.truckfit.loader.skin.*

data class RemoteSlotSnapshot(val sourceSha:String?,val renderSha:String?)
data class RemoteManifestSnapshot(val slots:Map<SkinSlot,RemoteSlotSnapshot>)
data class SlotUploadPlan(val slot:SkinSlot,val localUri:String)

object SyncPlanner {
    fun plan(local:RecoveredSkinPack,remote:RemoteManifestSnapshot):List<SlotUploadPlan> = SkinSlot.entries.mapNotNull { slot ->
        val l=local.slots[slot] ?: return@mapNotNull null
        val uri=l.localUri ?: return@mapNotNull null
        if(l.state!=LocalSourceState.LOCAL_LINKED) return@mapNotNull null
        val r=remote.slots[slot]
        val unchanged = r!=null && !l.sourceSha.isNullOrBlank() && !l.renderSha.isNullOrBlank() &&
            l.sourceSha.equals(r.sourceSha,true) && l.renderSha.equals(r.renderSha,true)
        if(unchanged) null else SlotUploadPlan(slot,uri)
    }
}
