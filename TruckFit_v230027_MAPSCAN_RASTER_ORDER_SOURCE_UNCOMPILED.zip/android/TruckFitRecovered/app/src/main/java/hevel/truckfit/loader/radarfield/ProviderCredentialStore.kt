package hevel.truckfit.loader.radarfield

import android.content.Context

class ProviderCredentialStore(context: Context) {
    private val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun read(): ProviderCredentials = ProviderCredentials(
        mapboxToken = prefs.getString("mapbox", "").orEmpty().trim().removePrefix("Bearer ").trim(),
        googleKey = prefs.getString("google", "").orEmpty(),
        azureCredential = prefs.getString("azure", "").orEmpty(),
        googleEnabled = prefs.getBoolean("google_enabled", false),
        azureEnabled = prefs.getBoolean("azure_enabled", false)
    )

    fun write(value: ProviderCredentials): Boolean = prefs.edit()
        .putString("mapbox", value.mapboxToken.trim().removePrefix("Bearer ").trim())
        .putString("google", value.googleKey.trim())
        .putString("azure", value.azureCredential.trim())
        .putBoolean("google_enabled", value.googleEnabled)
        .putBoolean("azure_enabled", value.azureEnabled)
        .commit()

    companion object { private const val PREFS = "truckfit_provider_credentials_v1" }
}
