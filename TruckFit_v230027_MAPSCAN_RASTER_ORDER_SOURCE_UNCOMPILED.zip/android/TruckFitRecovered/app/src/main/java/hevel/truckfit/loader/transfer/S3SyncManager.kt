package hevel.truckfit.loader.transfer

import android.content.Context
import hevel.truckfit.loader.AppServices
import hevel.truckfit.loader.skin.RecoveredSkinPack
import hevel.truckfit.loader.skin.SkinBank
import hevel.truckfit.loader.skin.SkinFolder
import hevel.truckfit.loader.skin.SkinRepository
import hevel.truckfit.loader.skin.SkinSlot
import kotlinx.serialization.json.*

data class S3SyncResult(
    val successful: Boolean,
    val message: String,
    val uploadedViews: Int = 0
)

class S3SyncManager(private val context: Context) {
    private val repo: SkinRepository = AppServices.repository(context)
    private val api = AppServices.api()
    private val transfer = SkinTransfer(context.contentResolver, api)

    suspend fun syncOne(packId: String): S3SyncResult {
        val pack = repo.get(packId) ?: return S3SyncResult(false, "Vehicle no longer exists")
        if (!pack.linkedToS3) return pruneOne(pack)
        return runCatching {
            val remote = fetchRemoteManifest(pack.id)
            val outcome = transfer.uploadSkin(pack, remote)
            repo.applyUploadHashes(pack.id, outcome.sourceHashes, outcome.renderHashes)
            check(postIndex()) { "S3 index update failed" }
            S3SyncResult(true, "Synced " + pack.name + " • " + outcome.uploadedSlots + " view(s)", outcome.uploadedSlots)
        }.getOrElse { S3SyncResult(false, "Sync failed: " + it.message) }
    }

    suspend fun syncAll(onProgress: (String) -> Unit = {}): S3SyncResult {
        val packs = repo.all().filter { it.bank == SkinBank.SKN }
        if (packs.isEmpty()) return S3SyncResult(false, "No Garage vehicles to sync")
        val linked = packs.filter { it.linkedToS3 }
        val unlinked = packs.filterNot { it.linkedToS3 }
        var views = 0
        for ((index, pack) in unlinked.withIndex()) {
            onProgress("Removing unlinked " + (index + 1) + "/" + unlinked.size + ": " + pack.name + "…")
            val removed = runCatching { api.deleteRemote(pack.id) }
                .getOrElse { return S3SyncResult(false, "Remove failed on " + pack.name + ": " + it.message, views) }
            if (!removed.successful && removed.code != 404) return S3SyncResult(false, "Remove failed on " + pack.name + " HTTP " + removed.code, views)
            repo.clearRemoteMetadata(pack.id)
        }
        for ((index, pack) in linked.withIndex()) {
            onProgress("Syncing " + (index + 1) + "/" + linked.size + ": " + pack.name + "…")
            val outcome = runCatching {
                val remote = fetchRemoteManifest(pack.id)
                transfer.uploadSkin(pack, remote)
            }.getOrElse { return S3SyncResult(false, "Sync failed on " + pack.name + ": " + it.message, views) }
            views += outcome.uploadedSlots
            repo.applyUploadHashes(pack.id, outcome.sourceHashes, outcome.renderHashes)
        }
        if (!postIndex()) return S3SyncResult(false, "Vehicle images reconciled, but S3 index update failed", views)
        return S3SyncResult(true, "S3 sync complete • " + linked.size + " linked • " + unlinked.size + " removed • " + views + " view(s)", views)
    }

    suspend fun unlink(packId: String): S3SyncResult {
        val pack = repo.get(packId) ?: return S3SyncResult(false, "Vehicle no longer exists")
        return if (repo.setLinkedToS3(pack.id, false))
            S3SyncResult(true, "Unlinked " + pack.name + " • shaded locally • Sync will remove it from S3")
        else S3SyncResult(false, "Unlink failed")
    }

    suspend fun link(packId: String): S3SyncResult {
        val pack = repo.get(packId) ?: return S3SyncResult(false, "Vehicle no longer exists")
        return if (repo.setLinkedToS3(pack.id, true))
            S3SyncResult(true, "Linked " + pack.name + " • next Sync will restore it to S3")
        else S3SyncResult(false, "Link failed")
    }

    private suspend fun pruneOne(pack: RecoveredSkinPack): S3SyncResult = runCatching {
        val response = api.deleteRemote(pack.id)
        check(response.successful || response.code == 404) { "S3 remove HTTP " + response.code }
        repo.clearRemoteMetadata(pack.id)
        check(postIndex()) { "S3 index update failed" }
        S3SyncResult(true, "Removed " + pack.name + " from S3 • local unlinked card kept")
    }.getOrElse { S3SyncResult(false, "Remove failed: " + it.message) }

    suspend fun status(): S3SyncResult = runCatching {
        val response = api.skinStatus()
        if (response.successful) S3SyncResult(true, "S3 loader reachable • 192.168.4.1")
        else S3SyncResult(false, "S3 answered HTTP " + response.code)
    }.getOrElse { S3SyncResult(false, "S3 not reachable: " + it.message) }

    private suspend fun fetchRemoteManifest(packId: String): RemoteManifestSnapshot {
        val response = api.skinManifest(packId)
        if (response.code == 404) return RemoteManifestSnapshot(emptyMap())
        check(response.successful) { "S3 manifest HTTP " + response.code }
        val root = runCatching { Json { ignoreUnknownKeys = true }.parseToJsonElement(response.body).jsonObject }
            .getOrElse { error("S3 manifest malformed for " + packId) }
        val container = root["slots"] as? JsonObject
        fun deep(o: JsonObject, key: String): String? {
            (o[key] as? JsonPrimitive)?.contentOrNull?.let { return it }
            o.values.filterIsInstance<JsonObject>().forEach { child ->
                (child[key] as? JsonPrimitive)?.contentOrNull?.let { return it }
            }
            return null
        }
        val slots = SkinSlot.entries.mapNotNull { slot ->
            val obj = (container?.get(slot.wireName) ?: root[slot.wireName]) as? JsonObject ?: return@mapNotNull null
            val source = deep(obj, "sourceSha") ?: deep(obj, "source_sha")
            val render = deep(obj, "renderSha") ?: deep(obj, "render_sha")
            slot to RemoteSlotSnapshot(source, render)
        }.toMap()
        return RemoteManifestSnapshot(slots)
    }

    private suspend fun postIndex(): Boolean {
        val all = repo.all().filter { it.linkedToS3 }
        val folders = repo.folders()
        val json = buildJsonObject {
            put("schema", 1)
            putJsonArray("lzr") { all.filter { it.bank == SkinBank.LZR }.forEach { add(JsonPrimitive(it.id)) } }
            putJsonArray("skn") { all.filter { it.bank == SkinBank.SKN }.forEach { add(JsonPrimitive(it.id)) } }
            putJsonArray("menu") {
                val consumed = mutableSetOf<String>()
                folders.filter { it.parentId == null }.forEach { folder ->
                    val ids = descendantPackIds(folder, folders, all)
                    if (ids.isNotEmpty()) {
                        add(buildJsonObject {
                            put("type", "folder")
                            put("name", folder.name)
                            put("items", buildJsonArray { ids.forEach { add(JsonPrimitive(it)) } })
                        })
                        consumed += ids
                    }
                }
                all.filter { it.id !in consumed }.forEach { pack ->
                    add(buildJsonObject {
                        put("type", "skin")
                        put("id", pack.id)
                    })
                }
            }
        }.toString()
        return api.postIndex(json).successful
    }

    private fun descendantPackIds(
        rootFolder: SkinFolder,
        folders: List<SkinFolder>,
        packs: List<RecoveredSkinPack>
    ): List<String> {
        val folderIds = linkedSetOf(rootFolder.id)
        var changed = true
        while (changed) {
            changed = false
            folders.forEach { f ->
                if (f.parentId in folderIds && folderIds.add(f.id)) changed = true
            }
        }
        return packs.filter { it.folderId in folderIds }.map { it.id }
    }
}
