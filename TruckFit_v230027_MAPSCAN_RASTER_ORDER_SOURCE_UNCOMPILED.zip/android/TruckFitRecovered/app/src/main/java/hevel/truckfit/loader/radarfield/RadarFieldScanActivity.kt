package hevel.truckfit.loader.radarfield

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import hevel.truckfit.loader.TruckFitChrome
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.launch
import kotlinx.coroutines.supervisorScope
import java.io.File
import java.util.Locale

class RadarFieldScanActivity : AppCompatActivity() {
    private lateinit var lat: EditText
    private lateinit var lon: EditText
    private lateinit var status: TextView
    private lateinit var loadButton: Button
    private val cells = linkedMapOf<RadarProviderId, ProviderCell>()
    private val store by lazy { ProviderCredentialStore(this) }
    private val client by lazy { RadarFieldPreviewClient(this) }
    private val previewSession by lazy {
        getSharedPreferences("radar_preview_session_v230008", Context.MODE_PRIVATE)
    }
    private var loadJob: Job? = null
    private var targetFolderId: String? = null

    private val requestLocation = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (it.values.any { granted -> granted }) {
            fillLastKnownLocation()
        } else {
            status.text = "Location permission denied - enter center manually"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        targetFolderId = intent.getStringExtra("folder_id")
        prunePreviewCache()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(hevel.truckfit.loader.R.drawable.mapscan_scan_backdrop)
        }
        root.addView(RadarFieldHeader.create(this, "Satellite"))

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(18))
        }
        status = TextView(this).apply {
            text = "Choose one shared geographic center. Nothing is requested until you tap LOAD PREVIEWS."
            textSize = 14f
            setPadding(dp(12), dp(10), dp(12), dp(10))
            TruckFitChrome.styleBodyText(this)
            TruckFitChrome.stylePanel(this)
        }
        content.addView(status)

        lat = EditText(this).apply {
            hint = "Latitude"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or
                android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL or
                android.text.InputType.TYPE_NUMBER_FLAG_SIGNED
        }
        lon = EditText(this).apply {
            hint = "Longitude"
            inputType = lat.inputType
        }
        content.addView(lat, fullWidth(8))
        content.addView(lon, fullWidth(6))

        val locationRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        locationRow.addView(Button(this).apply {
            text = "USE PHONE LOCATION"
            TruckFitChrome.styleMapScanSecondary(this)
            setOnClickListener { gatherLocation() }
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(4) })
        loadButton = Button(this).apply {
            text = "LOAD PREVIEWS"
            TruckFitChrome.styleMapScanPrimary(this)
            setOnClickListener { loadAll() }
        }
        locationRow.addView(loadButton, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(4) })
        content.addView(locationRow, fullWidth(8))

        content.addView(TextView(this).apply {
            text = "PROVIDER COMPARISON"
            textSize = 15f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(dp(6), dp(16), dp(6), dp(6))
            TruckFitChrome.styleBodyText(this)
        })

        val grid = GridLayout(this).apply {
            columnCount = 2
            rowCount = 2
        }
        RadarProviderId.entries.forEach { provider ->
            val cell = buildCell(provider)
            cells[provider] = cell
            grid.addView(cell.root, GridLayout.LayoutParams().apply {
                width = 0
                height = dp(210)
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(dp(4), dp(4), dp(4), dp(4))
            })
        }
        content.addView(grid, fullWidth(6))

        content.addView(TextView(this).apply {
            text = "Esri works without a key. Mapbox works after adding a public token. Google and Azure stay OFF until you enable them in GPS Keys. Provider images are comparison previews. To save a permanent MapScan image: TOOLS > Import, choose imagery you may retain, crop it, then tap SAVE AS."
            textSize = 12f
            setPadding(dp(10), dp(10), dp(10), dp(10))
            TruckFitChrome.styleBodyText(this)
            TruckFitChrome.stylePanel(this)
        }, fullWidth(8))

        content.addView(Button(this).apply {
            text = "GPS KEYS"
            TruckFitChrome.styleMapScanSecondary(this)
            setOnClickListener {
                startActivity(Intent(this@RadarFieldScanActivity, ProviderSetupActivity::class.java))
            }
        }, fullWidth(8))

        root.addView(ScrollView(this).apply { addView(content) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        TruckFitChrome.installMapScanSafeArea(this, root)

        val restored = restorePreviewSession()
        applyAvailabilityLabels()
        if (restored) {
            status.text = "Restored loaded previews - no provider refresh required"
        }
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized) applyAvailabilityLabels()
    }

    private fun buildCell(provider: RadarProviderId): ProviderCell {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(6), dp(6), dp(6), dp(6))
            TruckFitChrome.stylePanel(this)
        }
        val image = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(0xFF202020.toInt())
        }
        root.addView(image, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        val title = TextView(this).apply {
            text = provider.displayName
            gravity = Gravity.CENTER
            textSize = 12f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            TruckFitChrome.styleBodyText(this)
        }
        root.addView(title, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(4)
        })
        val state = TextView(this).apply {
            gravity = Gravity.CENTER
            textSize = 10f
            setPadding(dp(2), dp(2), dp(2), dp(2))
            TruckFitChrome.styleBodyText(this)
        }
        root.addView(state)
        return ProviderCell(root, image, state)
    }

    private fun applyAvailabilityLabels() {
        val center = parseCenterOrNull() ?: GeoCenter(0.0, 0.0)
        val credentials = store.read()
        val bounds = RadarFieldGeometry.boundsForFeet(center)
        cells.forEach { (provider, cell) ->
            val req = RadarProviderRequests.requestFor(provider, center, bounds, credentials)
            if (cell.file == null) {
                cell.state.text = req.unavailableReason ?: "READY - tap LOAD PREVIEWS"
            }
            cell.root.setOnClickListener {
                when {
                    cell.file != null -> openPreview(provider, cell.file!!, cell.previewCenter ?: center, cell.canPersist)
                    req.unavailableReason != null -> startActivity(Intent(this, ProviderSetupActivity::class.java))
                    else -> loadOne(provider)
                }
            }
        }
    }

    private fun loadAll() {
        val center = parseCenterOrNull() ?: return showCenterError()
        ensurePreviewSessionCenter(center)
        loadJob?.cancel()
        loadJob = lifecycleScope.launch {
            loadButton.isEnabled = false
            status.text = "Loading provider previews - cached cells will survive navigation"
            val credentials = store.read()
            supervisorScope {
                RadarProviderId.entries
                    .map { provider -> async { provider to client.fetch(provider, center, credentials) } }
                    .awaitAll()
                    .forEach { (provider, result) -> renderResult(provider, center, result) }
            }
            loadButton.isEnabled = true
            status.text = "Preview pass complete - tap an image to inspect/crop - tap an error cell to retry"
        }
    }

    private fun loadOne(provider: RadarProviderId) {
        val center = parseCenterOrNull() ?: return showCenterError()
        ensurePreviewSessionCenter(center)
        lifecycleScope.launch {
            cells[provider]?.state?.text = "LOADING..."
            renderResult(provider, center, client.fetch(provider, center, store.read()))
        }
    }

    private fun renderResult(provider: RadarProviderId, center: GeoCenter, result: ProviderFetchResult) {
        val cell = cells[provider] ?: return
        when (result) {
            is ProviderFetchResult.Success -> {
                val bitmap = BitmapFactory.decodeByteArray(result.bytes, 0, result.bytes.size)
                if (bitmap == null) {
                    cell.state.text = "ERROR - image decode failed - tap retry"
                    cell.file = null
                    cell.previewCenter = null
                    clearProviderSession(provider)
                    cell.root.setOnClickListener { loadOne(provider) }
                    return
                }
                val file = cachePreview(provider, center, result.bytes)
                cell.file = file
                cell.previewCenter = center
                cell.canPersist = result.request.canPersist
                cell.image.setImageBitmap(bitmap)
                cell.state.text = result.request.attribution
                persistProviderSession(provider, center, cell)
                cell.root.setOnClickListener { openPreview(provider, file, center, cell.canPersist) }
            }

            is ProviderFetchResult.Unavailable -> {
                cell.file = null
                cell.previewCenter = null
                cell.canPersist = false
                cell.image.setImageDrawable(null)
                cell.state.text = result.request.unavailableReason ?: "Unavailable"
                clearProviderSession(provider)
                cell.root.setOnClickListener {
                    startActivity(Intent(this, ProviderSetupActivity::class.java))
                }
            }

            is ProviderFetchResult.Error -> {
                cell.file = null
                cell.previewCenter = null
                cell.canPersist = false
                cell.image.setImageDrawable(null)
                cell.state.text = "ERROR - ${result.message} - tap retry"
                clearProviderSession(provider)
                cell.root.setOnClickListener { loadOne(provider) }
            }
        }
    }

    private fun openPreview(
        provider: RadarProviderId,
        file: File,
        center: GeoCenter,
        canPersist: Boolean
    ) {
        openProviderBrowse(provider, center, canPersist, file)
    }

    private fun openProviderBrowse(
        provider: RadarProviderId,
        center: GeoCenter,
        canPersist: Boolean,
        fallbackFile: File
    ) {
        val footprint = RadarFieldPreviewClient.BROWSE_FOOTPRINT_FT
        val cached = providerBrowseCacheFile(provider, center)
        if (cached.isFile && cached.length() > 0L && System.currentTimeMillis() - cached.lastModified() < PREVIEW_CACHE_MAX_AGE_MS) {
            launchCrop(
                provider,
                cached,
                center,
                canPersist,
                browseMode = true,
                sourceFootprintFt = footprint
            )
            return
        }

        lifecycleScope.launch {
            val cell = cells[provider]
            val prior = cell?.state?.text?.toString().orEmpty()
            cell?.state?.text = "LOADING ${footprint.toInt()}×${footprint.toInt()} FT BROWSE AREA…"
            when (val result = client.fetchBrowse(provider, center, store.read(), footprint)) {
                is ProviderFetchResult.Success -> {
                    val browseFile = cacheBrowsePreview(provider, center, result.bytes)
                    cell?.state?.text = prior.ifBlank { result.request.attribution }
                    launchCrop(
                        provider,
                        browseFile,
                        center,
                        canPersist,
                        browseMode = true,
                        sourceFootprintFt = footprint
                    )
                }
                is ProviderFetchResult.Error -> {
                    cell?.state?.text = "BROWSE ERROR • opening 80×80 preview"
                    launchCrop(provider, fallbackFile, center, canPersist, browseMode = false)
                }
                is ProviderFetchResult.Unavailable -> {
                    cell?.state?.text = result.request.unavailableReason ?: "Provider unavailable"
                    launchCrop(provider, fallbackFile, center, canPersist, browseMode = false)
                }
            }
        }
    }

    private fun launchCrop(
        provider: RadarProviderId,
        file: File,
        center: GeoCenter,
        canPersist: Boolean,
        browseMode: Boolean,
        sourceFootprintFt: Double = RadarFieldGeometry.masterWidthFt
    ) {
        startActivity(
            Intent(this, RadarFieldCropActivity::class.java)
                .putExtra("image_uri", Uri.fromFile(file).toString())
                .putExtra("folder_id", targetFolderId)
                .putExtra("provider", provider.name.lowercase())
                .putExtra("center_lat", center.lat)
                .putExtra("center_lon", center.lon)
                .putExtra("allow_persist", canPersist)
                .putExtra("browse_mode", browseMode)
                .putExtra("source_footprint_ft", sourceFootprintFt)
        )
    }

    private fun cachePreview(provider: RadarProviderId, center: GeoCenter, bytes: ByteArray): File {
        val dir = File(cacheDir, "radar_provider_previews").apply { mkdirs() }
        val latKey = String.format(Locale.US, "%.5f", center.lat)
        val lonKey = String.format(Locale.US, "%.5f", center.lon)
        return File(dir, "${provider.name.lowercase()}-$latKey-$lonKey.img").apply {
            writeBytes(bytes)
            setLastModified(System.currentTimeMillis())
        }
    }

    private fun providerBrowseCacheFile(provider: RadarProviderId, center: GeoCenter): File {
        val dir = File(cacheDir, "radar_provider_previews").apply { mkdirs() }
        val latKey = String.format(Locale.US, "%.5f", center.lat)
        val lonKey = String.format(Locale.US, "%.5f", center.lon)
        return File(dir, "${provider.name.lowercase()}-browse-$latKey-$lonKey.img")
    }

    private fun cacheBrowsePreview(provider: RadarProviderId, center: GeoCenter, bytes: ByteArray): File =
        providerBrowseCacheFile(provider, center).apply {
            writeBytes(bytes)
            setLastModified(System.currentTimeMillis())
        }

    private fun sessionCenterKey(center: GeoCenter): String =
        String.format(Locale.US, "%.7f,%.7f", center.lat, center.lon)

    private fun ensurePreviewSessionCenter(center: GeoCenter) {
        val key = sessionCenterKey(center)
        if (previewSession.getString("center_key", null) != key) {
            previewSession.edit().clear()
                .putString("center_key", key)
                .putString("center_lat", String.format(Locale.US, "%.7f", center.lat))
                .putString("center_lon", String.format(Locale.US, "%.7f", center.lon))
                .apply()
            clearCells()
        }
    }

    private fun persistProviderSession(provider: RadarProviderId, center: GeoCenter, cell: ProviderCell) {
        val file = cell.file ?: return
        val key = sessionCenterKey(center)
        previewSession.edit()
            .putString("center_key", key)
            .putString("center_lat", String.format(Locale.US, "%.7f", center.lat))
            .putString("center_lon", String.format(Locale.US, "%.7f", center.lon))
            .putString("file_${provider.name}", file.absolutePath)
            .putString("state_${provider.name}", cell.state.text.toString())
            .putBoolean("persist_${provider.name}", cell.canPersist)
            .apply()
    }

    private fun clearProviderSession(provider: RadarProviderId) {
        previewSession.edit()
            .remove("file_${provider.name}")
            .remove("state_${provider.name}")
            .remove("persist_${provider.name}")
            .apply()
    }

    private fun restorePreviewSession(): Boolean {
        val savedLatText = previewSession.getString("center_lat", null) ?: return false
        val savedLonText = previewSession.getString("center_lon", null) ?: return false
        val savedLat = savedLatText.toDoubleOrNull() ?: return false
        val savedLon = savedLonText.toDoubleOrNull() ?: return false
        val center = GeoCenter(savedLat, savedLon)

        lat.setText(savedLatText)
        lon.setText(savedLonText)

        var restoredAny = false
        RadarProviderId.entries.forEach { provider ->
            val path = previewSession.getString("file_${provider.name}", null) ?: return@forEach
            val file = File(path)
            if (!file.isFile) {
                clearProviderSession(provider)
                return@forEach
            }
            val bitmap = BitmapFactory.decodeFile(file.absolutePath)
            if (bitmap == null) {
                clearProviderSession(provider)
                return@forEach
            }
            val cell = cells[provider] ?: return@forEach
            cell.file = file
            cell.previewCenter = center
            cell.canPersist = previewSession.getBoolean("persist_${provider.name}", false)
            cell.image.setImageBitmap(bitmap)
            cell.state.text = previewSession.getString("state_${provider.name}", provider.displayName) ?: provider.displayName
            cell.root.setOnClickListener { openPreview(provider, file, center, cell.canPersist) }
            restoredAny = true
        }
        return restoredAny
    }

    private fun prunePreviewCache() {
        val cutoff = System.currentTimeMillis() - PREVIEW_CACHE_MAX_AGE_MS
        File(cacheDir, "radar_provider_previews").listFiles()?.forEach { file ->
            if (file.lastModified() < cutoff) file.delete()
        }
    }

    private fun gatherLocation() {
        val fine = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!fine && !coarse) {
            requestLocation.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
        } else {
            fillLastKnownLocation()
        }
    }

    private fun fillLastKnownLocation() {
        val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val best = lm.getProviders(true)
            .mapNotNull { p -> runCatching { lm.getLastKnownLocation(p) }.getOrNull() }
            .maxByOrNull { it.time }
        if (best == null) {
            status.text = "No cached phone location yet - enter center manually"
        } else {
            lat.setText(String.format(Locale.US, "%.7f", best.latitude))
            lon.setText(String.format(Locale.US, "%.7f", best.longitude))
            val center = GeoCenter(best.latitude, best.longitude)
            ensurePreviewSessionCenter(center)
            status.text = "Center gathered - tap LOAD PREVIEWS when ready"
            applyAvailabilityLabels()
        }
    }

    private fun parseCenterOrNull(): GeoCenter? = runCatching {
        GeoCenter(lat.text.toString().trim().toDouble(), lon.text.toString().trim().toDouble())
    }.getOrNull()

    private fun showCenterError() {
        status.text = "Enter a valid latitude and longitude first"
    }

    private fun clearCells() {
        cells.values.forEach {
            it.file = null
            it.previewCenter = null
            it.canPersist = false
            it.image.setImageDrawable(null)
        }
    }

    private fun fullWidth(top: Int) =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(top)
        }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

    companion object {
        private const val PREVIEW_CACHE_MAX_AGE_MS = 60L * 60L * 1000L
    }

    private data class ProviderCell(
        val root: LinearLayout,
        val image: ImageView,
        val state: TextView,
        var file: File? = null,
        var previewCenter: GeoCenter? = null,
        var canPersist: Boolean = false
    )
}
