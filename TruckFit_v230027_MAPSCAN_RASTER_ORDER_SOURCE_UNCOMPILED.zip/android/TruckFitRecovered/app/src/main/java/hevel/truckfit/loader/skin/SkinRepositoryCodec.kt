package hevel.truckfit.loader.skin

import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

class SkinRepositoryCodec(
    private val json: Json = Json { ignoreUnknownKeys = true; encodeDefaults = true; prettyPrint = false }
) {
    fun encode(envelope: RecoveredLibraryEnvelope): String = json.encodeToString(envelope)
    fun decode(raw: String): RecoveredLibraryEnvelope = json.decodeFromString(raw)
}
