package hevel.truckfit.loader.radarfield

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import hevel.truckfit.loader.TruckFitChrome
import hevel.truckfit.loader.ui.CropTransform
import kotlin.math.min

class RadarFieldCropView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {
    private val imagePaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val cropPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dp(2f)
        color = Color.WHITE
    }
    private val guidePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dp(1.5f)
        color = 0xFFFFC107.toInt()
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = dp(13f)
        typeface = TruckFitChrome.displayTypeface()
    }

    private var bitmap: Bitmap? = null
    private var transform: CropTransform? = null
    private var lastX = 0f
    private var lastY = 0f
    private var browserMode = false
    private var lockedDetailMode = false
    private var sourceFootprintFt = RadarFieldGeometry.masterWidthFt.toFloat()
    private var selectionFootprintFt = RadarFieldGeometry.masterWidthFt.toFloat()
    private var guidesEnabled = true
    private var radarGuideEnabled = false

    private val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            if (browserMode || lockedDetailMode) return false
            val b = bitmap ?: return false
            val t = transform ?: return false
            transform = t.zoomBy(detector.scaleFactor, detector.focusX, detector.focusY)
                .clamp(b.width.toFloat(), b.height.toFloat(), width.toFloat(), height.toFloat())
            invalidate()
            return true
        }
    })

    fun configureBrowser(sourceFootprintFt: Double, selectionFootprintFt: Double = RadarFieldGeometry.masterWidthFt) {
        require(sourceFootprintFt >= selectionFootprintFt && selectionFootprintFt > 0.0)
        browserMode = true
        lockedDetailMode = false
        this.sourceFootprintFt = sourceFootprintFt.toFloat()
        this.selectionFootprintFt = selectionFootprintFt.toFloat()
        post { resetTransform() }
    }

    fun configureLocalCrop() {
        browserMode = false
        lockedDetailMode = false
        sourceFootprintFt = RadarFieldGeometry.masterWidthFt.toFloat()
        selectionFootprintFt = RadarFieldGeometry.masterWidthFt.toFloat()
        post { resetTransform() }
    }

    fun configureLockedDetail() {
        browserMode = false
        lockedDetailMode = true
        sourceFootprintFt = RadarFieldGeometry.masterWidthFt.toFloat()
        selectionFootprintFt = RadarFieldGeometry.masterWidthFt.toFloat()
        post { resetTransform() }
    }

    fun setGuidesEnabled(enabled: Boolean) {
        guidesEnabled = enabled
        invalidate()
    }

    fun guidesEnabled(): Boolean = guidesEnabled

    fun setRadarGuideEnabled(enabled: Boolean) {
        radarGuideEnabled = enabled
        invalidate()
    }

    fun radarGuideEnabled(): Boolean = radarGuideEnabled

    fun setSource(bitmap: Bitmap) {
        this.bitmap = bitmap
        if (width > 0 && height > 0) resetTransform() else post { resetTransform() }
    }

    fun resetTransform() {
        val b = bitmap ?: return
        if (width <= 0 || height <= 0) return
        transform = CropTransform.fit(b.width.toFloat(), b.height.toFloat(), width.toFloat(), height.toFloat())
        invalidate()
    }

    fun currentTransform(): CropTransform? = transform

    fun selectedCenterOffsetFeet(): Pair<Double, Double> {
        if (!browserMode) return 0.0 to 0.0
        val b = bitmap ?: return 0.0 to 0.0
        val t = transform ?: return 0.0 to 0.0
        val crop = cropRect()
        if (t.scale <= 0f || b.width <= 0 || b.height <= 0) return 0.0 to 0.0
        val sourceX = (crop.centerX() - t.offsetX) / t.scale
        val sourceY = (crop.centerY() - t.offsetY) / t.scale
        val eastFt = ((sourceX - b.width / 2f) / b.width.toFloat()) * sourceFootprintFt
        val northFt = -((sourceY - b.height / 2f) / b.height.toFloat()) * sourceFootprintFt
        return eastFt.toDouble() to northFt.toDouble()
    }

    fun renderCrop(sizePx: Int = 1024): Bitmap {
        require(sizePx > 0)
        val b = requireNotNull(bitmap) { "No source image" }
        val t = requireNotNull(transform) { "Crop transform unavailable" }
        val crop = cropRect()
        val out = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        canvas.drawColor(Color.BLACK)
        val factor = sizePx.toFloat() / crop.width()
        val matrix = Matrix().apply {
            setScale(t.scale * factor, t.scale * factor)
            postTranslate((t.offsetX - crop.left) * factor, (t.offsetY - crop.top) * factor)
        }
        canvas.drawBitmap(b, matrix, imagePaint)
        return out
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val width = MeasureSpec.getSize(widthMeasureSpec)
        val heightLimit = MeasureSpec.getSize(heightMeasureSpec).takeIf { it > 0 } ?: width
        val size = min(width, heightLimit).coerceAtLeast(1)
        setMeasuredDimension(size, size)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (w > 0 && h > 0 && (oldw != w || oldh != h)) resetTransform()
    }

    private fun cropRect(): RectF {
        if (!browserMode) return RectF(0f, 0f, width.toFloat(), height.toFloat())
        val ratio = (selectionFootprintFt / sourceFootprintFt).coerceIn(0.05f, 1f)
        val side = min(width, height) * ratio
        val left = (width - side) / 2f
        val top = (height - side) / 2f
        return RectF(left, top, left + side, top + side)
    }

    private fun clampBrowser(t: CropTransform, b: Bitmap): CropTransform {
        val crop = cropRect()
        val scaledW = b.width * t.scale
        val scaledH = b.height * t.scale
        val minX = crop.right - scaledW
        val maxX = crop.left
        val minY = crop.bottom - scaledH
        val maxY = crop.top
        return t.copy(
            offsetX = t.offsetX.coerceIn(minX, maxX),
            offsetY = t.offsetY.coerceIn(minY, maxY)
        )
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(0xFF161616.toInt())
        val b = bitmap
        val t = transform
        if (b != null && t != null) {
            val matrix = Matrix().apply {
                setScale(t.scale, t.scale)
                postTranslate(t.offsetX, t.offsetY)
            }
            canvas.drawBitmap(b, matrix, imagePaint)
        }

        if (!guidesEnabled) return
        val crop = cropRect()
        val inset = dp(2f)
        val framed = RectF(crop.left + inset, crop.top + inset, crop.right - inset, crop.bottom - inset)
        canvas.drawRect(framed, cropPaint)

        val centerX = crop.centerX()
        val centerY = crop.centerY()
        val arm = dp(15f)
        val gap = dp(4f)
        canvas.drawLine(centerX - arm, centerY, centerX - gap, centerY, cropPaint)
        canvas.drawLine(centerX + gap, centerY, centerX + arm, centerY, cropPaint)
        canvas.drawLine(centerX, centerY - arm, centerX, centerY - gap, cropPaint)
        canvas.drawLine(centerX, centerY + gap, centerX, centerY + arm, cropPaint)
        canvas.drawCircle(centerX, centerY, dp(2.5f), cropPaint)

        val cropLabel = "80 × 80 FT CROP"
        val labelX = crop.centerX() - textPaint.measureText(cropLabel) / 2f
        val belowY = crop.bottom + dp(22f)
        val labelY = if (browserMode && belowY < height - dp(4f)) belowY else crop.bottom - dp(10f)
        canvas.drawText(cropLabel, labelX.coerceAtLeast(dp(4f)), labelY, textPaint)

        if (radarGuideEnabled) {
            val guideW = crop.width() * (RadarFieldGeometry.sensorEnvelopeLengthFt / RadarFieldGeometry.masterWidthFt).toFloat()
            val guideH = crop.height() * (RadarFieldGeometry.sensorEnvelopeWidthFt / RadarFieldGeometry.masterHeightFt).toFloat()
            val left = crop.centerX() - guideW / 2f
            val top = crop.centerY() - guideH / 2f
            val guide = RectF(left, top, left + guideW, top + guideH)
            val feetToPx = crop.width() / RadarFieldGeometry.masterWidthFt.toFloat()
            val cornerRadiusPx = feetToPx * RadarFieldGeometry.proximityCornerRadiusFt.toFloat()
            canvas.drawRoundRect(guide, cornerRadiusPx, cornerRadiusPx, guidePaint)
            canvas.drawText("68 × 48 FT PROX • R20 FT", guide.left + dp(5f), guide.top + dp(17f), textPaint)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val b = bitmap ?: return false
        if (!browserMode && !lockedDetailMode) scaleDetector.onTouchEvent(event)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = event.x
                lastY = event.y
                parent?.requestDisallowInterceptTouchEvent(true)
                return true
            }
            MotionEvent.ACTION_MOVE -> if (!lockedDetailMode && (browserMode || !scaleDetector.isInProgress)) {
                val dx = event.x - lastX
                val dy = event.y - lastY
                val t = transform ?: return true
                transform = if (browserMode) {
                    clampBrowser(t.panBy(dx, dy), b)
                } else {
                    t.panBy(dx, dy).clamp(b.width.toFloat(), b.height.toFloat(), width.toFloat(), height.toFloat())
                }
                lastX = event.x
                lastY = event.y
                invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> parent?.requestDisallowInterceptTouchEvent(false)
        }
        return true
    }

    private fun dp(value: Float): Float = value * resources.displayMetrics.density
}
