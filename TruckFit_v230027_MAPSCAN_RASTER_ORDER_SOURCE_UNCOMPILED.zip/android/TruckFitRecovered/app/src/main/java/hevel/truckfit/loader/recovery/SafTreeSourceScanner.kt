package hevel.truckfit.loader.recovery

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn

class SafTreeSourceScanner(private val context:Context) {
    fun scan(root:Uri):Flow<SourceCandidate> = flow {
        val tree=DocumentFile.fromTreeUri(context,root) ?: return@flow
        val stack=ArrayDeque<DocumentFile>(); stack.add(tree)
        while(stack.isNotEmpty()) {
            val node=stack.removeFirst()
            val children=runCatching { node.listFiles().toList().sortedBy { it.uri.toString() } }.getOrDefault(emptyList())
            children.forEach { child ->
                when {
                    child.isDirectory -> stack.add(child)
                    child.isFile && (child.type?.startsWith("image/")==true || child.name?.substringAfterLast('.',"")?.lowercase() in setOf("png","jpg","jpeg","webp")) ->
                        emit(SourceCandidate(child.uri.toString(),child.name.orEmpty()))
                }
            }
        }
    }.flowOn(Dispatchers.IO)
}
