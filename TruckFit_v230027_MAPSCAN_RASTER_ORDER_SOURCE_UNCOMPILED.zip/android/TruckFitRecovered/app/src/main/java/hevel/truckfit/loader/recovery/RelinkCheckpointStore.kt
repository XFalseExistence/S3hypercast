package hevel.truckfit.loader.recovery

import android.content.SharedPreferences

class RelinkCheckpointStore(private val prefs:SharedPreferences):RelinkCheckpoint {
    override fun resolved():Map<String,String> = prefs.getStringSet(KEY,emptySet()).orEmpty().mapNotNull { row ->
        val i=row.indexOf('|'); if(i<=0) null else row.substring(0,i) to row.substring(i+1)
    }.toMap()
    override fun save(sha:String,uri:String) {
        val current=resolved().toMutableMap(); current[sha]=uri
        prefs.edit().putStringSet(KEY,current.toSortedMap().mapTo(linkedSetOf()){"${it.key}|${it.value}"}).commit()
    }
    companion object { private const val KEY="resolved_sha_uri_v1" }
}
