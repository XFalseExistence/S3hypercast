package hevel.truckfit.loader.radarfield

data class GeoCenter(val lat: Double, val lon: Double) {
    init {
        require(lat in -90.0..90.0) { "Latitude out of range" }
        require(lon in -180.0..180.0) { "Longitude out of range" }
    }
}

data class GeoBounds(val west: Double, val south: Double, val east: Double, val north: Double)
