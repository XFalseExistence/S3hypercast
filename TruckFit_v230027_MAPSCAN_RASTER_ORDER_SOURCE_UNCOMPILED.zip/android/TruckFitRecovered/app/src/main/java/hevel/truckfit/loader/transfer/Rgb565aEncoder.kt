package hevel.truckfit.loader.transfer

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.InputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

data class EncodedRaster(val width:Int,val height:Int,val bytes:ByteArray)

object Rgb565aEncoder {
    fun encode(input:InputStream,maxEdge:Int=512):EncodedRaster {
        val original=BitmapFactory.decodeStream(input) ?: error("Unsupported image")
        val scale=minOf(1f,maxEdge.toFloat()/maxOf(original.width,original.height).toFloat())
        val w=maxOf(1,(original.width*scale).toInt())
        val h=maxOf(1,(original.height*scale).toInt())
        val bmp=if(w==original.width && h==original.height) original else Bitmap.createScaledBitmap(original,w,h,true)
        val pixels=IntArray(w*h); bmp.getPixels(pixels,0,w,0,0,w,h)
        val payloadBytes=w*h*3
        val out=ByteBuffer.allocate(16+payloadBytes).order(ByteOrder.LITTLE_ENDIAN)
        out.put(byteArrayOf('H'.code.toByte(),'S'.code.toByte(),'K'.code.toByte(),'1'.code.toByte()))
        out.putShort(w.toShort()); out.putShort(h.toShort()); out.put(1); out.put(byteArrayOf(0,0,0)); out.putInt(payloadBytes)
        pixels.forEach { argb ->
            val a=(argb ushr 24) and 0xff; val r=(argb ushr 16) and 0xff; val g=(argb ushr 8) and 0xff; val b=argb and 0xff
            val rgb565=((r shr 3) shl 11) or ((g shr 2) shl 5) or (b shr 3)
            out.put((rgb565 and 0xff).toByte()); out.put(((rgb565 ushr 8) and 0xff).toByte()); out.put(a.toByte())
        }
        if(bmp!==original) bmp.recycle(); original.recycle()
        return EncodedRaster(w,h,out.array())
    }
}
