package hevel.truckfit.loader.skin

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import hevel.truckfit.loader.AppServices
import hevel.truckfit.loader.TruckFitChrome
import hevel.truckfit.loader.ui.SkinLibraryRules
import hevel.truckfit.loader.transfer.S3SyncManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class SkinEditorActivity : AppCompatActivity() {
    private val repo by lazy { AppServices.repository(this) }
    private var packId: String = ""
    private var pendingSlot: SkinSlot? = null
    private lateinit var shell: LinearLayout
    private lateinit var content: LinearLayout
    private lateinit var header: TextView

    private val pickImage = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        val slot = pendingSlot
        pendingSlot = null
        if (uri != null && slot != null) {
            lifecycleScope.launch {
                val normalized = runCatching {
                    withContext(Dispatchers.IO) {
                        VehicleImageNormalizer.normalize(this@SkinEditorActivity, uri, packId, slot)
                    }
                }.getOrElse {
                    Toast.makeText(this@SkinEditorActivity, "Could not read image: ${it.message}", Toast.LENGTH_SHORT).show()
                    return@launch
                }
                val pack = repo.get(packId) ?: return@launch
                val old = pack.slots[slot] ?: RecoveredSlot(slot.wireName, state = LocalSourceState.EMPTY)
                if (repo.updateSlot(packId, slot, old.copy(
                        localUri = normalized.uri.toString(),
                        sourceSha = null,
                        renderSha = null,
                        state = LocalSourceState.LOCAL_LINKED
                    ))) {
                    Toast.makeText(
                        this@SkinEditorActivity,
                        if (normalized.backgroundRemoved) "Image added • background removed • trimmed + centered" else "Image added • trimmed + centered",
                        Toast.LENGTH_SHORT
                    ).show()
                    render()
                } else {
                    Toast.makeText(this@SkinEditorActivity, "Could not update view", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        packId = intent.getStringExtra("skin_id").orEmpty()
        buildChrome()
        render()
    }

    private fun buildChrome() {
        shell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            TruckFitChrome.styleScreen(this)
        }
        header = TextView(this).apply {
            textSize = 24f
            setTextColor(Color.WHITE)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(dp(18), dp(14), dp(18), dp(14))
            TruckFitChrome.styleHeader(this)
        }
        shell.addView(header)

        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(18))
        }
        val scroll = ScrollView(this).apply { addView(content) }
        shell.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(shell)
        TruckFitChrome.installSafeArea(this, shell)
    }

    private fun render() {
        val pack = repo.get(packId)
        header.text = pack?.let { SkinLibraryRules.displayName(it.bank.name, it.name) } ?: "Garage item not found"
        content.removeAllViews()
        if (pack == null) return

        val linked = pack.slots.values.count { it.localUri != null }
        val remote = pack.slots.values.count { it.state == LocalSourceState.REMOTE_ONLY }
        content.addView(TextView(this).apply {
            text = "6-VIEW VEHICLE COLLECTION • ${SkinLibraryRules.status(linked, remote)}\nTap a view to add/replace any image. Background is removed automatically when needed. Hold to clear."
            textSize = 14f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            TruckFitChrome.styleBodyText(this)
            TruckFitChrome.stylePanel(this)
        })
        SkinSlot.entries.forEach { slot -> content.addView(slotView(slot, pack.slots[slot]), fullWidth(10)) }
        content.addView(Button(this).apply {
            text = "SYNC THIS VEHICLE TO S3"
            TruckFitChrome.stylePrimary(this)
            setOnClickListener { syncThisVehicle() }
        }, fullWidth(14))
    }

    private fun slotView(slot: SkinSlot, value: RecoveredSlot?): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(7), dp(7), dp(7), dp(9))
        TruckFitChrome.stylePanel(this)
        addView(TextView(this@SkinEditorActivity).apply {
            text = displaySlot(slot)
            textSize = 14f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(dp(6), dp(4), dp(6), dp(6))
            TruckFitChrome.styleBodyText(this)
        })
        val frame = FrameLayout(this@SkinEditorActivity).apply { setBackgroundColor(0xFF202020.toInt()) }
        val image = ImageView(this@SkinEditorActivity).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(0xFF202020.toInt())
        }
        frame.addView(image, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(175)))
        val status = TextView(this@SkinEditorActivity).apply {
            text = value?.state?.name ?: "EMPTY"
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
        }
        frame.addView(status, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(175)))
        value?.localUri?.let { raw ->
            runCatching { image.setImageURI(Uri.parse(raw)); status.visibility = android.view.View.GONE }
        }
        addView(frame)
        setOnClickListener {
            pendingSlot = slot
            pickImage.launch(arrayOf("image/*"))
        }
        setOnLongClickListener {
            if (value?.localUri == null) return@setOnLongClickListener true
            AlertDialog.Builder(this@SkinEditorActivity)
                .setTitle("Clear ${displaySlot(slot)} image?")
                .setMessage("This removes the local image link from this vehicle view. Remote metadata is preserved.")
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("CLEAR") { _, _ ->
                    val nextState = if (value.sourceSha != null || value.renderSha != null) LocalSourceState.REMOTE_ONLY else LocalSourceState.EMPTY
                    repo.updateSlot(packId, slot, value.copy(localUri = null, state = nextState))
                    render()
                }
                .show()
            true
        }
    }

    private fun syncThisVehicle() = lifecycleScope.launch {
        val pack = repo.get(packId) ?: return@launch
        Toast.makeText(this@SkinEditorActivity, "Checking S3 loader…", Toast.LENGTH_SHORT).show()
        val manager = S3SyncManager(this@SkinEditorActivity)
        val status = manager.status()
        if (!status.successful) {
            Toast.makeText(this@SkinEditorActivity, status.message + " • connect HOTSPOT first", Toast.LENGTH_LONG).show()
            return@launch
        }
        val result = manager.syncOne(pack.id)
        Toast.makeText(this@SkinEditorActivity, result.message, Toast.LENGTH_LONG).show()
        render()
    }

    private fun displaySlot(slot: SkinSlot): String = when (slot) {
        SkinSlot.REAR_3D -> "3D SOUTH"
        SkinSlot.REAR_2D -> "2D SOUTH"
        else -> slot.wireName.replace('_', ' ')
    }

    private fun fullWidth(top: Int) = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(top) }
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()
}
