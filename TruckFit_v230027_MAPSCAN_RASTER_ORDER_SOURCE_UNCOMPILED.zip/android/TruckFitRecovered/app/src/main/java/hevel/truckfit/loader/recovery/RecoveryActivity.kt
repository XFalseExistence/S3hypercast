package hevel.truckfit.loader.recovery

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import hevel.truckfit.loader.AppServices
import hevel.truckfit.loader.TruckFitChrome
import kotlinx.coroutines.launch

class RecoveryActivity:AppCompatActivity() {
    private val repo by lazy { AppServices.repository(this) }
    private lateinit var status:TextView
    private val checkpoint by lazy { RelinkCheckpointStore(getSharedPreferences("truckfit_relink_v1",MODE_PRIVATE)) }
    private val treePicker=registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if(uri!=null) {
            contentResolver.takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION)
            relinkWith(SafTreeSourceScanner(this).scan(uri),"Folder scan")
        }
    }
    private val mediaPermission=registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if(granted) autoRelink() else renderStatus("Image permission denied. Remote Garage items remain usable; use SELECT GARAGE MAIN FOLDER instead.")
    }

    override fun onCreate(savedInstanceState:Bundle?) {
        super.onCreate(savedInstanceState)
        val column=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(18,18,18,18) }
        TruckFitChrome.styleScreen(column)
        val header=TextView(this).apply {
            text="TruckFit Recovery"; textSize=24f; setTextColor(0xFFFFFFFF.toInt()); setPadding(18,14,18,14)
        }
        TruckFitChrome.styleHeader(header); column.addView(header)
        status=TextView(this).apply {
            text="Recovery is read-only until you explicitly use normal TruckFit upload controls."
            textSize=16f; setPadding(18,16,18,16)
        }
        TruckFitChrome.styleBodyText(status); TruckFitChrome.stylePanel(status); column.addView(status)
        fun button(text:String, primary:Boolean=false, action:()->Unit)=Button(this).apply {
            this.text=text; setOnClickListener{action()}; if(primary) TruckFitChrome.stylePrimary(this) else TruckFitChrome.styleSecondary(this)
            column.addView(this, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin=10 })
        }
        button("IMPORT FROM HEVEL",true) { importRemote() }
        button("AUTO RELINK EXISTING PHONE IMAGES") { requestAutoRelink() }
        button("SELECT GARAGE MAIN FOLDER") { treePicker.launch(null) }
        button("VERIFY LIBRARY") { renderCounts("Verification") }
        val scroll=ScrollView(this).apply { addView(column) }
        setContentView(scroll)
        TruckFitChrome.installSafeArea(this, scroll)
        renderCounts("Ready")
    }

    private fun importRemote()=lifecycleScope.launch {
        setBusy("Reading HEVEL Garage index and manifests…")
        runCatching { RemoteCatalogImporter(AppServices.api(),repo).import() }
            .onSuccess { result -> renderStatus("Imported ${result.packs.size} Garage items, ${result.folders.size} folders. ${result.warnings.size} warning(s). No Garage assets were uploaded or deleted.") }
            .onFailure { renderStatus("Import failed: ${it.message}. Existing recovered catalog was not erased.") }
    }

    private fun requestAutoRelink() {
        if(Build.VERSION.SDK_INT>=33) {
            if(ContextCompat.checkSelfPermission(this,Manifest.permission.READ_MEDIA_IMAGES)==PackageManager.PERMISSION_GRANTED) autoRelink()
            else mediaPermission.launch(Manifest.permission.READ_MEDIA_IMAGES)
        } else autoRelink()
    }

    private fun autoRelink()=relinkWith(MediaStoreSourceScanner(this).scan(),"Media scan")

    private fun relinkWith(flow:kotlinx.coroutines.flow.Flow<SourceCandidate>,label:String)=lifecycleScope.launch {
        val unresolved=RecoveryRelinker.unresolvedHashes(repo)
        if(unresolved.isEmpty()) { renderStatus("$label: every recoverable source is already linked."); return@launch }
        setBusy("$label: hashing existing images (${unresolved.size} unresolved hashes)…")
        val matcher=Sha256SourceMatcher(AndroidSourceContentReader(contentResolver),checkpoint)
        runCatching { matcher.match(unresolved,flow) }
            .onSuccess { result ->
                val changed=RecoveryRelinker.applyMatches(repo,result)
                renderStatus("$label: linked $changed slot(s); ${result.unresolved.size} source hash(es) still remote-only.")
            }
            .onFailure { renderStatus("$label stopped: ${it.message}. Existing matches and remote catalog remain intact.") }
    }

    private fun setBusy(message:String)=renderStatus(message)
    private fun renderCounts(prefix:String) {
        val packs=repo.all(); val linked=packs.sumOf { p -> p.slots.values.count{it.localUri!=null} }; val remote=packs.sumOf { p -> p.slots.values.count{it.state==hevel.truckfit.loader.skin.LocalSourceState.REMOTE_ONLY} }
        renderStatus("$prefix: ${packs.size} Garage items • $linked linked slots • $remote remote-only slots")
    }
    private fun renderStatus(message:String) { status.text=message }

    companion object { fun rootTreeIntent()=Intent(Intent.ACTION_OPEN_DOCUMENT_TREE) }
}
