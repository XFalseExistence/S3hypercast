package hevel.truckfit.loader.radarfield

import android.os.Bundle
import android.text.InputType
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import hevel.truckfit.loader.TruckFitChrome

class ProviderSetupActivity : AppCompatActivity() {
    private val store by lazy { ProviderCredentialStore(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val saved = store.read()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; TruckFitChrome.styleScreen(this) }
        root.addView(RadarFieldHeader.create(this, "GPS Keys"))
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(10), dp(12), dp(18)) }
        content.addView(note("ESRI / ARCGIS is available without a key for live comparison previews."))

        val mapbox = secretField("Mapbox public access token", saved.mapboxToken)
        content.addView(mapbox, fullWidth(10))
        content.addView(note("Mapbox previews use the Static Images API. TruckFit keeps them only in temporary cache."), fullWidth(5))

        val googleEnabled = CheckBox(this).apply { text = "Enable Google satellite previews"; isChecked = saved.googleEnabled }
        content.addView(googleEnabled, fullWidth(12))
        val google = secretField("Google Maps Static API key", saved.googleKey)
        content.addView(google, fullWidth(5))

        val azureEnabled = CheckBox(this).apply { text = "Enable Microsoft / Azure previews"; isChecked = saved.azureEnabled }
        content.addView(azureEnabled, fullWidth(12))
        val azure = secretField("Azure Maps SAS token or subscription key", saved.azureCredential)
        content.addView(azure, fullWidth(5))
        content.addView(note("For Azure, a limited SAS token is preferable to a master subscription key."), fullWidth(5))

        content.addView(Button(this).apply {
            text = "SAVE GPS KEYS"
            TruckFitChrome.styleMapScanPrimary(this)
            setOnClickListener {
                val ok = store.write(ProviderCredentials(
                    mapboxToken = mapbox.text.toString(),
                    googleKey = google.text.toString(),
                    azureCredential = azure.text.toString(),
                    googleEnabled = googleEnabled.isChecked,
                    azureEnabled = azureEnabled.isChecked
                ))
                Toast.makeText(this@ProviderSetupActivity, if (ok) "GPS keys saved" else "Unable to save GPS keys", Toast.LENGTH_SHORT).show()
                if (ok) finish()
            }
        }, fullWidth(14))

        root.addView(ScrollView(this).apply { addView(content) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        TruckFitChrome.installMapScanSafeArea(this, root)
    }

    private fun secretField(hintText: String, value: String) = EditText(this).apply {
        hint = hintText
        setText(value)
        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        setSingleLine(true)
    }

    private fun note(textValue: String) = TextView(this).apply {
        text = textValue; textSize = 13f; setPadding(dp(10), dp(8), dp(10), dp(8)); TruckFitChrome.styleBodyText(this); TruckFitChrome.stylePanel(this)
    }
    private fun fullWidth(top: Int) = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(top) }
    private fun dp(value: Int) = (value * resources.displayMetrics.density + 0.5f).toInt()
}
