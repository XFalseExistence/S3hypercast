package hevel.truckfit.loader.ui

object SkinLibraryRules {
    const val previewWireName: String = "3D_REAR"

    fun displayName(bank: String, raw: String): String {
        val trimmed = raw.trim()
        val prefix = Regex("^${Regex.escape(bank)}\\s*(?:[•:|\\-]+\\s*)?", RegexOption.IGNORE_CASE)
        return trimmed.replace(prefix, "").trim().ifBlank { trimmed }
    }

    fun status(linked: Int, remote: Int): String = "${linked}/6 LINKED • ${remote} REMOTE"
}
