package hevel.truckfit.loader.radarfield

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import hevel.truckfit.loader.MainActivity
import hevel.truckfit.loader.R
import hevel.truckfit.loader.TruckFitChrome

object RadarFieldHeader {
    fun create(
        activity: Activity,
        title: String,
        onEyeClick: (() -> Unit)? = null,
        onMenuClick: ((ImageButton) -> Unit)? = null
    ): LinearLayout = LinearLayout(activity).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(activity, 10), dp(activity, 7), dp(activity, 14), dp(activity, 7))
        TruckFitChrome.styleMapScanHeader(this)

        val openGarage = {
            activity.startActivity(
                Intent(activity, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            )
        }

        addView(ImageView(activity).apply {
            setImageResource(R.drawable.radar_field_header_icon)
            scaleType = ImageView.ScaleType.FIT_CENTER
            isClickable = true
            contentDescription = "Switch to Garage"
            setOnClickListener { openGarage() }
        }, LinearLayout.LayoutParams(dp(activity, 52), dp(activity, 52)))

        addView(TextView(activity).apply {
            text = title
            textSize = 25f
            setTextColor(Color.BLACK)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(dp(activity, 10), 0, 0, 0)
            isClickable = true
            setOnClickListener { openGarage() }
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        if (onEyeClick != null) {
            addView(ImageButton(activity).apply {
                setImageResource(R.drawable.garage_mode_eye)
                scaleType = ImageView.ScaleType.FIT_CENTER
                setBackgroundColor(Color.TRANSPARENT)
                setPadding(dp(activity, 5), dp(activity, 8), dp(activity, 5), dp(activity, 8))
                contentDescription = "Map grid density"
                setOnClickListener {
                    // Grid density is a mode cycle, not a navigation/active state: never leave the eye highlighted.
                    isPressed = false
                    setBackgroundColor(Color.TRANSPARENT)
                    onEyeClick()
                    post { setBackgroundColor(Color.TRANSPARENT); isPressed = false }
                }
            }, LinearLayout.LayoutParams(dp(activity, 58), dp(activity, 48)))
        }

        if (onMenuClick != null) {
            addView(ImageButton(activity).apply {
                setImageResource(R.drawable.garage_menu_lines)
                scaleType = ImageView.ScaleType.FIT_CENTER
                setBackgroundColor(Color.TRANSPARENT)
                setPadding(dp(activity, 8), dp(activity, 9), dp(activity, 8), dp(activity, 9))
                contentDescription = "MapScan menu"
                setOnClickListener {
                    TruckFitChrome.flashCyan(this)
                    onMenuClick(this)
                }
            }, LinearLayout.LayoutParams(dp(activity, 58), dp(activity, 48)))
        }
    }

    private fun dp(activity: Activity, value: Int) =
        (value * activity.resources.displayMetrics.density + 0.5f).toInt()
}
