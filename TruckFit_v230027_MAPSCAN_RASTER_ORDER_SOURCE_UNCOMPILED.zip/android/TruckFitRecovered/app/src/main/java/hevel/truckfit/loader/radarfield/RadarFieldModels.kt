package hevel.truckfit.loader.radarfield

import kotlinx.serialization.Serializable

@Serializable
data class RadarFieldFolder(
    val id: String,
    val name: String,
    val order: Int = 0,
    val parentId: String? = null
)

@Serializable
data class SavedRadarField(
    val id: String,
    val displayName: String,
    val provider: String = "custom",
    val imageUri: String? = null,
    val folderId: String? = null,
    val centerLat: Double? = null,
    val centerLon: Double? = null,
    val masterWidthFt: Double = RadarFieldGeometry.masterWidthFt,
    val masterHeightFt: Double = RadarFieldGeometry.masterHeightFt,
    val northDeg: Double = 0.0,
    val defaultZoom: Double = 0.5,
    val zoomLevels: List<Double> = RadarFieldGeometry.zoomLevels,
    val cropScale: Float = 1f,
    val cropOffsetX: Float = 0f,
    val cropOffsetY: Float = 0f,
    val active: Boolean = false,
    val mapProximityEnabled: Boolean = true,
    val calibrationRevision: Int = 1,
    val order: Int = 0
)

@Serializable
data class RadarFieldLibraryEnvelope(
    val schemaVersion: Int = 1,
    val fields: List<SavedRadarField> = emptyList(),
    val folders: List<RadarFieldFolder> = emptyList()
)
