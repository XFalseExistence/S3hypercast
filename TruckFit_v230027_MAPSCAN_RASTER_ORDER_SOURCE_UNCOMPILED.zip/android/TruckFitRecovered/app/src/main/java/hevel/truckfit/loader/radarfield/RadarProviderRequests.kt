package hevel.truckfit.loader.radarfield

import java.net.URLEncoder
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.roundToInt

@Suppress("EnumEntryName")
enum class RadarProviderId(val displayName: String) {
    ESRI("ESRI / ARCGIS"),
    MAPBOX("MAPBOX SATELLITE"),
    GOOGLE("GOOGLE SATELLITE"),
    AZURE("MICROSOFT / AZURE")
}

data class ProviderCredentials(
    val mapboxToken: String = "",
    val googleKey: String = "",
    val azureCredential: String = "",
    val googleEnabled: Boolean = false,
    val azureEnabled: Boolean = false
)

data class ProviderRequest(
    val provider: RadarProviderId,
    val url: String = "",
    val headers: Map<String, String> = emptyMap(),
    val attribution: String,
    val unavailableReason: String? = null,
    val canPersist: Boolean = false
)

object RadarProviderRequests {
    fun requestFor(
        provider: RadarProviderId,
        center: GeoCenter,
        bounds: GeoBounds,
        credentials: ProviderCredentials,
        footprintFt: Double = RadarFieldGeometry.masterWidthFt
    ): ProviderRequest = when (provider) {
        RadarProviderId.ESRI -> ProviderRequest(
            provider,
            EsriTileWindow.tileTemplate,
            attribution = "Esri World Imagery • preview cache only"
        )
        RadarProviderId.MAPBOX -> credentials.mapboxToken.trim().takeIf { it.isNotEmpty() }?.let { token ->
            val bbox = "%5B${bounds.west},${bounds.south},${bounds.east},${bounds.north}%5D"
            ProviderRequest(
                provider,
                "https://api.mapbox.com/styles/v1/mapbox/satellite-v9/static/$bbox/640x640" +
                    "?access_token=${enc(token)}&attribution=true&logo=true",
                attribution = "© Mapbox • preview cache ≤30 days",
            )
        } ?: unavailable(provider, "Add a Mapbox public token in Provider Setup")
        RadarProviderId.GOOGLE -> {
            val key = credentials.googleKey.trim()
            if (!credentials.googleEnabled) unavailable(provider, "OFF by default • enable in Provider Setup")
            else if (key.isEmpty()) unavailable(provider, "Add a Google Maps Static API key")
            else {
                val (zoom, logicalPx) = googleZoomAndSize(center.lat, footprintFt)
                ProviderRequest(
                    provider,
                    "https://maps.googleapis.com/maps/api/staticmap?center=${center.lat},${center.lon}" +
                        "&zoom=$zoom&size=${logicalPx}x${logicalPx}&scale=2&maptype=satellite&key=${enc(key)}",
                    attribution = "Google • preview only"
                )
            }
        }
        RadarProviderId.AZURE -> {
            val credential = credentials.azureCredential.trim()
            if (!credentials.azureEnabled) unavailable(provider, "OFF by default • enable in Provider Setup")
            else if (credential.isEmpty()) unavailable(provider, "Add an Azure Maps key or SAS token")
            else {
                val base = "https://atlas.microsoft.com/map/static?api-version=2024-04-01" +
                    "&tilesetId=microsoft.imagery&zoom=18&bbox=${bounds.west},${bounds.south},${bounds.east},${bounds.north}&width=640&height=640&view=US"
                if (credential.startsWith("eyJ")) ProviderRequest(
                    provider, base, headers = mapOf("Authorization" to "jwt-sas $credential"), attribution = "Microsoft Azure Maps • preview only"
                ) else ProviderRequest(
                    provider, base, headers = mapOf("subscription-key" to credential), attribution = "Microsoft Azure Maps • preview only"
                )
            }
        }
    }

    fun detailRequestFor(
    provider: RadarProviderId,
    center: GeoCenter,
    credentials: ProviderCredentials
): ProviderRequest {
    val bounds = RadarFieldGeometry.boundsForFeet(center)
    return when (provider) {
        RadarProviderId.MAPBOX -> credentials.mapboxToken.trim().takeIf { it.isNotEmpty() }?.let { token ->
            val bbox = "%5B${bounds.west},${bounds.south},${bounds.east},${bounds.north}%5D"
            ProviderRequest(
                provider,
                "https://api.mapbox.com/styles/v1/mapbox/satellite-v9/static/$bbox/640x640@2x" +
                    "?padding=0&access_token=${enc(token)}&attribution=true&logo=true",
                attribution = "© Mapbox • exact-tile 80×80 ft detail • preview cache ≤30 days",
            )
        } ?: unavailable(provider, "Add a Mapbox public token in Provider Setup")
        RadarProviderId.AZURE -> {
            val credential = credentials.azureCredential.trim()
            if (!credentials.azureEnabled) unavailable(provider, "OFF by default • enable in Provider Setup")
            else if (credential.isEmpty()) unavailable(provider, "Add an Azure Maps key or SAS token")
            else {
                val base = "https://atlas.microsoft.com/map/static?api-version=2024-04-01" +
                    "&tilesetId=microsoft.imagery&bbox=${bounds.west},${bounds.south},${bounds.east},${bounds.north}&width=1280&height=1280&view=US"
                if (credential.startsWith("eyJ")) ProviderRequest(
                    provider, base, headers = mapOf("Authorization" to "jwt-sas $credential"), attribution = "Microsoft Azure Maps • locked 80×80 ft detail • preview only"
                ) else ProviderRequest(
                    provider, base, headers = mapOf("subscription-key" to credential), attribution = "Microsoft Azure Maps • locked 80×80 ft detail • preview only"
                )
            }
        }
        else -> requestFor(provider, center, bounds, credentials, RadarFieldGeometry.masterWidthFt)
    }
}

    private fun unavailable(provider: RadarProviderId, reason: String) = ProviderRequest(provider, attribution = "", unavailableReason = reason)
    private fun enc(value: String): String = URLEncoder.encode(value, Charsets.UTF_8.name())

    /** Google Static Maps uses integer zoom; choose the highest zoom whose requested square stays <= 640 logical pixels. */
    internal fun googleZoomAndSize(latitude: Double, widthFt: Double): Pair<Int, Int> {
        val targetMeters = widthFt * 0.3048
        val earthCircumference = 2.0 * PI * 6378137.0
        val cosLat = cos(latitude * PI / 180.0).coerceAtLeast(1e-6)
        for (zoom in 22 downTo 0) {
            val metersPerPixel = cosLat * earthCircumference / (256.0 * (1L shl zoom))
            val px = (targetMeters / metersPerPixel).roundToInt()
            if (px in 180..640) return zoom to px
        }
        return 20 to 640
    }
}
