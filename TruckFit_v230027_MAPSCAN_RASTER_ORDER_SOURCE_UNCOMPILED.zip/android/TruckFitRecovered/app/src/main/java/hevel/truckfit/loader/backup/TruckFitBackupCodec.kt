package hevel.truckfit.loader.backup

import hevel.truckfit.loader.skin.RecoveredLibraryEnvelope
import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.time.Instant

@Serializable
data class TruckFitBackup(
    val schemaVersion:Int=1,
    val exportedAtUtc:String,
    val library:RecoveredLibraryEnvelope,
    val radarFields:List<String> = emptyList()
)

class TruckFitBackupCodec(private val json:Json=Json { ignoreUnknownKeys=true; encodeDefaults=true; prettyPrint=true }) {
    fun encode(library:RecoveredLibraryEnvelope):String = json.encodeToString(TruckFitBackup(exportedAtUtc=Instant.now().toString(),library=library))
    fun decode(raw:String):TruckFitBackup = json.decodeFromString(raw)
}
