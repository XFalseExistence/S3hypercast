package hevel.truckfit.loader.ui

import kotlin.math.max

/** Uniform image transform used by Radar Field crop UI. X/Y are never scaled independently. */
data class CropTransform(
    val scale: Float,
    val offsetX: Float,
    val offsetY: Float
) {
    fun panBy(dx: Float, dy: Float): CropTransform = copy(offsetX = offsetX + dx, offsetY = offsetY + dy)

    fun zoomBy(factor: Float, pivotX: Float, pivotY: Float): CropTransform {
        val safeFactor = factor.coerceIn(0.25f, 4f)
        val nextScale = scale * safeFactor
        return copy(
            scale = nextScale,
            offsetX = pivotX + (offsetX - pivotX) * safeFactor,
            offsetY = pivotY + (offsetY - pivotY) * safeFactor
        )
    }

    fun clamp(imageWidth: Float, imageHeight: Float, frameWidth: Float, frameHeight: Float): CropTransform {
        val minScale = max(frameWidth / imageWidth, frameHeight / imageHeight)
        val safeScale = max(scale, minScale)
        val scaledW = imageWidth * safeScale
        val scaledH = imageHeight * safeScale
        val minX = frameWidth - scaledW
        val minY = frameHeight - scaledH
        return copy(
            scale = safeScale,
            offsetX = offsetX.coerceIn(minX, 0f),
            offsetY = offsetY.coerceIn(minY, 0f)
        )
    }

    companion object {
        fun fit(imageWidth: Float, imageHeight: Float, frameWidth: Float, frameHeight: Float): CropTransform {
            require(imageWidth > 0f && imageHeight > 0f && frameWidth > 0f && frameHeight > 0f)
            val scale = max(frameWidth / imageWidth, frameHeight / imageHeight)
            return CropTransform(
                scale = scale,
                offsetX = (frameWidth - imageWidth * scale) / 2f,
                offsetY = (frameHeight - imageHeight * scale) / 2f
            )
        }
    }
}
