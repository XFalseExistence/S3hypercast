package hevel.truckfit.loader.radarfield

import android.content.SharedPreferences
import hevel.truckfit.loader.ui.Hierarchy
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.util.UUID

class RadarFieldRepository(
    private val prefs: SharedPreferences,
    private val json: Json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
) {
    private fun read(): RadarFieldLibraryEnvelope = prefs.getString(KEY_LIBRARY, null)?.let {
        runCatching { json.decodeFromString<RadarFieldLibraryEnvelope>(it) }.getOrNull()
    } ?: RadarFieldLibraryEnvelope()

    private fun write(value: RadarFieldLibraryEnvelope): Boolean = prefs.edit().putString(KEY_LIBRARY, json.encodeToString(value)).commit()

    fun snapshot(): RadarFieldLibraryEnvelope = read()
    fun all(): List<SavedRadarField> = read().fields.sortedWith(compareBy<SavedRadarField>({ it.order }, { it.id }))
    fun fields(parentId: String?): List<SavedRadarField> = all().filter { it.folderId == parentId }
    fun folders(): List<RadarFieldFolder> = read().folders.sortedWith(compareBy<RadarFieldFolder>({ it.order }, { it.id }))
    fun folders(parentId: String?): List<RadarFieldFolder> = folders().filter { it.parentId == parentId }
    fun get(id: String): SavedRadarField? = read().fields.firstOrNull { it.id == id }

    fun createFolder(name: String, parentId: String?): RadarFieldFolder? {
        val clean = name.trim()
        if (clean.isEmpty()) return null
        val current = read()
        val validParent = parentId?.takeIf { p -> current.folders.any { it.id == p } }
        val folder = RadarFieldFolder("field-folder-${UUID.randomUUID()}", clean, current.folders.count { it.parentId == validParent }, validParent)
        return folder.takeIf { write(normalize(current.copy(folders = current.folders + folder))) }
    }

    fun moveFolder(id: String, parentId: String?): Boolean {
        val current = read()
        val parents = current.folders.associate { it.id to it.parentId }
        if (!Hierarchy.canMove(id, parentId, parents)) return false
        val valid = parentId?.takeIf { it in parents.keys }
        return write(normalize(current.copy(folders = current.folders.map { if (it.id == id) it.copy(parentId = valid) else it })))
    }

    fun save(field: SavedRadarField): Boolean {
        val current = read()
        val normalizedField = field.copy(
            id = field.id.ifBlank { "field-${UUID.randomUUID()}" },
            displayName = field.displayName.trim().ifBlank { "MapScan" },
            folderId = field.folderId?.takeIf { id -> current.folders.any { it.id == id } }
        )
        val fields = current.fields.filterNot { it.id == normalizedField.id } + normalizedField
        return write(normalize(current.copy(fields = fields)))
    }

    fun rename(id: String, displayName: String): Boolean {
        val clean = displayName.trim()
        if (clean.isEmpty()) return false
        val current = read()
        if (current.fields.none { it.id == id }) return false
        return write(normalize(current.copy(fields = current.fields.map { if (it.id == id) it.copy(displayName = clean) else it })))
    }

    fun moveField(id: String, folderId: String?): Boolean {
        val current = read()
        if (folderId != null && current.folders.none { it.id == folderId }) return false
        return write(normalize(current.copy(fields = current.fields.map { if (it.id == id) it.copy(folderId = folderId) else it })))
    }

    fun setActive(id: String): Boolean {
        val current = read()
        if (current.fields.none { it.id == id }) return false
        return write(normalize(current.copy(fields = current.fields.map { it.copy(active = it.id == id) })))
    }

    fun useDefault(): Boolean {
        val current = read()
        return write(normalize(current.copy(fields = current.fields.map { it.copy(active = false) })))
    }

    fun setMapProximity(id: String, enabled: Boolean): Boolean {
        val current = read()
        if (current.fields.none { it.id == id }) return false
        return write(normalize(current.copy(fields = current.fields.map { if (it.id == id) it.copy(mapProximityEnabled = enabled, calibrationRevision = it.calibrationRevision + 1) else it })))
    }

    fun delete(id: String): Boolean {
        val current = read()
        if (current.fields.none { it.id == id }) return false
        return write(normalize(current.copy(fields = current.fields.filterNot { it.id == id })))
    }

    private fun normalize(value: RadarFieldLibraryEnvelope): RadarFieldLibraryEnvelope {
        val distinctFolders = value.folders.distinctBy { it.id }
        val ids = distinctFolders.map { it.id }.toSet()
        val parents = distinctFolders.associate { it.id to it.parentId?.takeIf { p -> p in ids && p != it.id } }.toMutableMap()
        distinctFolders.forEach { folder -> if (!Hierarchy.canMove(folder.id, parents[folder.id], parents)) parents[folder.id] = null }
        val folders = distinctFolders.map { it.copy(parentId = parents[it.id]) }
        val validIds = folders.map { it.id }.toSet()
        val fields = value.fields.distinctBy { it.id }.mapIndexed { index, field ->
            field.copy(
                order = index,
                folderId = field.folderId?.takeIf { it in validIds },
                masterWidthFt = field.masterWidthFt.takeIf { it > 0.0 } ?: RadarFieldGeometry.masterWidthFt,
                masterHeightFt = field.masterHeightFt.takeIf { it > 0.0 } ?: RadarFieldGeometry.masterHeightFt,
                zoomLevels = field.zoomLevels.ifEmpty { RadarFieldGeometry.zoomLevels },
                calibrationRevision = field.calibrationRevision.coerceAtLeast(1)
            )
        }
        return RadarFieldLibraryEnvelope(1, fields, folders)
    }

    companion object {
        const val PREFS_NAME = "truckfit_radar_fields_v1"
        private const val KEY_LIBRARY = "radar_field_library_json"
    }
}
