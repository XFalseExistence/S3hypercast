package hevel.truckfit.loader

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import hevel.truckfit.loader.backup.TruckFitBackupCodec
import hevel.truckfit.loader.recovery.RecoveryActivity
import hevel.truckfit.loader.skin.*
import hevel.truckfit.loader.ui.SkinLibraryRules
import hevel.truckfit.loader.transfer.S3SyncManager
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    private val repo by lazy { AppServices.repository(this) }
    private var currentFolderId: String? = null
    private lateinit var content: LinearLayout
    private lateinit var footer: TextView
    private var garageColumns: Int = 2

    private val createBackup = registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            runCatching {
                contentResolver.openOutputStream(uri)?.bufferedWriter()?.use {
                    it.write(TruckFitBackupCodec().encode(repo.snapshot()))
                }
            }.onSuccess { setFooter("Library backup exported") }
                .onFailure { setFooter("Backup failed: ${it.message}") }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        currentFolderId = savedInstanceState?.getString("folder_id")
        garageColumns = getSharedPreferences("garage_view", MODE_PRIVATE)
            .getInt("columns", 2)
            .takeIf { it in setOf(2, 4, 8) } ?: 2
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (currentFolderId != null) goUp()
                else { isEnabled = false; onBackPressedDispatcher.onBackPressed() }
            }
        })
        buildChrome()
        VehicleImageMigration.start(this, repo) { changed, failed ->
            if (changed > 0 || failed > 0) {
                setFooter("Auto-trim centered $changed skin views" + if (failed > 0) " • $failed need attention" else " • Sync to refresh S3")
                renderSkins()
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("folder_id", currentFolderId)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        HotspotConnector.onPermissionResult(this, requestCode, grantResults) { setFooter(it) }
    }

    override fun onResume() {
        super.onResume()
        renderSkins()
    }

    private fun buildChrome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            TruckFitChrome.styleLibraryScreen(this)
        }

        val title = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(8), dp(14), dp(8))
            TruckFitChrome.styleHeader(this)
        }
        title.addView(ImageView(this).apply {
            setImageResource(R.drawable.truckfit_launcher_art)
            scaleType = ImageView.ScaleType.FIT_CENTER
            isClickable = true
            contentDescription = "Switch to MapScan"
            setOnClickListener { openRadarFields() }
        }, LinearLayout.LayoutParams(dp(48), dp(48)))
        title.addView(TextView(this).apply {
            text = "TruckFit"
            textSize = 28f
            setTextColor(Color.WHITE)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(dp(10), 0, 0, 0)
            isClickable = true
            setOnClickListener { openRadarFields() }
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        title.addView(ImageButton(this).apply {
            setImageResource(R.drawable.garage_mode_eye)
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(Color.TRANSPARENT)
            setPadding(dp(5), dp(8), dp(5), dp(8))
            contentDescription = "Garage view mode"
            setOnClickListener { TruckFitChrome.flashCyan(this); showGarageViewMode(this) }
        }, LinearLayout.LayoutParams(dp(58), dp(48)))
        title.addView(ImageButton(this).apply {
    setImageResource(R.drawable.garage_menu_lines)
    scaleType = ImageView.ScaleType.FIT_CENTER
    setBackgroundColor(Color.TRANSPARENT)
    setPadding(dp(8), dp(9), dp(8), dp(9))
    contentDescription = "Garage menu"
    setOnClickListener { TruckFitChrome.flashCyan(this); showGarageMenu(this) }
}, LinearLayout.LayoutParams(dp(58), dp(48)))
root.addView(title)

        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(16))
        }
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            addView(content)
        }
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        footer = TextView(this).apply {
            textSize = 12f
            setPadding(dp(12), dp(8), dp(12), dp(8))
            TruckFitChrome.styleBodyText(this)
            TruckFitChrome.stylePanel(this)
        }
        root.addView(footer, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            setMargins(dp(8), 0, dp(8), dp(8))
        })

        setContentView(root)
        TruckFitChrome.installSafeArea(this, root)
    }

    private fun showGarageViewMode(anchor: ImageButton) {
    PopupMenu(this, anchor).apply {
        listOf(2, 4, 8).forEach { columns ->
            val marker = if (garageColumns == columns) " ✓" else ""
            menu.add("$columns PER ROW$marker").setOnMenuItemClickListener {
                garageColumns = columns
                getSharedPreferences("garage_view", MODE_PRIVATE).edit().putInt("columns", columns).apply()
                renderSkins()
                true
            }
        }
        show()
    }
}

private fun showGarageMenu(anchor: ImageButton) {
    val menuColumn = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(10), dp(10), dp(10), dp(10))
        TruckFitChrome.stylePanel(this)
    }
    lateinit var popup: PopupWindow
    fun action(label: String, run: () -> Unit) {
        menuColumn.addView(Button(this).apply {
            text = label
            textSize = 12f
            minHeight = dp(46)
            TruckFitChrome.styleSecondary(this)
            setOnClickListener { popup.dismiss(); run() }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(3); bottomMargin = dp(3)
        })
    }
    fun groupGap() { menuColumn.addView(Space(this), LinearLayout.LayoutParams(1, dp(14))) }

    action("MAIN") { currentFolderId = null; renderSkins() }
    if (currentFolderId != null) action("UP ONE FOLDER") { goUp() }
    action("ADD VEHICLE") { createVehicleDialog() }
    action("NEW FOLDER") { createFolderDialog() }
    action("ORGANIZE") { startActivity(Intent(this, SkinOrganizerActivity::class.java)) }

    groupGap()
    action("Import") { startActivity(Intent(this, RecoveryActivity::class.java)) }
    action("Export") { createBackup.launch("TruckFit-Library-Backup.json") }
    action("Hotspot") { openHotspotPanel() }
    action("Sync") { syncGarageToS3() }

    groupGap()
    action("MapScan") { openRadarFields() }

    groupGap()
    action("Complete") { completeSession() }

    val scroll = ScrollView(this).apply { addView(menuColumn) }
    popup = PopupWindow(scroll, dp(318), ViewGroup.LayoutParams.WRAP_CONTENT, true).apply {
        isOutsideTouchable = true
        setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        elevation = dp(12).toFloat()
    }
    popup.showAsDropDown(anchor, -dp(260), dp(4))
}

    private fun openHotspotPanel() {
        HotspotConnector.connect(this) { setFooter(it) }
    }

    private fun openRadarFields() {
        startActivity(Intent().setClassName(packageName, "hevel.truckfit.loader.radarfield.RadarFieldLibraryActivity"))
    }

    private fun goUp() {
        val current = repo.folders().firstOrNull { it.id == currentFolderId }
        currentFolderId = current?.parentId
        renderSkins()
    }

    private fun createVehicleDialog() {
        val input = EditText(this).apply { hint = "Vehicle / collection name" }
        AlertDialog.Builder(this)
            .setTitle("Add vehicle")
            .setView(input)
            .setNegativeButton("CANCEL", null)
            .setPositiveButton("CREATE") { _, _ ->
                val created = repo.createVehicle(input.text.toString(), currentFolderId)
                if (created != null) {
                    setFooter("Created ${created.name}")
                    startActivity(Intent(this, SkinEditorActivity::class.java).putExtra("skin_id", created.id))
                } else {
                    setFooter("Vehicle name required")
                }
            }.show()
    }

    private fun createFolderDialog() {
        val input = EditText(this).apply { hint = "Folder name" }
        AlertDialog.Builder(this)
            .setTitle("New Garage folder")
            .setView(input)
            .setNegativeButton("CANCEL", null)
            .setPositiveButton("CREATE") { _, _ ->
                val created = repo.createFolder(input.text.toString(), currentFolderId)
                setFooter(if (created != null) "Created ${created.name}" else "Folder name required")
                renderSkins()
            }.show()
    }

    private fun renderSkins() {
        if (!::content.isInitialized) return
        if (currentFolderId != null && repo.folders().none { it.id == currentFolderId }) currentFolderId = null
        content.removeAllViews()

        content.addView(TextView(this).apply {
            text = breadcrumb()
            gravity = Gravity.CENTER
            textSize = 15f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(dp(10), dp(8), dp(10), dp(8))
            TruckFitChrome.styleBodyText(this)
            TruckFitChrome.stylePanel(this)
        })

        val directPacks = repo.packs(currentFolderId)
        renderPackGrid(directPacks, depth = 0, top = 10)
        repo.folders(currentFolderId).forEach { folder -> renderExpandedFolder(folder, depth = 0) }

        if (directPacks.isEmpty() && repo.folders(currentFolderId).isEmpty()) {
            content.addView(TextView(this).apply {
                text = "No Garage items here. Open the menu to create a folder or recover/import."
                textSize = 15f
                setPadding(dp(14), dp(18), dp(14), dp(18))
                TruckFitChrome.styleBodyText(this)
                TruckFitChrome.stylePanel(this)
            }, fullWidth(top = 10))
        }
        setFooter("${repo.all().size} Garage items • ${repo.folders().size} folders • $garageColumns per row • tap opens 6 POVs • hold opens vehicle menu")
    }

    private fun renderExpandedFolder(folder: SkinFolder, depth: Int) {
        content.addView(Button(this).apply {
            text = "▼  ${folder.name}"
            gravity = Gravity.START or Gravity.CENTER_VERTICAL
            TruckFitChrome.styleSecondary(this)
            setPadding(dp(12 + depth * 12), paddingTop, paddingRight, paddingBottom)
            setOnClickListener { currentFolderId = folder.id; renderSkins() }
        }, fullWidth(top = 8))
        renderPackGrid(repo.packs(folder.id), depth = depth + 1, top = 6)
        repo.folders(folder.id).forEach { child -> renderExpandedFolder(child, depth + 1) }
    }

    private fun renderPackGrid(packs: List<RecoveredSkinPack>, depth: Int, top: Int) {
        if (packs.isEmpty()) return
        packs.chunked(garageColumns).forEachIndexed { rowIndex, chunk ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(dp(depth * 8), 0, 0, 0)
            }
            chunk.forEach { pack ->
                row.addView(
                    skinCard(pack),
                    LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                        marginStart = dp(2)
                        marginEnd = dp(2)
                    }
                )
            }
            repeat(garageColumns - chunk.size) {
                row.addView(Space(this), LinearLayout.LayoutParams(0, 1, 1f))
            }
            content.addView(row, fullWidth(top = if (rowIndex == 0) top else 4))
        }
    }

    private fun skinCard(pack: RecoveredSkinPack): LinearLayout {
        val previewHeight = when (garageColumns) {
            2 -> 150
            4 -> 92
            else -> 52
        }
        val titleSize = when (garageColumns) {
            2 -> 16f
            4 -> 11f
            else -> 8f
        }
        val cardPad = if (garageColumns >= 8) 2 else 4
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            isClickable = true
            isFocusable = true
            setPadding(dp(cardPad), dp(cardPad), dp(cardPad), dp(cardPad + 1))
            if (pack.linkedToS3) TruckFitChrome.stylePanel(this) else setBackgroundColor(Color.BLACK)
        }
        val previewSlot = pack.slots[SkinSlot.REAR_3D]
        val frame = FrameLayout(this).apply { setBackgroundColor(0xFF202020.toInt()) }
        val image = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = false
            setBackgroundColor(0xFF202020.toInt())
        }
        frame.addView(image, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(previewHeight)))
        val placeholder = TextView(this).apply {
            text = "3D SOUTH${if (previewSlot?.localUri == null) " • SOURCE NOT LINKED" else ""}"
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            textSize = if (garageColumns >= 8) 7f else 10f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        frame.addView(placeholder, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(previewHeight)))
        previewSlot?.localUri?.let { raw ->
            runCatching { image.setImageURI(Uri.parse(raw)); placeholder.visibility = android.view.View.GONE }
        }
        card.addView(frame)
        card.addView(TextView(this).apply {
            text = SkinLibraryRules.displayName(pack.bank.name, pack.name)
            textSize = titleSize
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(dp(cardPad), dp(cardPad), dp(cardPad), 0)
            setSingleLine(true)
            maxLines = 1
            setAutoSizeTextTypeUniformWithConfiguration(6, titleSize.toInt().coerceAtLeast(7), 1, android.util.TypedValue.COMPLEX_UNIT_SP)
            if (pack.linkedToS3) TruckFitChrome.styleBodyText(this) else setTextColor(Color.WHITE)
        })
        card.setOnClickListener {
            startActivity(Intent(this, SkinEditorActivity::class.java).putExtra("skin_id", pack.id))
        }
        card.setOnLongClickListener {
            showVehicleMenu(card, pack)
            true
        }
        return card
    }

    private fun showVehicleMenu(anchor: android.view.View, pack: RecoveredSkinPack) {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(10), dp(10), dp(10))
            TruckFitChrome.stylePanel(this)
        }
        lateinit var popup: PopupWindow
        fun action(label: String, run: () -> Unit): Button {
            val button = Button(this).apply {
                text = label
                textSize = 12f
                minHeight = dp(46)
                TruckFitChrome.styleSecondary(this)
                setOnClickListener { run() }
            }
            panel.addView(button, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(3); bottomMargin = dp(3)
            })
            return button
        }

        action("ACTIVATE") {
            popup.dismiss()
            activate(pack)
        }
        action(if (pack.linkedToS3) "UNLINK" else "LINK") {
            popup.dismiss()
            if (pack.linkedToS3) unlinkFromS3(pack) else linkToS3(pack)
        }
        action("RENAME") {
            popup.dismiss()
            renameVehicle(pack)
        }
        val deleteButton = action("DELETE") { }
        var deleteArmed = false
        deleteButton.setOnClickListener {
            if (!deleteArmed) {
                deleteArmed = true
                deleteButton.text = "DELETE? TAP AGAIN TO CONFIRM"
                setFooter("Delete armed for " + SkinLibraryRules.displayName(pack.bank.name, pack.name) + " • tap DELETE again to confirm")
            } else {
                popup.dismiss()
                if (repo.deletePack(pack.id)) {
                    setFooter("Deleted local collection: " + SkinLibraryRules.displayName(pack.bank.name, pack.name))
                    renderSkins()
                } else setFooter("Delete failed")
            }
        }

        popup = PopupWindow(panel, dp(260), ViewGroup.LayoutParams.WRAP_CONTENT, true).apply {
            isOutsideTouchable = true
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            elevation = dp(12).toFloat()
        }
        panel.measure(android.view.View.MeasureSpec.UNSPECIFIED, android.view.View.MeasureSpec.UNSPECIFIED)
        val popupHeight = panel.measuredHeight
        val location = IntArray(2).also { anchor.getLocationOnScreen(it) }
        val screenHeight = resources.displayMetrics.heightPixels
        val openAbove = location[1] + anchor.height + popupHeight + dp(8) > screenHeight
        val yOffset = if (openAbove) -(anchor.height + popupHeight + dp(2)) else dp(2)
        popup.showAsDropDown(anchor, 0, yOffset)
    }

    private fun renameVehicle(pack: RecoveredSkinPack) {
        val input = EditText(this).apply {
            setText(SkinLibraryRules.displayName(pack.bank.name, pack.name))
            selectAll()
        }
        AlertDialog.Builder(this)
            .setTitle("Rename vehicle")
            .setView(input)
            .setNegativeButton("CANCEL", null)
            .setPositiveButton("RENAME") { _, _ ->
                if (repo.rename(pack.id, input.text.toString())) {
                    setFooter("Renamed to " + input.text.toString().trim())
                    renderSkins()
                } else setFooter("Rename failed")
            }.show()
    }

    private fun unlinkFromS3(pack: RecoveredSkinPack) = lifecycleScope.launch {
        val result = S3SyncManager(this@MainActivity).unlink(pack.id)
        setFooter(result.message)
        renderSkins()
    }

    private fun linkToS3(pack: RecoveredSkinPack) = lifecycleScope.launch {
        val result = S3SyncManager(this@MainActivity).link(pack.id)
        setFooter(result.message)
        renderSkins()
    }

    private fun syncGarageToS3() = lifecycleScope.launch {
        setFooter("Checking S3 loader…")
        val manager = S3SyncManager(this@MainActivity)
        val status = manager.status()
        if (!status.successful) {
            setFooter(status.message + " • connect HOTSPOT first and leave LOAD enabled on S3")
            return@launch
        }
        val result = manager.syncAll { msg -> setFooter(msg) }
        if (!result.successful) {
            setFooter(result.message)
            renderSkins()
            return@launch
        }
        val mapResult = hevel.truckfit.loader.transfer.RadarMapSyncManager(this@MainActivity).syncAll { msg -> setFooter(msg) }
        setFooter(result.message + " • " + mapResult.message)
        renderSkins()
    }

    private fun activate(pack: RecoveredSkinPack) = lifecycleScope.launch {
        if (!pack.linkedToS3) {
            setFooter("Unlinked vehicle • removing it from S3…")
            val result = S3SyncManager(this@MainActivity).syncOne(pack.id)
            setFooter(result.message)
            renderSkins()
            return@launch
        }
        setFooter("Activating ${SkinLibraryRules.displayName(pack.bank.name, pack.name)}…")
        runCatching { AppServices.api().activateSkin(pack.id, pack.bank.name) }
            .onSuccess { r -> setFooter(if (r.successful) "Active: ${SkinLibraryRules.displayName(pack.bank.name, pack.name)}" else "Activate failed HTTP ${r.code}") }
            .onFailure { setFooter("Activate failed: ${it.message}") }
    }

    private fun completeSession() = lifecycleScope.launch {
        setFooter("Completing TruckFit session • resetting S3…")
        runCatching { AppServices.api().exitLoader() }
            .onSuccess { r -> setFooter(if (r.successful) "S3 reset requested • closing TruckFit" else "S3 reset returned HTTP ${r.code} • closing TruckFit") }
            .onFailure { setFooter("S3 reset request failed: ${it.message} • closing TruckFit") }
        HotspotConnector.release(this@MainActivity)
        finishAndRemoveTask()
    }

    private fun breadcrumb(): String {
        val byId = repo.folders().associateBy { it.id }
        val names = mutableListOf<String>()
        val seen = mutableSetOf<String>()
        var cursor = currentFolderId
        while (cursor != null && seen.add(cursor)) {
            val folder = byId[cursor] ?: break
            names += folder.name
            cursor = folder.parentId
        }
        return if (names.isEmpty()) "GARAGE/MAIN" else "GARAGE/MAIN / " + names.asReversed().joinToString(" / ")
    }

    private fun setFooter(text: String) { if (::footer.isInitialized) footer.text = text }
    private fun fullWidth(top: Int = 0) = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(top) }
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()
}
