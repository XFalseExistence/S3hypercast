package hevel.truckfit.loader.transfer

import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import hevel.truckfit.loader.AppServices
import hevel.truckfit.loader.radarfield.RadarFieldGeometry
import hevel.truckfit.loader.radarfield.SavedRadarField
import kotlinx.coroutines.delay
import kotlinx.serialization.json.*
import java.security.MessageDigest
import java.util.Locale
import java.util.zip.CRC32

data class RadarMapSyncResult(
    val successful: Boolean,
    val message: String,
    val uploadedImages: Int = 0,
    val updatedManifests: Int = 0,
    val deletedRemote: Int = 0
)

/**
 * v230024 map reconciler.
 * TruckFit keeps the archival 1024×1024 JPEG and also sends an RGB565LE render master
 * that W412 can draw directly from PSRAM. Calibration-only edits keep both image payloads intact.
 */
class RadarMapSyncManager(private val context: Context) {
    private val repo = AppServices.radarFields(context)
    private val api = AppServices.api()
    private val json = Json { ignoreUnknownKeys = true }

    suspend fun status(): RadarMapSyncResult = runCatching {
        val r = api.mapStatus()
        if (r.successful) RadarMapSyncResult(true, "S3 map catalog reachable")
        else RadarMapSyncResult(false, "S3 map API HTTP ${r.code}")
    }.getOrElse { RadarMapSyncResult(false, "S3 map API unavailable: ${it.message}") }

    suspend fun syncOne(fieldId: String, activate: Boolean = false): RadarMapSyncResult {
        val field = repo.get(fieldId) ?: return RadarMapSyncResult(false, "Map no longer exists")
        return runCatching {
            val result = reconcileField(field)
            check(postIndex()) { "S3 map index update failed" }
            if (activate || field.active) {
                val active = api.activateMap(field.id)
                check(active.successful) { "S3 map activation HTTP ${active.code}: ${active.body}" }
            }
            RadarMapSyncResult(
                true,
                "Map synced • ${field.displayName} • ${if (result.image) "JPEG + " else ""}${if (result.raster) "S3 raster + " else ""}cal R${field.calibrationRevision}" +
                    if (activate || field.active) " • ACTIVE" else "",
                uploadedImages = if (result.image || result.raster) 1 else 0,
                updatedManifests = if (result.manifest) 1 else 0
            )
        }.getOrElse { RadarMapSyncResult(false, "Map sync failed: ${it.message}") }
    }

    suspend fun syncAll(onProgress: (String) -> Unit = {}): RadarMapSyncResult {
        val fields = repo.all()
        return runCatching {
            val remoteIds = fetchRemoteIds()
            val localIds = fields.map { it.id }.toSet()
            var deleted = 0
            remoteIds.filter { it !in localIds }.forEachIndexed { index, id ->
                onProgress("Removing old S3 map ${index + 1}/${remoteIds.count { it !in localIds }}…")
                val r = api.deleteRemoteMap(id)
                check(r.successful || r.code == 404) { "map delete $id HTTP ${r.code}" }
                deleted++
            }

            var images = 0
            var manifests = 0
            fields.forEachIndexed { index, field ->
                onProgress("Syncing map ${index + 1}/${fields.size}: ${field.displayName}…")
                val changed = reconcileField(field)
                if (changed.image || changed.raster) images++
                if (changed.manifest) manifests++
            }
            check(postIndex()) { "S3 map index update failed" }

            val selected = fields.firstOrNull { it.active }
            if (selected != null) {
                onProgress("Activating map: ${selected.displayName}…")
                val r = api.activateMap(selected.id)
                check(r.successful) { "map activation HTTP ${r.code}: ${r.body}" }
            } else {
                val r = api.setDefaultMap()
                check(r.successful) { "DEFAULT map HTTP ${r.code}: ${r.body}" }
            }

            RadarMapSyncResult(
                true,
                "MapScan sync complete • ${fields.size} field(s) • $images image(s) • $manifests calibration manifest(s) • $deleted removed • active ${selected?.displayName ?: "DEFAULT"}",
                images, manifests, deleted
            )
        }.getOrElse { RadarMapSyncResult(false, "MapScan sync failed: ${it.message}") }
    }

    private data class FieldChange(val image: Boolean, val raster: Boolean, val manifest: Boolean)

    private suspend fun reconcileField(field: SavedRadarField): FieldChange {
        val local = localAsset(field)
        val remote = remoteManifest(field.id)
        val remoteSha = remote?.get("imageSha256")?.jsonPrimitive?.contentOrNull
        val remoteRasterSha = remote?.get("rasterSha256")?.jsonPrimitive?.contentOrNull
        val remoteRev = remote?.get("calibrationRevision")?.jsonPrimitive?.intOrNull
        val imageChanged = remoteSha == null || !remoteSha.equals(local.sha256, ignoreCase = true)
        val rasterChanged = remoteRasterSha == null || !remoteRasterSha.equals(local.rasterSha256, ignoreCase = true)
        val manifestChanged = imageChanged || rasterChanged || remoteRev != field.calibrationRevision

        // W418Q: Firmware requires a complete staged JPEG + RGB565 raster pair
        // BEFORE any manifest can promote it. Never post an intermediate manifest.
        if (imageChanged) uploadImageVerified(field, local)
        if (imageChanged || rasterChanged) uploadRasterVerified(field, local)
        if (manifestChanged) postManifestWithRetry(field.id, manifestJson(field, local, includeRaster = true))
        return FieldChange(imageChanged, rasterChanged, manifestChanged)
    }

    private suspend fun postManifestWithRetry(id: String, payload: String) {
        var lastResponse: hevel.truckfit.loader.hevel.HevelResponse? = null
        var lastFailure: Throwable? = null
        for (attempt in 0..1) {
            val result = runCatching { api.postMapManifest(id, payload) }
            lastResponse = result.getOrNull()
            lastFailure = result.exceptionOrNull()
            if (lastResponse?.successful == true) return
            if (attempt == 0) delay(180)
        }
        val r = lastResponse
        if (r != null) error("manifest HTTP ${r.code}: ${r.body}")
        error("manifest transport failed: ${lastFailure?.message ?: "unknown"}")
    }

    suspend fun useDefault(): RadarMapSyncResult = runCatching {
        check(repo.useDefault()) { "Unable to clear local active map" }
        val r = api.setDefaultMap()
        check(r.successful) { "DEFAULT map HTTP ${r.code}: ${r.body}" }
        RadarMapSyncResult(true, "DEFAULT active • onboard 5 / 10 / 20 ft rings")
    }.getOrElse { RadarMapSyncResult(false, "Map deactivation failed: ${it.message}") }

    private suspend fun uploadImageVerified(field: SavedRadarField, local: LocalMapAsset) {
        var lastFailure: Throwable? = null
        repeat(3) { attempt ->
            val upload = runCatching { api.uploadMapImage(field.id, local.bytes) }
            val response = upload.getOrNull()
            if (response?.successful == true) return
            lastFailure = upload.exceptionOrNull() ?: IllegalStateException("image upload HTTP ${response?.code}: ${response?.body}")

            // W411 can prove that the whole staged JPEG arrived even when Android lost the
            // tiny response while the S3 closed its one-shot HTTP connection.
            val stage = runCatching { api.mapStage(field.id) }.getOrNull()
            if (stage?.successful == true && stagedAssetMatches(stage.body, local)) return
            if (attempt < 2) delay(220L * (attempt + 1))
        }
        val status = runCatching { api.mapStatus() }.getOrNull()?.body.orEmpty()
        error("image upload transport failed: ${lastFailure?.message ?: "unknown"}" + if (status.isNotBlank()) " • S3 $status" else "")
    }

    private suspend fun uploadRasterVerified(field: SavedRadarField, local: LocalMapAsset) {
        var lastFailure: Throwable? = null
        repeat(3) { attempt ->
            val upload = runCatching { api.uploadMapRaster(field.id, local.rasterBytes) }
            val response = upload.getOrNull()
            if (response?.successful == true) return
            lastFailure = upload.exceptionOrNull() ?: IllegalStateException("raster upload HTTP ${response?.code}: ${response?.body}")
            val remote = runCatching { api.mapRasterStatus(field.id) }.getOrNull()
            if (remote?.successful == true && rasterStatusMatches(remote.body, local)) return
            if (attempt < 2) delay(260L * (attempt + 1))
        }
        error("S3 render-raster upload failed: ${lastFailure?.message ?: "unknown"}")
    }

    private fun rasterStatusMatches(body: String, local: LocalMapAsset): Boolean = runCatching {
        val root = json.parseToJsonElement(body).jsonObject
        root["present"]?.jsonPrimitive?.booleanOrNull == true &&
            root["rasterBytes"]?.jsonPrimitive?.longOrNull == local.rasterBytes.size.toLong() &&
            root["rasterCrc32"]?.jsonPrimitive?.contentOrNull.equals(local.rasterCrc32, ignoreCase = true)
    }.getOrDefault(false)

    private fun stagedAssetMatches(body: String, local: LocalMapAsset): Boolean = runCatching {
        val root = json.parseToJsonElement(body).jsonObject
        root["staged"]?.jsonPrimitive?.booleanOrNull == true &&
            root["imageBytes"]?.jsonPrimitive?.longOrNull == local.bytes.size.toLong() &&
            root["imageCrc32"]?.jsonPrimitive?.contentOrNull.equals(local.crc32, ignoreCase = true) &&
            root["imageWidthPx"]?.jsonPrimitive?.intOrNull == local.width &&
            root["imageHeightPx"]?.jsonPrimitive?.intOrNull == local.height
    }.getOrDefault(false)

    private data class LocalMapAsset(
        val bytes: ByteArray,
        val sha256: String,
        val crc32: String,
        val width: Int,
        val height: Int,
        val rasterBytes: ByteArray,
        val rasterSha256: String,
        val rasterCrc32: String
    )

    private fun localAsset(field: SavedRadarField): LocalMapAsset {
        val raw = field.imageUri ?: error("${field.displayName} has no saved image")
        val uri = Uri.parse(raw)
        val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            ?: error("Unable to read ${field.displayName} image")
        require(bytes.isNotEmpty()) { "${field.displayName} image is empty" }

        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
        require(opts.outWidth > 0 && opts.outHeight > 0) { "${field.displayName} is not a valid image" }
        // TruckFit's saved master contract is square. Physical scale remains metadata-driven at 80×80 ft.
        require(opts.outWidth == opts.outHeight) { "${field.displayName} master must be square" }

        val digest = MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it.toInt() and 0xff) }
        val crc = CRC32().apply { update(bytes) }.value
        val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            ?: error("Unable to decode ${field.displayName} for S3 raster")
        val raster = ByteArray(bitmap.width * bitmap.height * 2)
        val row = IntArray(bitmap.width)
        var out = 0
        for (y in 0 until bitmap.height) {
            bitmap.getPixels(row, 0, bitmap.width, 0, y, bitmap.width, 1)
            for (argb in row) {
                val r = (argb ushr 19) and 0x1f
                val g = (argb ushr 10) and 0x3f
                val b = (argb ushr 3) and 0x1f
                val rgb565 = (r shl 11) or (g shl 5) or b
                raster[out++] = (rgb565 and 0xff).toByte()
                raster[out++] = ((rgb565 ushr 8) and 0xff).toByte()
            }
        }
        bitmap.recycle()
        val rasterDigest = MessageDigest.getInstance("SHA-256").digest(raster).joinToString("") { "%02x".format(it.toInt() and 0xff) }
        val rasterCrc = CRC32().apply { update(raster) }.value
        return LocalMapAsset(
            bytes = bytes,
            sha256 = digest,
            crc32 = String.format(Locale.US, "%08x", crc),
            width = opts.outWidth,
            height = opts.outHeight,
            rasterBytes = raster,
            rasterSha256 = rasterDigest,
            rasterCrc32 = String.format(Locale.US, "%08x", rasterCrc)
        )
    }

    private fun manifestJson(field: SavedRadarField, asset: LocalMapAsset, includeRaster: Boolean): String = buildJsonObject {
        put("schemaVersion", 1)
        put("id", field.id)
        put("displayName", field.displayName)
        put("provider", field.provider)
        field.centerLat?.let { put("centerLat", it) }
        field.centerLon?.let { put("centerLon", it) }
        put("masterWidthFt", RadarFieldGeometry.masterWidthFt)
        put("masterHeightFt", RadarFieldGeometry.masterHeightFt)
        put("proximityWidthFt", RadarFieldGeometry.sensorEnvelopeLengthFt)
        put("proximityHeightFt", RadarFieldGeometry.sensorEnvelopeWidthFt)
        put("proximityCornerRadiusFt", RadarFieldGeometry.proximityCornerRadiusFt)
        put("northDeg", field.northDeg)
        put("defaultZoom", field.defaultZoom)
        putJsonArray("zoomLevels") { field.zoomLevels.forEach { add(JsonPrimitive(it)) } }
        put("imageWidthPx", asset.width)
        put("imageHeightPx", asset.height)
        put("imageBytes", asset.bytes.size)
        put("imageSha256", asset.sha256)
        put("imageCrc32", asset.crc32)
        if (includeRaster) {
            put("rasterFormat", "RGB565LE")
            put("rasterBytes", asset.rasterBytes.size)
            put("rasterSha256", asset.rasterSha256)
            put("rasterCrc32", asset.rasterCrc32)
        }
        put("cropScale", field.cropScale)
        put("cropOffsetX", field.cropOffsetX)
        put("cropOffsetY", field.cropOffsetY)
        put("mapProximityEnabled", field.mapProximityEnabled)
        put("calibrationRevision", field.calibrationRevision)
    }.toString()

    private suspend fun remoteManifest(id: String): JsonObject? {
        val r = api.mapManifest(id)
        if (r.code == 404) return null
        check(r.successful) { "map manifest $id HTTP ${r.code}" }
        return runCatching { json.parseToJsonElement(r.body).jsonObject }
            .getOrElse { error("S3 map manifest malformed for $id") }
    }

    private suspend fun fetchRemoteIds(): Set<String> {
        val r = api.mapIndex()
        if (r.code == 404) return emptySet()
        check(r.successful) { "S3 map index HTTP ${r.code}" }
        val root = runCatching { json.parseToJsonElement(r.body).jsonObject }.getOrElse { return emptySet() }
        return (root["maps"] as? JsonArray).orEmpty().mapNotNull { element ->
            when (element) {
                is JsonPrimitive -> element.contentOrNull
                is JsonObject -> element["id"]?.jsonPrimitive?.contentOrNull
                else -> null
            }
        }.toSet()
    }

    private suspend fun postIndex(): Boolean {
        val fields = repo.all()
        val body = buildJsonObject {
            put("schema", 1)
            putJsonArray("maps") {
                fields.forEach { field ->
                    add(buildJsonObject {
                        put("id", field.id)
                        put("name", field.displayName)
                        put("order", field.order)
                        put("active", field.active)
                        put("mapProximityEnabled", field.mapProximityEnabled)
                        put("calibrationRevision", field.calibrationRevision)
                    })
                }
            }
        }.toString()
        return api.postMapIndex(body).successful
    }
}
