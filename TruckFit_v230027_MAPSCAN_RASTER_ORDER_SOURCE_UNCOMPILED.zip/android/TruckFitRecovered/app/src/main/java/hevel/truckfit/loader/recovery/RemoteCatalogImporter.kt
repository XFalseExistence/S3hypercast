package hevel.truckfit.loader.recovery

import hevel.truckfit.loader.hevel.RecoveryReadApi
import hevel.truckfit.loader.skin.*
import kotlinx.serialization.json.*
import java.security.MessageDigest


data class RecoveryImportResult(
    val packs:List<RecoveredSkinPack>,
    val folders:List<SkinFolder>,
    val warnings:List<String>
)

class RemoteCatalogImporter(
    private val api:RecoveryReadApi,
    private val repository:SkinRepository,
    private val json:Json=Json { ignoreUnknownKeys=true }
) {
    suspend fun import():RecoveryImportResult {
        val indexResp=api.skinIndex()
        require(indexResp.successful) { "HEVEL index HTTP ${indexResp.code}" }
        val root=runCatching { json.parseToJsonElement(indexResp.body).jsonObject }.getOrElse { throw IllegalArgumentException("Malformed HEVEL Garage index",it) }
        val lzr=stringArray(root["lzr"])
        val skn=stringArray(root["skn"])
        val folderMap=linkedMapOf<String,SkinFolder>()
        val folderForSkin=mutableMapOf<String,String>()
        val menuOrder=mutableMapOf<String,Int>()
        var rootOrder=0
        root["menu"]?.jsonArray?.forEach { item ->
            val o=item.jsonObject
            when(o["type"]?.jsonPrimitive?.contentOrNull) {
                "folder" -> {
                    val name=o["name"]?.jsonPrimitive?.contentOrNull?.trim().orEmpty().ifBlank { "Folder" }
                    val fid=folderId(name)
                    folderMap.putIfAbsent(fid,SkinFolder(fid,name,folderMap.size))
                    stringArray(o["items"]).forEachIndexed { i,id -> folderForSkin[id]=fid; menuOrder[id]=i }
                    rootOrder++
                }
                "skin" -> o["id"]?.jsonPrimitive?.contentOrNull?.let { menuOrder[it]=rootOrder++ }
            }
        }
        val warnings=mutableListOf<String>()
        val packs=mutableListOf<RecoveredSkinPack>()
        suspend fun addBank(ids:List<String>,bank:SkinBank) {
            ids.forEachIndexed { order,id ->
                val manifest=api.skinManifest(id)
                if (!manifest.successful) {
                    warnings += "$id manifest unavailable (HTTP ${manifest.code})"
                    packs += missingMetadataPack(id,bank,order,menuOrder[id]?:order,folderForSkin[id])
                } else {
                    val parsed=runCatching { parseManifest(id,bank,order,menuOrder[id]?:order,folderForSkin[id],manifest.body) }.getOrElse {
                        warnings += "$id manifest malformed"
                        missingMetadataPack(id,bank,order,menuOrder[id]?:order,folderForSkin[id])
                    }
                    packs += parsed
                }
            }
        }
        addBank(lzr,SkinBank.LZR); addBank(skn,SkinBank.SKN)
        val folders=folderMap.values.toList()
        if (!repository.replaceRecoveredCatalog(packs,folders)) error("Unable to persist recovered catalog")
        return RecoveryImportResult(packs,folders,warnings)
    }

    private fun parseManifest(id:String,bank:SkinBank,order:Int,menuOrder:Int,folderId:String?,raw:String):RecoveredSkinPack {
        val obj=json.parseToJsonElement(raw).jsonObject
        val name=obj["name"]?.jsonPrimitive?.contentOrNull?.ifBlank{id} ?: id
        val slotContainer=obj["slots"]?.let { it as? JsonObject }
        val slots=SkinSlot.entries.associateWith { slot ->
            val e=(slotContainer?.get(slot.wireName) ?: obj[slot.wireName]) as? JsonObject
            if (e==null) RecoveredSlot(slot.wireName,state=LocalSourceState.EMPTY)
            else {
                val sourceSha=stringFieldDeep(e,"sourceSha") ?: stringFieldDeep(e,"source_sha")
                val renderSha=stringFieldDeep(e,"renderSha") ?: stringFieldDeep(e,"render_sha")
                val state=if (sourceSha==null && renderSha==null) LocalSourceState.EMPTY else LocalSourceState.REMOTE_ONLY
                RecoveredSlot(slot.wireName,sourceSha,renderSha,null,state)
            }
        }
        return RecoveredSkinPack(id=id, name=name, bank=bank, order=order, menuOrder=menuOrder, folderId=folderId, slots=slots)
    }

    private fun missingMetadataPack(id:String,bank:SkinBank,order:Int,menuOrder:Int,folderId:String?)=RecoveredSkinPack(
        id=id,name=id,bank=bank,order=order,menuOrder=menuOrder,folderId=folderId,
        slots=SkinSlot.entries.associateWith { RecoveredSlot(it.wireName,state=LocalSourceState.REMOTE_METADATA_MISSING) }
    )

    private fun stringArray(e:JsonElement?):List<String> = (e as? JsonArray)?.mapNotNull { it.jsonPrimitive.contentOrNull } ?: emptyList()
    private fun stringFieldDeep(o:JsonObject,key:String):String? {
        o[key]?.jsonPrimitive?.contentOrNull?.let { return it }
        o.values.filterIsInstance<JsonObject>().forEach { child -> child[key]?.jsonPrimitive?.contentOrNull?.let { return it } }
        return null
    }
    private fun folderId(name:String):String {
        val d=MessageDigest.getInstance("SHA-256").digest(name.trim().lowercase().toByteArray())
        return "folder-"+d.take(6).joinToString("") { "%02x".format(it) }
    }
}
