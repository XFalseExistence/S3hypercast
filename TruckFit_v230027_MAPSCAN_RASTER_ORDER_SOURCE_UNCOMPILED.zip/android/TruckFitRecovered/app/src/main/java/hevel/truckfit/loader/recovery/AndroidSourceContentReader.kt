package hevel.truckfit.loader.recovery

import android.content.ContentResolver
import android.net.Uri

class AndroidSourceContentReader(private val resolver:ContentResolver):SourceContentReader {
    override fun open(candidate:SourceCandidate)=resolver.openInputStream(Uri.parse(candidate.uri))
        ?: error("Unable to read ${candidate.uri}")
}
