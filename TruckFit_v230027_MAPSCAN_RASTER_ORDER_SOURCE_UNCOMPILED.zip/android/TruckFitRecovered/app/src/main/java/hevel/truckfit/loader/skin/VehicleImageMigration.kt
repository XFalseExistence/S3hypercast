package hevel.truckfit.loader.skin

import android.app.Activity
import android.content.Context
import android.net.Uri
import java.util.concurrent.atomic.AtomicBoolean

/** One-time v230025 migration for every already-imported local vehicle image. */
object VehicleImageMigration {
    private const val PREFS = "vehicle_image_migration"
    private const val KEY = "trim_center_v230025_done"
    private val running = AtomicBoolean(false)

    fun start(activity: Activity, repo: SkinRepository, onComplete: (changed: Int, failed: Int) -> Unit = { _, _ -> }) {
        val app = activity.applicationContext
        val prefs = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (prefs.getBoolean(KEY, false)) return
        if (!running.compareAndSet(false, true)) return

        Thread {
            var changed = 0
            var failed = 0
            try {
                for (pack in repo.all()) {
                    for (slot in SkinSlot.entries) {
                        val current = pack.slots[slot] ?: continue
                        val raw = current.localUri?.takeIf { it.isNotBlank() } ?: continue
                        runCatching {
                            VehicleImageNormalizer.normalize(app, Uri.parse(raw), pack.id, slot)
                        }.onSuccess { normalized ->
                            val next = current.copy(
                                localUri = normalized.uri.toString(),
                                sourceSha = null,
                                renderSha = null,
                                state = LocalSourceState.LOCAL_LINKED
                            )
                            if (repo.updateSlot(pack.id, slot, next)) changed++ else failed++
                        }.onFailure { failed++ }
                    }
                }
                if (failed == 0) prefs.edit().putBoolean(KEY, true).apply()
            } finally {
                running.set(false)
                activity.runOnUiThread {
                    if (!activity.isFinishing && !activity.isDestroyed) onComplete(changed, failed)
                }
            }
        }.apply {
            name = "TruckFit-v230025-trim-center"
            isDaemon = true
            start()
        }
    }
}
