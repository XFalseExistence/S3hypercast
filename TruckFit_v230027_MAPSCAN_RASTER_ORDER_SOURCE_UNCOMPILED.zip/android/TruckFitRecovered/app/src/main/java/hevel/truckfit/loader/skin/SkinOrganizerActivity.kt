package hevel.truckfit.loader.skin

import android.content.ClipData
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.DragEvent
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import hevel.truckfit.loader.AppServices
import hevel.truckfit.loader.R
import hevel.truckfit.loader.TruckFitChrome
import hevel.truckfit.loader.ui.SkinLibraryRules

class SkinOrganizerActivity : AppCompatActivity() {
    private val repo by lazy { AppServices.repository(this) }
    private lateinit var content: LinearLayout
    private var garageColumns = 2

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        garageColumns = getSharedPreferences("garage_view", MODE_PRIVATE)
            .getInt("columns", 2)
            .takeIf { it in setOf(2, 4, 8) } ?: 2
        buildChrome()
        VehicleImageMigration.start(this, repo) { changed, failed ->
            if (changed > 0 || failed > 0) {
                Toast.makeText(
                    this,
                    "Auto-trim centered $changed skin views" + if (failed > 0) " • $failed need attention" else "",
                    Toast.LENGTH_LONG
                ).show()
                render()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (::content.isInitialized) render()
    }

    private fun buildChrome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            TruckFitChrome.styleLibraryScreen(this)
            setBackgroundResource(R.drawable.garage_organize_backdrop)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(8), dp(14), dp(8))
            TruckFitChrome.styleHeader(this)
        }
        header.addView(ImageView(this).apply {
            setImageResource(R.drawable.truckfit_launcher_art)
            scaleType = ImageView.ScaleType.FIT_CENTER
            isClickable = true
            contentDescription = "Switch to MapScan"
            setOnClickListener { openMapScan() }
        }, LinearLayout.LayoutParams(dp(48), dp(48)))
        header.addView(TextView(this).apply {
            text = "ORGANIZE"
            textSize = 27f
            setTextColor(Color.WHITE)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(dp(10), 0, 0, 0)
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(header)

        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(18))
        }
        root.addView(ScrollView(this).apply {
            isFillViewport = true
            addView(content)
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        setContentView(root)
        TruckFitChrome.installSafeArea(this, root)
        render()
    }

    private fun render() {
        content.removeAllViews()
        content.addView(TextView(this).apply {
            text = "GARAGE/MAIN • $garageColumns PER ROW\nHold and drag a vehicle to another vehicle to reorder. Drop on MAIN or a folder bar to move it. Tap a vehicle to edit its 6-view collection."
            textSize = 14f
            setPadding(dp(12), dp(10), dp(12), dp(10))
            TruckFitChrome.styleBodyText(this)
            TruckFitChrome.stylePanel(this)
        }, fullWidth(0))

        content.addView(Button(this).apply {
            text = "+  ADD VEHICLE"
            TruckFitChrome.styleSecondary(this)
            setOnClickListener { createVehicleDialog() }
        }, fullWidth(10))

        content.addView(dropFolderBar("▼  MAIN", null, 0), fullWidth(8))
        renderPackGrid(repo.packs(null), depth = 0, top = 6)
        repo.folders(null).forEach { renderExpandedFolder(it, 0) }
    }

    private fun renderExpandedFolder(folder: SkinFolder, depth: Int) {
        content.addView(dropFolderBar("▼  ${folder.name}", folder.id, depth), fullWidth(8))
        renderPackGrid(repo.packs(folder.id), depth + 1, 6)
        repo.folders(folder.id).forEach { child -> renderExpandedFolder(child, depth + 1) }
    }

    private fun dropFolderBar(label: String, folderId: String?, depth: Int): Button = Button(this).apply {
        text = label
        gravity = Gravity.START or Gravity.CENTER_VERTICAL
        setPadding(dp(12 + depth * 12), paddingTop, paddingRight, paddingBottom)
        TruckFitChrome.styleSecondary(this)
        setOnDragListener { view, event ->
            when (event.action) {
                DragEvent.ACTION_DRAG_ENTERED -> { view.alpha = 0.72f; true }
                DragEvent.ACTION_DRAG_EXITED -> { view.alpha = 1f; true }
                DragEvent.ACTION_DROP -> {
                    view.alpha = 1f
                    val draggedId = event.localState as? String ?: return@setOnDragListener false
                    repo.moveToFolder(draggedId, folderId)
                    render()
                    true
                }
                DragEvent.ACTION_DRAG_ENDED -> { view.alpha = 1f; true }
                else -> true
            }
        }
    }

    private fun renderPackGrid(packs: List<RecoveredSkinPack>, depth: Int, top: Int) {
        if (packs.isEmpty()) return
        packs.chunked(garageColumns).forEachIndexed { rowIndex, chunk ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(dp(depth * 8), 0, 0, 0)
                setOnDragListener { view, event ->
                    when (event.action) {
                        DragEvent.ACTION_DRAG_STARTED -> true
                        DragEvent.ACTION_DRAG_ENTERED -> { view.alpha = 0.82f; true }
                        DragEvent.ACTION_DRAG_EXITED -> { view.alpha = 1f; true }
                        DragEvent.ACTION_DROP -> {
                            view.alpha = 1f
                            val draggedId = event.localState as? String ?: return@setOnDragListener false
                            if (chunk.isEmpty()) return@setOnDragListener false
                            val slotWidth = (view.width.toFloat() / garageColumns.coerceAtLeast(1)).coerceAtLeast(1f)
                            val slot = (event.x / slotWidth).toInt().coerceIn(0, chunk.lastIndex)
                            repo.reorderPack(draggedId, chunk[slot].id)
                            render()
                            true
                        }
                        DragEvent.ACTION_DRAG_ENDED -> { view.alpha = 1f; true }
                        else -> true
                    }
                }
            }
            chunk.forEach { pack ->
                row.addView(vehicleCard(pack), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                    marginStart = dp(2)
                    marginEnd = dp(2)
                })
            }
            repeat(garageColumns - chunk.size) {
                row.addView(Space(this), LinearLayout.LayoutParams(0, 1, 1f))
            }
            content.addView(row, fullWidth(if (rowIndex == 0) top else 4))
        }
    }

    private fun vehicleCard(pack: RecoveredSkinPack): LinearLayout {
        val previewHeight = when (garageColumns) {
            2 -> 150
            4 -> 92
            else -> 52
        }
        val titleSize = when (garageColumns) {
            2 -> 16f
            4 -> 11f
            else -> 8f
        }
        val cardPad = if (garageColumns >= 8) 2 else 4
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            isClickable = true
            isFocusable = true
            setPadding(dp(cardPad), dp(cardPad), dp(cardPad), dp(cardPad + 1))
            if (pack.linkedToS3) TruckFitChrome.stylePanel(this) else setBackgroundColor(Color.BLACK)
        }
        val previewSlot = pack.slots[SkinSlot.REAR_3D]
        val frame = FrameLayout(this).apply { setBackgroundColor(0xFF202020.toInt()) }
        val image = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(0xFF202020.toInt())
        }
        frame.addView(image, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(previewHeight)))
        val placeholder = TextView(this).apply {
            text = "3D SOUTH"
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            textSize = if (garageColumns >= 8) 7f else 10f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        frame.addView(placeholder, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(previewHeight)))
        previewSlot?.localUri?.let { raw ->
            runCatching {
                image.setImageURI(Uri.parse(raw))
                placeholder.visibility = View.GONE
            }
        }
        card.addView(frame)
        card.addView(TextView(this).apply {
            text = SkinLibraryRules.displayName(pack.bank.name, pack.name)
            textSize = titleSize
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(dp(cardPad), dp(cardPad), dp(cardPad), 0)
            setSingleLine(true)
            maxLines = 1
            setAutoSizeTextTypeUniformWithConfiguration(6, titleSize.toInt().coerceAtLeast(7), 1, android.util.TypedValue.COMPLEX_UNIT_SP)
            if (pack.linkedToS3) TruckFitChrome.styleBodyText(this) else setTextColor(Color.WHITE)
        })
        card.setOnClickListener {
            startActivity(Intent(this, SkinEditorActivity::class.java).putExtra("skin_id", pack.id))
        }
        card.setOnLongClickListener {
            val clip = ClipData.newPlainText("vehicle_id", pack.id)
            it.startDragAndDrop(clip, View.DragShadowBuilder(it), pack.id, 0)
            it.alpha = 0.45f
            true
        }
        return card
    }

    private fun openMapScan() {
        startActivity(Intent().setClassName(packageName, "hevel.truckfit.loader.radarfield.RadarFieldLibraryActivity"))
    }

    private fun createVehicleDialog() {
        val input = EditText(this).apply { hint = "Vehicle / collection name" }
        AlertDialog.Builder(this)
            .setTitle("Add vehicle")
            .setView(input)
            .setNegativeButton("CANCEL", null)
            .setPositiveButton("CREATE") { _, _ ->
                val created = repo.createVehicle(input.text.toString(), null)
                if (created != null) {
                    startActivity(Intent(this, SkinEditorActivity::class.java).putExtra("skin_id", created.id))
                } else {
                    Toast.makeText(this, "Vehicle name required", Toast.LENGTH_SHORT).show()
                }
            }.show()
    }

    private fun fullWidth(top: Int) = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
        topMargin = dp(top)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()
}
