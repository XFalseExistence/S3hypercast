package hevel.truckfit.loader.transfer

import android.content.ContentResolver
import android.net.Uri
import hevel.truckfit.loader.hevel.HevelMutatingApi
import hevel.truckfit.loader.skin.*
import kotlinx.serialization.json.*
import java.security.MessageDigest

data class UploadOutcome(val uploadedSlots:Int,val sourceHashes:Map<SkinSlot,String>,val renderHashes:Map<SkinSlot,String>)

class SkinTransfer(private val resolver:ContentResolver,private val api:HevelMutatingApi) {
    suspend fun activateSkin(id:String,bank:SkinBank)=api.activateSkin(id,bank.name)
    suspend fun setDefault()=api.setDefault()
    suspend fun deleteRemote(id:String)=api.deleteRemote(id)

    suspend fun uploadSkin(pack:RecoveredSkinPack,remote:RemoteManifestSnapshot):UploadOutcome {
        val sourceHashes=mutableMapOf<SkinSlot,String>(); val renderHashes=mutableMapOf<SkinSlot,String>()
        val plans=SyncPlanner.plan(pack,remote)
        for(op in plans) {
            val uri=Uri.parse(op.localUri)
            val source=resolver.openInputStream(uri)?.use{it.readBytes()} ?: error("Cannot read ${op.localUri}")
            val render=resolver.openInputStream(uri)?.use{Rgb565aEncoder.encode(it).bytes} ?: error("Cannot render ${op.localUri}")
            val sourceSha=sha256(source); val renderSha=sha256(render)
            check(api.uploadRaw(pack.id,op.slot.wireName,"source",source).successful) { "source upload failed ${op.slot.wireName}" }
            check(api.uploadRaw(pack.id,op.slot.wireName,"render",render).successful) { "render upload failed ${op.slot.wireName}" }
            sourceHashes[op.slot]=sourceSha; renderHashes[op.slot]=renderSha
        }
        val mergedSource=SkinSlot.entries.associateWith { sourceHashes[it] ?: pack.slots[it]?.sourceSha }
        val mergedRender=SkinSlot.entries.associateWith { renderHashes[it] ?: pack.slots[it]?.renderSha }
        val manifest=buildJsonObject {
            put("schema",1); put("id",pack.id); put("name",pack.name); put("bank",pack.bank.name)
            putJsonObject("slots") {
                SkinSlot.entries.forEach { slot ->
                    val ss=mergedSource[slot]; val rs=mergedRender[slot]
                    if(!ss.isNullOrBlank() || !rs.isNullOrBlank()) putJsonObject(slot.wireName) {
                        ss?.let{put("sourceSha",it)}; rs?.let{put("renderSha",it)}
                    }
                }
            }
        }.toString()
        check(api.postManifest(pack.id,manifest).successful) { "manifest update failed" }
        return UploadOutcome(plans.size,sourceHashes,renderHashes)
    }

    private fun sha256(bytes:ByteArray)=MessageDigest.getInstance("SHA-256").digest(bytes).joinToString(""){"%02x".format(it)}
}
