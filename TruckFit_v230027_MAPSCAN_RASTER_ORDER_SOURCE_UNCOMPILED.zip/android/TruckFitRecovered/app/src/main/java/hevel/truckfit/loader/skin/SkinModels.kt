package hevel.truckfit.loader.skin

import kotlinx.serialization.Serializable

@Serializable
enum class SkinBank { SKN, LZR }

@Serializable
enum class SkinSlot(val wireName: String) {
    TOP_3D("3D_TOP"),
    TOP_2D("2D_TOP"),
    TACT_3D("3D_TACT"),
    TACT_2D("2D_TACT"),
    REAR_3D("3D_REAR"),
    REAR_2D("2D_REAR");

    companion object {
        fun fromWireName(value: String): SkinSlot? = entries.firstOrNull { it.wireName == value }
    }
}

@Serializable
enum class LocalSourceState { LOCAL_LINKED, REMOTE_ONLY, EMPTY, REMOTE_METADATA_MISSING }

@Serializable
data class RecoveredSlot(
    val wireName: String,
    val sourceSha: String? = null,
    val renderSha: String? = null,
    val localUri: String? = null,
    val state: LocalSourceState = LocalSourceState.REMOTE_ONLY,
    val alternatives: List<String> = emptyList()
)

@Serializable
data class RecoveredSkinPack(
    val id: String,
    val name: String,
    val bank: SkinBank,
    val order: Int = 0,
    val menuOrder: Int = 0,
    val folderId: String? = null,
    val linkedToS3: Boolean = true,
    val slots: Map<SkinSlot, RecoveredSlot> = emptyMap()
) {
    companion object {
        fun empty(id: String, name: String, bank: SkinBank): RecoveredSkinPack = RecoveredSkinPack(
            id = id,
            name = name,
            bank = bank,
            slots = SkinSlot.entries.associateWith { RecoveredSlot(it.wireName, state = LocalSourceState.EMPTY) }
        )
    }
}

@Serializable
data class SkinFolder(
    val id: String,
    val name: String,
    val order: Int = 0,
    val parentId: String? = null
)

@Serializable
data class RecoveredLibraryEnvelope(
    val schemaVersion: Int = 1,
    val packs: List<RecoveredSkinPack> = emptyList(),
    val folders: List<SkinFolder> = emptyList()
)
