package hevel.truckfit.loader.radarfield

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import hevel.truckfit.loader.AppServices
import hevel.truckfit.loader.HotspotConnector
import hevel.truckfit.loader.MainActivity
import hevel.truckfit.loader.TruckFitChrome
import kotlinx.coroutines.launch

class RadarFieldLibraryActivity : AppCompatActivity() {
    private val repo by lazy { AppServices.radarFields(this) }
    private var currentFolderId: String? = null
    private lateinit var content: LinearLayout
    private lateinit var footer: TextView
    private var mapColumns: Int = 2

    private val openImage = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            startActivity(Intent().setClassName(packageName, "hevel.truckfit.loader.radarfield.RadarFieldCropActivity")
                .putExtra("image_uri", uri.toString())
                .putExtra("folder_id", currentFolderId))
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        currentFolderId = savedInstanceState?.getString("folder_id")
        mapColumns = getSharedPreferences("satellite_view", MODE_PRIVATE).getInt("columns", 2).takeIf { it in setOf(2,4,8) } ?: 2
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (currentFolderId != null) goUp() else { isEnabled = false; onBackPressedDispatcher.onBackPressed() }
            }
        })
        buildChrome()
    }

    override fun onSaveInstanceState(outState: Bundle) { super.onSaveInstanceState(outState); outState.putString("folder_id", currentFolderId) }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        HotspotConnector.onPermissionResult(this, requestCode, grantResults) { footer.text = it }
    }
    override fun onResume() { super.onResume(); render() }

    private fun buildChrome() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; TruckFitChrome.styleLibraryScreen(this) }
        root.addView(RadarFieldHeader.create(this, "MapScan", onEyeClick = { cycleGrid() }, onMenuClick = { showMapScanMenu(it) }))
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(8), dp(12), dp(16)) }
        root.addView(ScrollView(this).apply { isFillViewport = true; addView(content) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        footer = TextView(this).apply { textSize = 12f; setPadding(dp(12), dp(8), dp(12), dp(8)); TruckFitChrome.styleBodyText(this); TruckFitChrome.stylePanel(this) }
        root.addView(footer, fullWidth(0).apply { setMargins(dp(8), 0, dp(8), dp(8)) })
        setContentView(root)
        TruckFitChrome.installMapScanSafeArea(this, root)
    }

    private fun cycleGrid() {
        mapColumns = when(mapColumns) { 2 -> 4; 4 -> 8; else -> 2 }
        getSharedPreferences("satellite_view", MODE_PRIVATE).edit().putInt("columns", mapColumns).apply()
        render()
    }

    private fun showMapScanMenu(anchor: ImageButton) {
        val menuColumn = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), dp(10), dp(10), dp(10)); TruckFitChrome.stylePanel(this) }
        lateinit var popup: PopupWindow
        fun action(label: String, run: () -> Unit) {
            menuColumn.addView(Button(this).apply { text = label; textSize = 12f; minHeight = dp(46); TruckFitChrome.styleMapScanSecondary(this); setOnClickListener { popup.dismiss(); run() } }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin=dp(3); bottomMargin=dp(3) })
        }
        fun groupGap() { menuColumn.addView(Space(this), LinearLayout.LayoutParams(1, dp(14))) }
        action("Satellite") { openSatellite() }
        action("MAIN") { currentFolderId = null; render() }
        if (currentFolderId != null) action("UP ONE FOLDER") { goUp() }
        action("NEW FOLDER") { createFolderDialog() }
        groupGap()
        action("Import") { openImage.launch(arrayOf("image/*")) }
        action("GPS KEYS") { startActivity(Intent(this, ProviderSetupActivity::class.java)) }
        action("Hotspot") { openHotspotPanel() }
        action("Sync") { syncMapsToS3() }
        groupGap()
        action("GARAGE") { startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)) }
        groupGap()
        action("Complete") { completeSession() }
        val scroll = ScrollView(this).apply { addView(menuColumn) }
        popup = PopupWindow(scroll, dp(318), ViewGroup.LayoutParams.WRAP_CONTENT, true).apply { isOutsideTouchable=true; setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT)); elevation=dp(12).toFloat() }
        popup.showAsDropDown(anchor, -dp(260), dp(4))
    }

    private fun openHotspotPanel() { HotspotConnector.connect(this) { if (::footer.isInitialized) footer.text = it } }
    private fun syncMapsToS3() = lifecycleScope.launch {
        footer.text = "Syncing MapScan catalog to S3…"
        val result = hevel.truckfit.loader.transfer.RadarMapSyncManager(this@RadarFieldLibraryActivity).syncAll { footer.text = it }
        footer.text = result.message
        render()
    }
    private fun openSatellite() { startActivity(Intent(this, RadarFieldScanActivity::class.java).putExtra("folder_id", currentFolderId)) }
    private fun completeSession() = lifecycleScope.launch {
        footer.text = "Completing TruckFit session • resetting S3…"
        runCatching { AppServices.api().exitLoader() }
        HotspotConnector.release(this@RadarFieldLibraryActivity)
        finishAndRemoveTask()
    }
    private fun goUp() { currentFolderId = repo.folders().firstOrNull { it.id == currentFolderId }?.parentId; render() }
    private fun createFolderDialog() {
        val input = EditText(this).apply { hint = "Folder name" }
        AlertDialog.Builder(this).setTitle("New MapScan folder").setView(input).setNegativeButton("CANCEL", null).setPositiveButton("CREATE") { _, _ -> repo.createFolder(input.text.toString(), currentFolderId); render() }.show()
    }

    private fun render() {
        if (!::content.isInitialized) return
        if (currentFolderId != null && repo.folders().none { it.id == currentFolderId }) currentFolderId = null
        content.removeAllViews()
        content.addView(TextView(this).apply { text=breadcrumb(); gravity=Gravity.CENTER; textSize=15f; setTypeface(typeface, android.graphics.Typeface.BOLD); setPadding(dp(10),dp(8),dp(10),dp(8)); TruckFitChrome.styleBodyText(this); TruckFitChrome.stylePanel(this) })
        if (currentFolderId == null) content.addView(defaultCard(), fullWidth(10))
        repo.folders(currentFolderId).forEach { folder -> content.addView(Button(this).apply { text="▸  ${folder.name}"; gravity=Gravity.START or Gravity.CENTER_VERTICAL; TruckFitChrome.styleMapScanSecondary(this); setOnClickListener { currentFolderId=folder.id; render() } }, fullWidth(8)) }
        renderFieldGrid(repo.fields(currentFolderId))
        val active = repo.all().firstOrNull { it.active }?.displayName ?: "DEFAULT"
        footer.text = "${repo.all().size} saved fields • $mapColumns per row • active $active • 80×80 ft masters • 68×48 ft rounded prox • R20 ft"
    }

    private fun renderFieldGrid(fields: List<SavedRadarField>) {
        fields.chunked(mapColumns).forEachIndexed { rowIndex, chunk ->
            val row=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
            chunk.forEach { field -> row.addView(fieldCard(field), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart=dp(2); marginEnd=dp(2) }) }
            repeat(mapColumns-chunk.size) { row.addView(Space(this), LinearLayout.LayoutParams(0,1,1f)) }
            content.addView(row, fullWidth(if(rowIndex==0) 10 else 4))
        }
    }

    private fun defaultCard(): LinearLayout = LinearLayout(this).apply {
        val defaultActive = repo.all().none { it.active }
        orientation=LinearLayout.VERTICAL; setPadding(dp(10),dp(12),dp(10),dp(12)); TruckFitChrome.stylePanel(this)
        if (defaultActive) setBackgroundColor(0xFF15353A.toInt())
        addView(TextView(this@RadarFieldLibraryActivity).apply { text=if(defaultActive) "DEFAULT • ACTIVE" else "DEFAULT"; textSize=20f; setTypeface(typeface,android.graphics.Typeface.BOLD); TruckFitChrome.styleBodyText(this) })
        addView(TextView(this@RadarFieldLibraryActivity).apply { text="Built-in HEVEL field • onboard 5 / 10 / 20 ft rings • tap to deactivate map"; textSize=13f; TruckFitChrome.styleBodyText(this) })
        setOnClickListener { activateDefault() }
    }

    private fun fieldCard(field: SavedRadarField): LinearLayout = LinearLayout(this).apply {
        orientation=LinearLayout.VERTICAL; setPadding(dp(if(mapColumns>=8) 2 else 5),dp(5),dp(if(mapColumns>=8) 2 else 5),dp(6)); TruckFitChrome.stylePanel(this)
        if (field.active) setBackgroundColor(0xFF15353A.toInt())
        val image=ImageView(this@RadarFieldLibraryActivity).apply { scaleType=ImageView.ScaleType.CENTER_CROP; setBackgroundColor(0xFF202020.toInt()); field.imageUri?.let { raw -> runCatching { setImageURI(Uri.parse(raw)) } } }
        val previewH=when(mapColumns){2->170;4->100;else->58}
        addView(image, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(previewH)))
        addView(TextView(this@RadarFieldLibraryActivity).apply {
            text=field.displayName; setTypeface(typeface,android.graphics.Typeface.BOLD); setSingleLine(true); maxLines=1; setPadding(dp(3),dp(5),dp(3),0); TruckFitChrome.styleBodyText(this)
            setAutoSizeTextTypeUniformWithConfiguration(6, if(mapColumns==2) 18 else if(mapColumns==4) 12 else 8, 1, android.util.TypedValue.COMPLEX_UNIT_SP)
        })
        addView(TextView(this@RadarFieldLibraryActivity).apply { text=(if(field.active) "ACTIVE • " else "TAP TO ACTIVATE • ") + (if(field.mapProximityEnabled) "68×48 PROX" else "S3 RINGS") + " • R${field.calibrationRevision}"; textSize=if(mapColumns>=8) 6f else 10f; setPadding(dp(3),0,dp(3),dp(3)); TruckFitChrome.styleBodyText(this) })
        setOnClickListener { if(field.active) openCalibration(field) else activateField(field) }
        setOnLongClickListener { manageField(field); true }
    }

    private fun openCalibration(field: SavedRadarField) {
        if (field.imageUri != null) startActivity(Intent().setClassName(packageName,"hevel.truckfit.loader.radarfield.RadarFieldCropActivity").putExtra("field_id",field.id))
        else Toast.makeText(this,"This field has no local image",Toast.LENGTH_SHORT).show()
    }

    private fun manageField(field: SavedRadarField) {
        val actions=arrayOf(if(field.active) "DEACTIVATE" else "ACTIVATE", "CALIBRATE", if(field.mapProximityEnabled) "USE S3 RINGS" else "USE 68×48 MAP PROX", "RENAME", "MOVE TO FOLDER", "DELETE")
        AlertDialog.Builder(this).setTitle(field.displayName).setItems(actions) { _,which -> when(which) {
            0 -> if(field.active) activateDefault() else activateField(field)
            1 -> openCalibration(field)
            2 -> { repo.setMapProximity(field.id,!field.mapProximityEnabled); render() }
            3 -> renameField(field)
            4 -> moveField(field)
            else -> deleteField(field)
        }}.show()
    }

    private fun activateDefault() = lifecycleScope.launch {
        footer.text = "Deactivating map • returning S3 to DEFAULT…"
        val result = hevel.truckfit.loader.transfer.RadarMapSyncManager(this@RadarFieldLibraryActivity).useDefault()
        footer.text = result.message
        render()
    }

    private fun activateField(field: SavedRadarField) = lifecycleScope.launch {
        val previousActive = repo.all().firstOrNull { it.active }?.id
        if (!repo.setActive(field.id)) {
            footer.text = "Activation failed • local map state unavailable"
            return@launch
        }
        render()
        footer.text = "Activating ${field.displayName} on S3…"
        val result = hevel.truckfit.loader.transfer.RadarMapSyncManager(this@RadarFieldLibraryActivity).syncOne(field.id, activate = true)
        if (!result.successful) {
            if (previousActive != null) repo.setActive(previousActive) else repo.useDefault()
            render()
        }
        footer.text = result.message
    }

    private fun deleteField(field: SavedRadarField) {
        AlertDialog.Builder(this).setTitle("Delete ${field.displayName}?").setMessage("This removes the saved map image and its TruckFit calibration.").setNegativeButton("CANCEL",null).setPositiveButton("DELETE") { _,_ ->
            if(repo.delete(field.id)) {
                field.imageUri?.let { raw -> runCatching { val uri=Uri.parse(raw); if(uri.scheme=="file") { val file=uri.path?.let{java.io.File(it)}; val root=java.io.File(filesDir,"radar_fields").canonicalFile; val target=file?.canonicalFile; if(target!=null && target.path.startsWith(root.path+java.io.File.separator)) target.parentFile?.deleteRecursively() } } }
                render()
            }
        }.show()
    }
    private fun renameField(field: SavedRadarField) { val input=EditText(this).apply{setText(field.displayName);selectAll()}; AlertDialog.Builder(this).setTitle("Rename field").setView(input).setNegativeButton("CANCEL",null).setPositiveButton("SAVE"){_,_->repo.rename(field.id,input.text.toString());render()}.show() }
    private fun moveField(field: SavedRadarField) { val folders=repo.folders(); val labels=mutableListOf("MAIN"); labels+=folders.map{folderPath(it,folders.associateBy{f->f.id})}; AlertDialog.Builder(this).setTitle("Move ${field.displayName}").setItems(labels.toTypedArray()){_,which->repo.moveField(field.id,if(which==0)null else folders[which-1].id);render()}.show() }
    private fun breadcrumb(): String { val byId=repo.folders().associateBy{it.id}; val names=mutableListOf<String>(); val seen=mutableSetOf<String>(); var cursor=currentFolderId; while(cursor!=null && seen.add(cursor)){val f=byId[cursor]?:break;names+=f.name;cursor=f.parentId}; return if(names.isEmpty()) "MAPSCAN/MAIN" else "MAPSCAN/MAIN / "+names.asReversed().joinToString(" / ") }
    private fun folderPath(folder: RadarFieldFolder, byId: Map<String,RadarFieldFolder>): String { val names=mutableListOf<String>(); val seen=mutableSetOf<String>(); var cursor:RadarFieldFolder?=folder; while(cursor!=null && seen.add(cursor.id)){names+=cursor.name;cursor=cursor.parentId?.let{byId[it]}}; return names.asReversed().joinToString(" / ") }
    private fun fullWidth(top:Int)=LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT).apply{topMargin=dp(top)}
    private fun dp(value:Int):Int=(value*resources.displayMetrics.density+0.5f).toInt()
}
