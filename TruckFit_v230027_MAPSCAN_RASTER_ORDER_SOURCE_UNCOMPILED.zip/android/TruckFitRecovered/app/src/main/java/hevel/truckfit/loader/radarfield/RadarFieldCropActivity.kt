package hevel.truckfit.loader.radarfield

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import hevel.truckfit.loader.AppServices
import hevel.truckfit.loader.TruckFitChrome
import java.io.File
import java.util.UUID
import kotlinx.coroutines.launch

class RadarFieldCropActivity : AppCompatActivity() {
    private val repo by lazy { AppServices.radarFields(this) }
    private val previewClient by lazy { RadarFieldPreviewClient(this) }
    private val credentialStore by lazy { ProviderCredentialStore(this) }
    private lateinit var cropView: RadarFieldCropView
    private lateinit var status: TextView
    private lateinit var guideButton: Button
    private lateinit var radarGuideButton: Button
    private var sourceField: SavedRadarField? = null
    private var sourceUri: Uri? = null
    private var targetFolderId: String? = null
    private var allowPersist: Boolean = true
    private var sourceProvider: String = "imported"
    private var sourceCenterLat: Double? = null
    private var sourceCenterLon: Double? = null
    private var browseMode: Boolean = false
    private var detailMode: Boolean = false
    private var sourceFootprintFt: Double = RadarFieldGeometry.masterWidthFt

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val fieldId = intent.getStringExtra("field_id")
        sourceField = fieldId?.let { repo.get(it) }
        sourceUri = intent.getStringExtra("image_uri")?.let(Uri::parse) ?: sourceField?.imageUri?.let(Uri::parse)
        targetFolderId = intent.getStringExtra("folder_id") ?: sourceField?.folderId
        allowPersist = intent.getBooleanExtra("allow_persist", true)
        sourceProvider = intent.getStringExtra("provider") ?: sourceField?.provider ?: "imported"
        sourceCenterLat = intent.takeIf { it.hasExtra("center_lat") }?.getDoubleExtra("center_lat", 0.0) ?: sourceField?.centerLat
        sourceCenterLon = intent.takeIf { it.hasExtra("center_lon") }?.getDoubleExtra("center_lon", 0.0) ?: sourceField?.centerLon
        browseMode = intent.getBooleanExtra("browse_mode", false)
        detailMode = intent.getBooleanExtra("detail_mode", false)
        sourceFootprintFt = intent.getDoubleExtra("source_footprint_ft", RadarFieldGeometry.masterWidthFt)
        buildUi()

        when {
            browseMode -> cropView.configureBrowser(sourceFootprintFt, RadarFieldGeometry.masterWidthFt)
            detailMode -> cropView.configureLockedDetail()
            else -> cropView.configureLocalCrop()
        }
        sourceField?.let { cropView.setRadarGuideEnabled(it.mapProximityEnabled) }

        val uri = sourceUri
        if (uri == null) status.text = "No source image available"
        else runCatching { decodeScaled(uri, 3000) }
            .onSuccess {
                cropView.setSource(it)
                status.text = when {
                    browseMode -> "Drag the satellite image under the white 80×80 ft crop frame • ${sourceFootprintFt.toInt()}×${sourceFootprintFt.toInt()} ft browse area"
                    detailMode -> "LOCKED 80×80 FT DETAIL • provider scale fixed • PROX FIELD is 68×48 ft"
                    allowPersist -> "Drag / pinch the image until the 80×80 ft crop is framed, then tap CROP & SAVE AS"
                    else -> "Drag / pinch to inspect • provider preview only • tap HOW TO SAVE for the permanent-field workflow"
                }
            }
            .onFailure { status.text = "Unable to open image: ${it.message}" }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            TruckFitChrome.styleScreen(this)
        }
        root.addView(RadarFieldHeader.create(this, "Crop / Inspect"))
        status = TextView(this).apply {
            textSize = 13f
            setPadding(dp(12), dp(9), dp(12), dp(9))
            TruckFitChrome.styleBodyText(this)
            TruckFitChrome.stylePanel(this)
        }
        root.addView(status, fullWidth(8).apply { marginStart = dp(10); marginEnd = dp(10) })

        cropView = RadarFieldCropView(this)
        root.addView(cropView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            setMargins(dp(10), dp(10), dp(10), dp(8))
        })

        val row1 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(8), 0, dp(8), dp(4))
        }
        row1.addView(Button(this).apply {
            text = "RESET"
            TruckFitChrome.styleMapScanSecondary(this)
            setOnClickListener { cropView.resetTransform() }
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(4) })
        guideButton = Button(this).apply {
            text = "CLEAN VIEW"
            TruckFitChrome.styleMapScanSecondary(this)
            setOnClickListener {
                cropView.setGuidesEnabled(!cropView.guidesEnabled())
                text = if (cropView.guidesEnabled()) "CLEAN VIEW" else "SHOW CROP"
            }
        }
        row1.addView(guideButton, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(4) })
        root.addView(row1)

        val row2 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(8), 0, dp(8), dp(4))
        }
        radarGuideButton = Button(this).apply {
            text = if (sourceField?.mapProximityEnabled == true) "PROX FIELD: ON" else "PROX FIELD: OFF"
            TruckFitChrome.styleMapScanSecondary(this)
            setOnClickListener {
                val next = !cropView.radarGuideEnabled()
                cropView.setRadarGuideEnabled(next)
                text = if (next) "PROX FIELD: ON" else "PROX FIELD: OFF"
            }
        }
        row2.addView(radarGuideButton, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(4) })

        if (browseMode) {
            row2.addView(Button(this).apply {
                text = "80 × 80 DETAIL"
                TruckFitChrome.styleMapScanPrimary(this)
                setOnClickListener { openSelectedDetail() }
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(4) })
            root.addView(row2)

            root.addView(Button(this).apply {
                text = "HOW TO SAVE"
                TruckFitChrome.styleMapScanSecondary(this)
                setOnClickListener { showSaveHelp() }
            }, fullWidth(0).apply {
                marginStart = dp(8)
                marginEnd = dp(8)
                bottomMargin = dp(8)
            })
        } else {
            row2.addView(Button(this).apply {
                text = if (allowPersist) (if (sourceField != null) "SAVE CALIBRATION" else "CROP & SAVE AS") else "HOW TO SAVE"
                if (allowPersist) TruckFitChrome.styleMapScanPrimary(this) else TruckFitChrome.styleMapScanSecondary(this)
                setOnClickListener {
                    if (allowPersist) askNameAndSave() else showSaveHelp()
                }
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(4) })
            root.addView(row2.apply { setPadding(dp(8), 0, dp(8), dp(8)) })
        }

        setContentView(root)
        TruckFitChrome.installMapScanSafeArea(this, root)
    }

    private fun openSelectedDetail() {
        val provider = RadarProviderId.entries.firstOrNull { it.name.equals(sourceProvider, ignoreCase = true) }
        val lat = sourceCenterLat
        val lon = sourceCenterLon
        if (provider == null || lat == null || lon == null) {
            status.text = "Detail view unavailable for this source"
            return
        }
        val (eastFt, northFt) = cropView.selectedCenterOffsetFeet()
        val selectedCenter = RadarFieldGeometry.offsetCenterFeet(GeoCenter(lat, lon), eastFt, northFt)
        lifecycleScope.launch {
            status.text = "Loading full-detail 80×80 ft ${provider.displayName} view…"
            when (val result = previewClient.fetchDetail(provider, selectedCenter, credentialStore.read())) {
                is ProviderFetchResult.Success -> {
                    val file = File.createTempFile("radar-detail-${provider.name.lowercase()}-", ".img", cacheDir)
                    file.writeBytes(result.bytes)
                    startActivity(
                        Intent(this@RadarFieldCropActivity, RadarFieldCropActivity::class.java)
                            .putExtra("image_uri", Uri.fromFile(file).toString())
                            .putExtra("folder_id", targetFolderId)
                            .putExtra("provider", provider.name.lowercase())
                            .putExtra("center_lat", selectedCenter.lat)
                            .putExtra("center_lon", selectedCenter.lon)
                            .putExtra("allow_persist", result.request.canPersist)
                            .putExtra("browse_mode", false)
                            .putExtra("detail_mode", true)
                            .putExtra("source_footprint_ft", RadarFieldGeometry.masterWidthFt)
                    )
                    status.text = "Opened full-detail 80×80 ft provider view"
                }
                is ProviderFetchResult.Error -> status.text = "80×80 detail failed: ${result.message}"
                is ProviderFetchResult.Unavailable -> status.text = result.request.unavailableReason ?: "Provider unavailable"
            }
        }
    }

    private fun showSaveHelp() {
        AlertDialog.Builder(this)
            .setTitle("Saving MapScan")
            .setMessage(
                "This provider image is a comparison/browse preview, so TruckFit will not silently turn it into a permanent saved field.\n\n" +
                    "To save a permanent MapScan image:\n" +
                    "1. In the wide browser, center the reticle and tap 80 × 80 DETAIL for a full-detail field view.\n" +
                    "2. Use CLEAN VIEW if you want an overlay-free reference.\n" +
                    "3. Go to MapScan > TOOLS.\n" +
                    "4. Choose Import.\n" +
                    "5. Pick imagery you are allowed to retain.\n" +
                    "6. Frame the 80×80 ft crop and tap CROP & SAVE AS.\n\n" +
                    "Saved images are copied into TruckFit's MapScan library and remain available offline."
            )
            .setPositiveButton("OK", null)
            .show()
    }

    private fun askNameAndSave() {
        val input = EditText(this).apply {
            setText(sourceField?.displayName ?: "MapScan")
            selectAll()
        }
        AlertDialog.Builder(this)
            .setTitle("Save cropped MapScan as")
            .setView(input)
            .setNegativeButton("CANCEL", null)
            .setPositiveButton("SAVE") { _, _ -> saveAs(input.text.toString()) }
            .show()
    }

    private fun saveAs(rawName: String) {
        val name = rawName.trim().ifBlank { "MapScan" }
        val existing = sourceField
        val id = existing?.id ?: "field-${UUID.randomUUID()}"
        val dir = File(filesDir, "radar_fields/$id").apply { mkdirs() }
        val file = File(dir, "field.jpg")
        runCatching {
            val rendered = cropView.renderCrop(1024)
            file.outputStream().buffered().use { out ->
                check(rendered.compress(Bitmap.CompressFormat.JPEG, 94, out))
            }
            val source = sourceField
            val t = cropView.currentTransform()
            val saved = SavedRadarField(
                id = id,
                displayName = name,
                provider = source?.provider ?: sourceProvider,
                imageUri = Uri.fromFile(file).toString(),
                folderId = targetFolderId,
                centerLat = source?.centerLat ?: sourceCenterLat,
                centerLon = source?.centerLon ?: sourceCenterLon,
                cropScale = t?.scale ?: 1f,
                cropOffsetX = t?.offsetX ?: 0f,
                cropOffsetY = t?.offsetY ?: existing?.cropOffsetY ?: 0f,
                active = existing?.active ?: false,
                mapProximityEnabled = cropView.radarGuideEnabled(),
                calibrationRevision = (existing?.calibrationRevision ?: 0) + 1
            )
            check(repo.save(saved))
            saved
        }.onSuccess {
            status.text = "Saved ${it.displayName} • 80×80 ft calibrated master • 68×48 ft prox field • rev ${it.calibrationRevision}"
            Toast.makeText(this, "Saved ${it.displayName}", Toast.LENGTH_SHORT).show()
        }.onFailure {
            status.text = "Save failed: ${it.message}"
            file.delete()
            dir.delete()
        }
    }

    private fun decodeScaled(uri: Uri, maxDimension: Int): Bitmap {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        val boundsRead = contentResolver.openInputStream(uri)?.use { input ->
            BitmapFactory.decodeStream(input, null, bounds)
            true
        } ?: false
        if (!boundsRead || bounds.outWidth <= 0 || bounds.outHeight <= 0) {
            error("Unable to read image bounds")
        }

        var sample = 1
        while (bounds.outWidth / sample > maxDimension || bounds.outHeight / sample > maxDimension) sample *= 2
        val opts = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        return contentResolver.openInputStream(uri)?.use { input ->
            BitmapFactory.decodeStream(input, null, opts)
        } ?: error("Unable to decode image")
    }

    private fun fullWidth(top: Int) =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(top)
        }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()
}
