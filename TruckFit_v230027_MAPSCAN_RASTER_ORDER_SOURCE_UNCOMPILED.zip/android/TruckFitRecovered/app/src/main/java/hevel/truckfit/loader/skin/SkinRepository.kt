package hevel.truckfit.loader.skin

import android.content.SharedPreferences
import hevel.truckfit.loader.ui.Hierarchy
import java.util.UUID

interface LibraryStore {
    fun read(): String?
    fun write(value: String): Boolean
}

class SharedPreferencesLibraryStore(
    private val prefs: SharedPreferences,
    private val key: String = "library_json"
) : LibraryStore {
    override fun read(): String? = prefs.getString(key, null)
    override fun write(value: String): Boolean = prefs.edit().putString(key, value).commit()
}

class SkinRepository(
    private val store: LibraryStore,
    private val codec: SkinRepositoryCodec = SkinRepositoryCodec()
) {
    private fun envelope(): RecoveredLibraryEnvelope = store.read()?.let {
        runCatching { codec.decode(it) }.getOrNull()
    } ?: RecoveredLibraryEnvelope()

    fun snapshot(): RecoveredLibraryEnvelope = envelope()

    fun all(): List<RecoveredSkinPack> = envelope().packs
        .sortedWith(compareBy<RecoveredSkinPack>({ bankSortRank(it.bank) }, { it.order }, { it.menuOrder }, { it.id }))

    fun get(id: String): RecoveredSkinPack? = envelope().packs.firstOrNull { it.id == id }

    fun folders(): List<SkinFolder> = envelope().folders.sortedWith(compareBy<SkinFolder>({ it.order }, { it.id }))

    fun folders(parentId: String?): List<SkinFolder> = folders().filter { it.parentId == parentId }

    fun packs(parentId: String?): List<RecoveredSkinPack> = all().filter { it.folderId == parentId }

    fun createFolder(name: String, parentId: String?): SkinFolder? {
        val clean = name.trim()
        if (clean.isBlank()) return null
        val current = envelope()
        val validParent = parentId?.takeIf { p -> current.folders.any { it.id == p } }
        val folder = SkinFolder(
            id = "folder-${UUID.randomUUID()}",
            name = clean,
            order = current.folders.count { it.parentId == validParent },
            parentId = validParent
        )
        return folder.takeIf { replaceRecoveredCatalog(current.packs, current.folders + folder) }
    }

    fun createVehicle(name: String, parentId: String?): RecoveredSkinPack? {
        val clean = name.trim()
        if (clean.isBlank()) return null
        val current = envelope()
        val validParent = parentId?.takeIf { p -> current.folders.any { it.id == p } }
        val nextOrder = current.packs.count { it.bank == SkinBank.SKN }
        val pack = RecoveredSkinPack.empty(
            id = "vehicle-${UUID.randomUUID()}",
            name = clean,
            bank = SkinBank.SKN
        ).copy(order = nextOrder, menuOrder = nextOrder, folderId = validParent)
        return pack.takeIf { replaceRecoveredCatalog(current.packs + pack, current.folders) }
    }

    fun renameFolder(id: String, name: String): Boolean {
        val clean = name.trim()
        if (clean.isBlank()) return false
        val current = envelope()
        if (current.folders.none { it.id == id }) return false
        return replaceRecoveredCatalog(current.packs, current.folders.map { if (it.id == id) it.copy(name = clean) else it })
    }

    fun moveFolder(id: String, parentId: String?): Boolean {
        val current = envelope()
        val parents = current.folders.associate { it.id to it.parentId }
        if (!Hierarchy.canMove(id, parentId, parents)) return false
        val validParent = parentId?.takeIf { it in parents.keys }
        return replaceRecoveredCatalog(current.packs, current.folders.map { if (it.id == id) it.copy(parentId = validParent) else it })
    }

    fun replaceRecoveredCatalog(packs: List<RecoveredSkinPack>, folders: List<SkinFolder>): Boolean {
        val normalized = normalize(packs, folders)
        val encoded = runCatching { codec.encode(normalized) }.getOrElse { return false }
        return store.write(encoded)
    }

    fun updateSlot(id: String, slot: SkinSlot, value: RecoveredSlot): Boolean {
        val current = envelope()
        val index = current.packs.indexOfFirst { it.id == id }
        if (index < 0) return false
        val packs = current.packs.toMutableList()
        val old = packs[index]
        packs[index] = old.copy(slots = old.slots + (slot to value.copy(wireName = slot.wireName)))
        return replaceRecoveredCatalog(packs, current.folders)
    }

    fun rename(id: String, name: String): Boolean = mutatePack(id) { it.copy(name = name.trim().ifBlank { it.name }) }

    fun setLinkedToS3(id: String, linked: Boolean): Boolean = mutatePack(id) { it.copy(linkedToS3 = linked) }

    fun deletePack(id: String): Boolean {
        val current = envelope()
        if (current.packs.none { it.id == id }) return false
        return replaceRecoveredCatalog(current.packs.filterNot { it.id == id }, current.folders)
    }

    fun clearRemoteMetadata(id: String): Boolean = mutatePack(id) { pack ->
        pack.copy(slots = pack.slots.mapValues { (_, slot) ->
            slot.copy(
                sourceSha = null,
                renderSha = null,
                state = if (slot.localUri.isNullOrBlank()) LocalSourceState.EMPTY else LocalSourceState.LOCAL_LINKED
            )
        })
    }

    fun applyUploadHashes(
        id: String,
        sourceHashes: Map<SkinSlot, String>,
        renderHashes: Map<SkinSlot, String>
    ): Boolean = mutatePack(id) { pack ->
        pack.copy(slots = pack.slots.mapValues { (slot, value) ->
            value.copy(
                sourceSha = sourceHashes[slot] ?: value.sourceSha,
                renderSha = renderHashes[slot] ?: value.renderSha,
                state = if (value.localUri.isNullOrBlank()) {
                    if (sourceHashes[slot] != null || renderHashes[slot] != null || value.sourceSha != null || value.renderSha != null)
                        LocalSourceState.REMOTE_ONLY
                    else LocalSourceState.EMPTY
                } else LocalSourceState.LOCAL_LINKED
            )
        })
    }

    fun move(id: String, order: Int, menuOrder: Int = order, folderId: String? = null): Boolean =
        mutatePack(id) { it.copy(order = order.coerceAtLeast(0), menuOrder = menuOrder.coerceAtLeast(0), folderId = folderId) }

    fun moveToFolder(id: String, folderId: String?): Boolean {
        val current = envelope()
        val valid = folderId == null || current.folders.any { it.id == folderId }
        if (!valid) return false
        return mutatePack(id) { it.copy(folderId = folderId) }
    }

    /** Reorder a vehicle collection by dropping it on another vehicle.
     *  Crossing folder boundaries moves the dragged collection into the target folder.
     */
    fun reorderPack(draggedId: String, targetId: String): Boolean {
        if (draggedId == targetId) return true
        val current = envelope()
        val dragged = current.packs.firstOrNull { it.id == draggedId } ?: return false
        val target = current.packs.firstOrNull { it.id == targetId } ?: return false
        if (dragged.bank != target.bank) return false

        val bankOrder = current.packs
            .filter { it.bank == dragged.bank }
            .sortedWith(compareBy<RecoveredSkinPack>({ it.order }, { it.menuOrder }, { it.id }))
            .filterNot { it.id == draggedId }
            .toMutableList()
        val targetIndex = bankOrder.indexOfFirst { it.id == targetId }
        if (targetIndex < 0) return false
        bankOrder.add(targetIndex, dragged.copy(folderId = target.folderId))
        val rank = bankOrder.mapIndexed { index, pack -> pack.id to index }.toMap()

        val updated = current.packs.map { pack ->
            if (pack.bank != dragged.bank) pack
            else {
                val moved = if (pack.id == draggedId) pack.copy(folderId = target.folderId) else pack
                val order = rank[moved.id] ?: moved.order
                moved.copy(order = order, menuOrder = order)
            }
        }
        return replaceRecoveredCatalog(updated, current.folders)
    }

    fun saveFolders(folders: List<SkinFolder>): Boolean {
        val current = envelope()
        return replaceRecoveredCatalog(current.packs, folders)
    }

    private fun mutatePack(id: String, change: (RecoveredSkinPack) -> RecoveredSkinPack): Boolean {
        val current = envelope()
        val index = current.packs.indexOfFirst { it.id == id }
        if (index < 0) return false
        val packs = current.packs.toMutableList()
        packs[index] = change(packs[index])
        return replaceRecoveredCatalog(packs, current.folders)
    }

    private fun normalize(packs: List<RecoveredSkinPack>, folders: List<SkinFolder>): RecoveredLibraryEnvelope {
        val distinct = folders.distinctBy { it.id }
        val ids = distinct.map { it.id }.toSet()
        val initialParents = distinct.associate { f -> f.id to f.parentId?.takeIf { it in ids && it != f.id } }.toMutableMap()
        distinct.forEach { f ->
            val p = initialParents[f.id]
            if (!Hierarchy.canMove(f.id, p, initialParents)) initialParents[f.id] = null
        }
        val normalizedFolders = distinct
            .map { it.copy(parentId = initialParents[it.id]) }
            .groupBy { it.parentId }
            .flatMap { (_, group) -> group.sortedWith(compareBy<SkinFolder>({ it.order }, { it.id })).mapIndexed { i, f -> f.copy(order = i) } }
        val validFolderIds = normalizedFolders.map { it.id }.toSet()
        val normalizedPacks = BANK_DISPLAY_ORDER.flatMap { bank ->
            packs.filter { it.bank == bank }.distinctBy { it.id }
                .sortedWith(compareBy<RecoveredSkinPack>({ it.order }, { it.menuOrder }, { it.id }))
                .mapIndexed { i, p ->
                    val normalizedSlots = SkinSlot.entries.associateWith { slot ->
                        p.slots[slot]?.copy(wireName = slot.wireName)
                            ?: RecoveredSlot(slot.wireName, state = LocalSourceState.EMPTY)
                    }
                    p.copy(
                        order = i,
                        menuOrder = p.menuOrder.coerceAtLeast(0),
                        folderId = p.folderId?.takeIf { it in validFolderIds },
                        slots = normalizedSlots
                    )
                }
        }
        return RecoveredLibraryEnvelope(schemaVersion = 1, packs = normalizedPacks, folders = normalizedFolders)
    }

    companion object {
        private val BANK_DISPLAY_ORDER = listOf(SkinBank.LZR, SkinBank.SKN)
        private fun bankSortRank(bank: SkinBank): Int = BANK_DISPLAY_ORDER.indexOf(bank)
        const val PREFS_NAME = "truckfit_recovered_library_v1"
    }
}
