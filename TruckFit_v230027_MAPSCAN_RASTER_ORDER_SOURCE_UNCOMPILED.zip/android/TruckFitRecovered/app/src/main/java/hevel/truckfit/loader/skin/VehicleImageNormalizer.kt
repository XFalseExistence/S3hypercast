package hevel.truckfit.loader.skin

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Rect
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Local-only vehicle image normalization.
 *
 * v230025 contract:
 *  - preserve real transparency,
 *  - remove a reasonably uniform background connected to the outside edge,
 *  - crop every asset to its visible alpha bounds,
 *  - add symmetric transparent padding so the vehicle is centered on its own canvas.
 *
 * The normalized PNG is the single source used by Garage previews and S3 sync, so the phone
 * and S3 cannot disagree about where the vehicle sits inside the bitmap.
 */
object VehicleImageNormalizer {
    data class Result(
        val uri: Uri,
        val backgroundRemoved: Boolean,
        val trimmedCentered: Boolean = true
    )

    fun normalize(context: Context, source: Uri, packId: String, slot: SkinSlot): Result {
        val decoded = decodeScaled(context, source, 1600)
        val working = if (decoded.config == Bitmap.Config.ARGB_8888 && decoded.isMutable) {
            decoded
        } else {
            decoded.copy(Bitmap.Config.ARGB_8888, true).also { decoded.recycle() }
        }

        val pixels = IntArray(working.width * working.height)
        working.getPixels(pixels, 0, working.width, 0, 0, working.width, working.height)

        // A black/white square may still contain a handful of semi-transparent antialias pixels.
        // Looking only at the outside edge avoids the old "any transparent pixel => skip removal"
        // bug while preserving already-cut transparent PNGs.
        val opaqueEdgeRatio = opaqueEdgeRatio(pixels, working.width, working.height)
        val removed = if (opaqueEdgeRatio >= 0.72f) {
            removeConnectedBackground(pixels, working.width, working.height)
        } else {
            false
        }
        if (removed) {
            working.setPixels(pixels, 0, working.width, 0, 0, working.width, working.height)
        }

        val normalized = trimAndCenter(working)
        if (normalized !== working) working.recycle()

        val safePack = packId.replace(Regex("[^A-Za-z0-9._-]"), "_")
        val dir = File(context.filesDir, "vehicle_images/$safePack").apply { mkdirs() }
        val file = File(dir, "${slot.wireName.lowercase()}.png")
        FileOutputStream(file).use { out ->
            check(normalized.compress(Bitmap.CompressFormat.PNG, 100, out)) { "PNG encode failed" }
        }
        normalized.recycle()
        return Result(Uri.fromFile(file), removed, true)
    }

    private fun decodeScaled(context: Context, uri: Uri, maxDimension: Int): Bitmap {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        val readable = context.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, bounds)
            true
        } ?: false
        check(readable && bounds.outWidth > 0 && bounds.outHeight > 0) { "Unsupported image" }

        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / sample > maxDimension) sample *= 2
        val options = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        return context.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, options)
        } ?: error("Unable to decode image")
    }

    private fun opaqueEdgeRatio(pixels: IntArray, width: Int, height: Int): Float {
        if (width <= 1 || height <= 1) return 0f
        var opaque = 0
        var total = 0
        fun sample(index: Int) {
            total++
            if (Color.alpha(pixels[index]) >= 235) opaque++
        }
        for (x in 0 until width) {
            sample(x)
            sample((height - 1) * width + x)
        }
        for (y in 1 until height - 1) {
            sample(y * width)
            sample(y * width + width - 1)
        }
        return if (total == 0) 0f else opaque.toFloat() / total.toFloat()
    }

    /** Remove only a reasonably uniform background connected to an outside edge. */
    private fun removeConnectedBackground(pixels: IntArray, width: Int, height: Int): Boolean {
        if (width < 8 || height < 8) return false
        val patch = max(2, minOf(width, height) / 80)
        val corners = intArrayOf(
            averagePatch(pixels, width, height, 0, 0, patch),
            averagePatch(pixels, width, height, width - patch, 0, patch),
            averagePatch(pixels, width, height, 0, height - patch, patch),
            averagePatch(pixels, width, height, width - patch, height - patch, patch)
        )
        var spreadSq = 0
        for (a in corners.indices) {
            for (b in a + 1 until corners.size) {
                spreadSq = max(spreadSq, colorDistanceSq(corners[a], corners[b]))
            }
        }
        if (spreadSq > 95 * 95 * 3) return false

        val bg = averageColors(corners)
        val threshold = if (spreadSq < 35 * 35 * 3) 58 else 72
        val thresholdSq = threshold * threshold * 3
        val seen = BooleanArray(pixels.size)
        val queue = IntArray(pixels.size)
        var head = 0
        var tail = 0

        fun tryEnqueue(index: Int) {
            if (seen[index]) return
            val c = pixels[index]
            // Existing transparent edge pixels count as outside background and allow the flood
            // to continue around a partially-cut subject; opaque pixels still need to match bg.
            val candidate = Color.alpha(c) <= 12 || colorDistanceSq(c, bg) <= thresholdSq
            if (!candidate) return
            seen[index] = true
            queue[tail++] = index
        }

        for (x in 0 until width) {
            tryEnqueue(x)
            tryEnqueue((height - 1) * width + x)
        }
        for (y in 0 until height) {
            tryEnqueue(y * width)
            tryEnqueue(y * width + width - 1)
        }
        if (tail == 0) return false

        var removedOpaque = 0
        while (head < tail) {
            val idx = queue[head++]
            val x = idx % width
            val y = idx / width
            if (Color.alpha(pixels[idx]) > 12) removedOpaque++
            pixels[idx] = pixels[idx] and 0x00FFFFFF
            if (x > 0) tryEnqueue(idx - 1)
            if (x + 1 < width) tryEnqueue(idx + 1)
            if (y > 0) tryEnqueue(idx - width)
            if (y + 1 < height) tryEnqueue(idx + width)
        }
        return removedOpaque > (width + height)
    }

    /** Tight alpha crop + equal padding on all sides; no scaling or stretching. */
    private fun trimAndCenter(source: Bitmap): Bitmap {
        val width = source.width
        val height = source.height
        val pixels = IntArray(width * height)
        source.getPixels(pixels, 0, width, 0, 0, width, height)

        var left = width
        var top = height
        var right = -1
        var bottom = -1
        for (y in 0 until height) {
            val row = y * width
            for (x in 0 until width) {
                // Keep faint glow/antialiasing, but ignore effectively invisible alpha noise.
                if (Color.alpha(pixels[row + x]) >= 4) {
                    if (x < left) left = x
                    if (x > right) right = x
                    if (y < top) top = y
                    if (y > bottom) bottom = y
                }
            }
        }
        if (right < left || bottom < top) return source

        val subjectW = right - left + 1
        val subjectH = bottom - top + 1
        val pad = max(6, (max(subjectW, subjectH) * 0.045f).roundToInt())
        val outW = subjectW + pad * 2
        val outH = subjectH + pad * 2

        // If the source is already exactly normalized, avoid a redundant allocation.
        if (left == pad && top == pad && width == outW && height == outH) return source

        val out = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        canvas.drawBitmap(
            source,
            Rect(left, top, right + 1, bottom + 1),
            Rect(pad, pad, pad + subjectW, pad + subjectH),
            null
        )
        return out
    }

    private fun averagePatch(
        pixels: IntArray,
        width: Int,
        height: Int,
        startX: Int,
        startY: Int,
        size: Int
    ): Int {
        var r = 0L
        var g = 0L
        var b = 0L
        var n = 0L
        for (y in startY.coerceAtLeast(0) until (startY + size).coerceAtMost(height)) {
            for (x in startX.coerceAtLeast(0) until (startX + size).coerceAtMost(width)) {
                val c = pixels[y * width + x]
                if (Color.alpha(c) <= 12) continue
                r += Color.red(c)
                g += Color.green(c)
                b += Color.blue(c)
                n++
            }
        }
        // Transparent corner patches are uncommon on the opaque canvases for which this method
        // is called; keep a neutral fallback rather than divide by zero.
        return if (n == 0L) Color.TRANSPARENT else Color.rgb((r / n).toInt(), (g / n).toInt(), (b / n).toInt())
    }

    private fun averageColors(colors: IntArray): Int {
        val visible = colors.filter { Color.alpha(it) > 12 }
        val src = if (visible.isNotEmpty()) visible else colors.toList()
        return Color.rgb(
            src.sumOf { Color.red(it) } / src.size,
            src.sumOf { Color.green(it) } / src.size,
            src.sumOf { Color.blue(it) } / src.size
        )
    }

    private fun colorDistanceSq(a: Int, b: Int): Int {
        val dr = Color.red(a) - Color.red(b)
        val dg = Color.green(a) - Color.green(b)
        val db = Color.blue(a) - Color.blue(b)
        return dr * dr + dg * dg + db * db
    }
}
