package hevel.truckfit.loader.recovery

import android.content.ContentUris
import android.content.Context
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn

class MediaStoreSourceScanner(private val context:Context) {
    fun scan():Flow<SourceCandidate> = flow {
        val resolver=context.contentResolver
        val projection=arrayOf(MediaStore.Images.Media._ID,MediaStore.Images.Media.DISPLAY_NAME)
        val sort="${MediaStore.Images.Media.DISPLAY_NAME} ASC, ${MediaStore.Images.Media._ID} ASC"
        try {
            resolver.query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,projection,null,null,sort)?.use { c ->
                val idCol=c.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                val nameCol=c.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
                while(c.moveToNext()) {
                    val uri=ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,c.getLong(idCol))
                    emit(SourceCandidate(uri.toString(),c.getString(nameCol).orEmpty()))
                }
            }
        } catch (_:SecurityException) {
            // Permission denial is recoverable: the remote catalog remains usable.
        }
    }.flowOn(Dispatchers.IO)
}
