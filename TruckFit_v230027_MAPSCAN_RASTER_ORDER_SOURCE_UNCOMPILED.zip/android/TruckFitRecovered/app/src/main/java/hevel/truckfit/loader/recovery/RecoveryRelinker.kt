package hevel.truckfit.loader.recovery

import hevel.truckfit.loader.skin.*

object RecoveryRelinker {
    fun unresolvedHashes(repo:SkinRepository):Set<String> = repo.all().flatMap { pack ->
        pack.slots.values.filter { it.localUri==null && it.state!=LocalSourceState.EMPTY }.mapNotNull { it.sourceSha?.lowercase() }
    }.toSet()

    fun applyMatches(repo:SkinRepository,result:MatchResult):Int {
        var changed=0
        repo.all().forEach { pack ->
            pack.slots.forEach { (slot,value) ->
                val sha=value.sourceSha?.lowercase() ?: return@forEach
                val uri=result.matches[sha] ?: return@forEach
                if(value.localUri==uri && value.state==LocalSourceState.LOCAL_LINKED) return@forEach
                val alt=result.alternatives[sha].orEmpty()
                if(repo.updateSlot(pack.id,slot,value.copy(localUri=uri,state=LocalSourceState.LOCAL_LINKED,alternatives=alt))) changed++
            }
        }
        return changed
    }
}
