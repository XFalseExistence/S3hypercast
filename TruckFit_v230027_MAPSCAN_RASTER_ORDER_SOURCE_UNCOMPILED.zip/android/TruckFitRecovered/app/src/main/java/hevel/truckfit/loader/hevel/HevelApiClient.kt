package hevel.truckfit.loader.hevel

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.ConnectionPool
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

interface RecoveryReadApi {
    suspend fun skinStatus(): HevelResponse
    suspend fun skinIndex(): HevelResponse
    suspend fun skinManifest(id:String): HevelResponse
}
interface HevelMutatingApi {
    suspend fun activateSkin(id:String,bank:String):HevelResponse
    suspend fun setDefault():HevelResponse
    suspend fun deleteRemote(id:String):HevelResponse
    suspend fun clearSlot(id:String,slot:String):HevelResponse
    suspend fun uploadRaw(id:String,slot:String,kind:String,bytes:ByteArray):HevelResponse
    suspend fun postManifest(id:String,json:String):HevelResponse
    suspend fun postIndex(json:String):HevelResponse
    suspend fun mapStatus():HevelResponse
    suspend fun mapIndex():HevelResponse
    suspend fun mapManifest(id:String):HevelResponse
    suspend fun mapStage(id:String):HevelResponse
    suspend fun mapRasterStatus(id:String):HevelResponse
    suspend fun uploadMapImage(id:String,bytes:ByteArray):HevelResponse
    suspend fun uploadMapRaster(id:String,bytes:ByteArray):HevelResponse
    suspend fun postMapManifest(id:String,json:String):HevelResponse
    suspend fun postMapIndex(json:String):HevelResponse
    suspend fun activateMap(id:String):HevelResponse
    suspend fun setDefaultMap():HevelResponse
    suspend fun deleteRemoteMap(id:String):HevelResponse
    suspend fun exitLoader():HevelResponse
}

class HevelApiClient(
    baseUrl:String,
    private val client:OkHttpClient=OkHttpClient.Builder()
        .connectTimeout(4000,TimeUnit.MILLISECONDS)
        .readTimeout(30000,TimeUnit.MILLISECONDS)
        .writeTimeout(120000,TimeUnit.MILLISECONDS)
        // HEVEL's embedded HTTP server intentionally serves one request per TCP connection.
        // Do not pool a socket that the S3 has already closed.
        .connectionPool(ConnectionPool(0,1,TimeUnit.MILLISECONDS))
        .retryOnConnectionFailure(true)
        .build()
):RecoveryReadApi,HevelMutatingApi {
    private val base=baseUrl.trimEnd('/')
    private suspend fun execute(req:Request):HevelResponse = withContext(Dispatchers.IO) {
        client.newCall(req).execute().use { HevelResponse(it.code,it.body?.string().orEmpty()) }
    }
    private fun builder(url:String)=Request.Builder().url(url).header("Connection","close")
    private suspend fun get(path:String)=execute(builder(base+path).get().build())
    private suspend fun postForm(path:String,body:String="")=execute(builder(base+path).post(body.toRequestBody("application/x-www-form-urlencoded".toMediaType())).build())
    private suspend fun postJson(path:String,body:String)=execute(builder(base+path).post(body.toRequestBody("application/json".toMediaType())).build())
    override suspend fun skinStatus()=get("/api/skins/status")
    override suspend fun skinIndex()=get("/api/skins/index")
    override suspend fun skinManifest(id:String)=get("/api/skins/manifest?skin="+enc(id))
    override suspend fun activateSkin(id:String,bank:String)=postForm("/api/skins/activate","bank=${enc(bank)}&skin=${enc(id)}")
    override suspend fun setDefault()=postForm("/api/skins/default")
    override suspend fun deleteRemote(id:String)=postForm("/api/skins/delete","skin=${enc(id)}")
    override suspend fun clearSlot(id:String,slot:String)=postForm("/api/skins/clear","skin=${enc(id)}&slot=${enc(slot)}")
    override suspend fun uploadRaw(id:String,slot:String,kind:String,bytes:ByteArray)=execute(builder("$base/api/skins/upload?skin=${enc(id)}&slot=${enc(slot)}&kind=${enc(kind)}").post(bytes.toRequestBody("application/octet-stream".toMediaType())).build())
    override suspend fun postManifest(id:String,json:String)=postJson("/api/skins/manifest?skin=${enc(id)}",json)
    override suspend fun postIndex(json:String)=postJson("/api/skins/index",json)
    override suspend fun mapStatus()=get("/api/maps/status")
    override suspend fun mapIndex()=get("/api/maps/index")
    override suspend fun mapManifest(id:String)=get("/api/maps/manifest?map="+enc(id))
    override suspend fun mapStage(id:String)=get("/api/maps/stage?map="+enc(id))
    override suspend fun mapRasterStatus(id:String)=get("/api/maps/raster?map="+enc(id))
    override suspend fun uploadMapImage(id:String,bytes:ByteArray)=execute(builder("$base/api/maps/upload?map=${enc(id)}").post(bytes.toRequestBody("image/jpeg".toMediaType())).build())
    override suspend fun uploadMapRaster(id:String,bytes:ByteArray)=execute(builder("$base/api/maps/raster?map=${enc(id)}").post(bytes.toRequestBody("application/octet-stream".toMediaType())).build())
    override suspend fun postMapManifest(id:String,json:String)=postJson("/api/maps/manifest?map=${enc(id)}",json)
    override suspend fun postMapIndex(json:String)=postJson("/api/maps/index",json)
    override suspend fun activateMap(id:String)=postForm("/api/maps/activate","map=${enc(id)}")
    override suspend fun setDefaultMap()=postForm("/api/maps/default")
    override suspend fun deleteRemoteMap(id:String)=postForm("/api/maps/delete","map=${enc(id)}")
    override suspend fun exitLoader()=postForm("/api/loader/exit")
    private fun enc(v:String)=URLEncoder.encode(v,"UTF-8")
}
