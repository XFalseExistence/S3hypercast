package hevel.truckfit.loader.hevel

data class HevelResponse(val code:Int,val body:String) { val successful:Boolean get()=code in 200..299 }
