package hevel.truckfit.loader.recovery

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.collect
import java.io.InputStream
import java.security.MessageDigest

data class SourceCandidate(val uri:String,val displayName:String)
data class MatchResult(
    val matches:Map<String,String>,
    val alternatives:Map<String,List<String>>,
    val unresolved:Set<String>
)

fun interface SourceContentReader { fun open(candidate:SourceCandidate):InputStream }

interface RelinkCheckpoint {
    fun resolved():Map<String,String>
    fun save(sha:String,uri:String)
}

class InMemoryRelinkCheckpointStore:RelinkCheckpoint {
    private val map=linkedMapOf<String,String>()
    override fun resolved():Map<String,String> = map.toMap()
    override fun save(sha:String,uri:String) { map[sha]=uri }
}

class Sha256SourceMatcher(
    private val reader:SourceContentReader,
    private val checkpoint:RelinkCheckpoint
) {
    suspend fun match(unresolved:Set<String>,candidates:Flow<SourceCandidate>):MatchResult {
        val requested=unresolved.map { it.lowercase() }.toSet()
        val matches=checkpoint.resolved().filterKeys { it.lowercase() in requested }.toMutableMap()
        val alternatives=mutableMapOf<String,MutableSet<String>>()
        val pending=requested - matches.keys.map{it.lowercase()}.toSet()
        if (pending.isNotEmpty()) {
            candidates.collect { candidate ->
                val sha=runCatching { reader.open(candidate).use(::sha256) }.getOrNull() ?: return@collect
                if (sha !in requested) return@collect
                val previous=matches[sha]
                if (previous==null) {
                    matches[sha]=candidate.uri
                    checkpoint.save(sha,candidate.uri)
                } else if (previous != candidate.uri) {
                    val canonical=minOf(previous,candidate.uri)
                    val alternate=maxOf(previous,candidate.uri)
                    matches[sha]=canonical
                    checkpoint.save(sha,canonical)
                    alternatives.getOrPut(sha){linkedSetOf()}.add(alternate)
                }
            }
        }
        val unresolvedOut=requested - matches.keys.map{it.lowercase()}.toSet()
        return MatchResult(matches.toSortedMap(),alternatives.mapValues{it.value.toList().sorted()},unresolvedOut)
    }

    private fun sha256(input:InputStream):String {
        val md=MessageDigest.getInstance("SHA-256")
        val buf=ByteArray(64*1024)
        while(true) {
            val n=input.read(buf)
            if(n<=0) break
            md.update(buf,0,n)
        }
        return md.digest().joinToString(""){"%02x".format(it)}
    }
}
