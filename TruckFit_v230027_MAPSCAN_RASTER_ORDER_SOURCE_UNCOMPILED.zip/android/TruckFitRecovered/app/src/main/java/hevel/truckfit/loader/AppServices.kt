package hevel.truckfit.loader

import android.content.Context
import hevel.truckfit.loader.hevel.HevelApiClient
import hevel.truckfit.loader.skin.SharedPreferencesLibraryStore
import hevel.truckfit.loader.radarfield.RadarFieldRepository
import hevel.truckfit.loader.skin.SkinRepository

object AppServices {
    const val DEFAULT_HEVEL_BASE_URL="http://192.168.4.1"
    fun repository(context:Context):SkinRepository {
        val prefs=context.getSharedPreferences(SkinRepository.PREFS_NAME,Context.MODE_PRIVATE)
        return SkinRepository(SharedPreferencesLibraryStore(prefs))
    }
    fun radarFields(context:Context):RadarFieldRepository {
        val prefs=context.getSharedPreferences(RadarFieldRepository.PREFS_NAME,Context.MODE_PRIVATE)
        return RadarFieldRepository(prefs)
    }
    fun api()=HevelApiClient(DEFAULT_HEVEL_BASE_URL)
}
