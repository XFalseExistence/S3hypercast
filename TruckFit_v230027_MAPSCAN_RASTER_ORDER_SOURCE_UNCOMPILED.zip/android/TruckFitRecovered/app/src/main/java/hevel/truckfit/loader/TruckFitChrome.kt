package hevel.truckfit.loader

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

/** Shared TruckFit chrome, Garage blue + MapScan jade themes, safe-area handling, and HEVEL SF-style typography. */
object TruckFitChrome {
    private const val BLUE = 0xFF2F6D8FL
    private const val BLUE_DARK = 0xFF2F6D8FL
    private const val BLUE_DEEP = 0xFF2F6D8FL
    private const val BLUE_LIGHT = 0xFF2F6D8FL
    private const val BLUE_SOFT = 0xFF2F6D8FL

    private const val JADE = 0xFF52C7A5L
    private const val JADE_DARK = 0xFF27856FL
    private const val JADE_DEEP = 0xFF176351L
    private const val JADE_LIGHT = 0xFF9BE6CBL
    private const val JADE_SOFT = 0xFF78D9B8L
    private const val PANEL = 0xFFF0F4F7L
    private const val PANEL_LIGHT = 0xFFFFFFFFL
    private const val PANEL_BORDER = 0xFFA7BAC5L
    private const val TEXT = 0xFF111111L

    private val sfTextRegular: Typeface by lazy { Typeface.create("sans-serif", Typeface.NORMAL) }
    private val sfTextMedium: Typeface by lazy { Typeface.create("sans-serif-medium", Typeface.NORMAL) }
    private val sfDisplaySemibold: Typeface by lazy { Typeface.create("sans-serif", Typeface.BOLD) }

    fun installSafeArea(activity: Activity, root: View) = installSafeArea(activity, root, BLUE_DEEP, false)

    fun installMapScanSafeArea(activity: Activity, root: View) = installSafeArea(activity, root, JADE, true)

    private fun installSafeArea(activity: Activity, root: View, statusColor: Long, darkStatusIcons: Boolean) {
        WindowCompat.setDecorFitsSystemWindows(activity.window, false)
        activity.window.statusBarColor = statusColor.toInt()
        activity.window.navigationBarColor = PANEL.toInt()
        WindowInsetsControllerCompat(activity.window, root).apply {
            isAppearanceLightStatusBars = darkStatusIcons
            isAppearanceLightNavigationBars = true
        }
        applyTypography(root)
        val baseLeft = root.paddingLeft
        val baseTop = root.paddingTop
        val baseRight = root.paddingRight
        val baseBottom = root.paddingBottom
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            view.setPadding(
                baseLeft + bars.left,
                baseTop + bars.top,
                baseRight + bars.right,
                baseBottom + bars.bottom
            )
            insets
        }
        ViewCompat.requestApplyInsets(root)
    }

    fun styleScreen(root: View) {
        root.setBackgroundColor(PANEL.toInt())
    }

    fun styleLibraryScreen(root: View) {
        root.setBackgroundColor(0xFF2B2D31.toInt())
    }

    fun styleHeader(view: View) {
        view.background = gradient(BLUE_LIGHT, BLUE_DARK, 8f, BLUE_DEEP.toInt())
    }

    fun styleMapScanHeader(view: View) {
        view.background = gradient(JADE_LIGHT, JADE_DARK, 8f, JADE_DEEP.toInt())
    }

    fun stylePanel(view: View) {
        view.background = gradient(PANEL_LIGHT, PANEL, 8f, PANEL_BORDER.toInt())
    }

    fun stylePrimary(button: Button) {
        button.isAllCaps = true
        button.setTextColor(Color.WHITE)
        button.typeface = sfDisplaySemibold
        button.letterSpacing = -0.005f
        button.background = gradient(BLUE_LIGHT, BLUE_DARK, 9f, BLUE_DEEP.toInt())
        button.stateListAnimator = null
    }

    fun styleSecondary(button: Button) {
        button.isAllCaps = true
        button.setTextColor(Color.WHITE)
        button.typeface = sfTextMedium
        button.letterSpacing = -0.005f
        button.background = gradient(BLUE_SOFT, BLUE, 9f, BLUE_DARK.toInt())
        button.stateListAnimator = null
    }

    fun styleMapScanPrimary(button: Button) {
    button.isAllCaps = true
    button.setTextColor(Color.BLACK)
    button.typeface = sfDisplaySemibold
    button.letterSpacing = -0.005f
    button.background = gradient(JADE_LIGHT, JADE_DARK, 9f, JADE_DEEP.toInt())
    button.stateListAnimator = null
}

fun styleMapScanSecondary(button: Button) {
    button.isAllCaps = true
    button.setTextColor(Color.BLACK)
    button.typeface = sfTextMedium
    button.letterSpacing = -0.005f
    button.background = gradient(JADE_SOFT, JADE, 9f, JADE_DARK.toInt())
    button.stateListAnimator = null
}

    fun styleBodyText(textView: TextView) {
        textView.setTextColor(TEXT.toInt())
        val wasBold = textView.typeface?.style?.and(Typeface.BOLD) != 0
        textView.typeface = if (wasBold) sfDisplaySemibold else sfTextRegular
        textView.letterSpacing = if (textView.textSize / textView.resources.displayMetrics.scaledDensity >= 22f) -0.015f else -0.005f
    }

    fun displayTypeface(): Typeface = sfDisplaySemibold

    fun flashCyan(view: View) {
        val previous = view.background
        val pulse = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 18f
            setColor(0xFF00E5FF.toInt())
            setStroke(2, 0xFFB9FFFF.toInt())
        }
        view.background = pulse
        view.postDelayed({
            if (view.background === pulse) view.background = previous
        }, 1000L)
    }

    private fun applyTypography(view: View) {
        if (view is TextView) {
            val wasBold = view.typeface?.style?.and(Typeface.BOLD) != 0
            view.typeface = when {
                view is Button -> sfTextMedium
                wasBold -> sfDisplaySemibold
                else -> sfTextRegular
            }
            val sp = view.textSize / view.resources.displayMetrics.scaledDensity
            view.letterSpacing = if (sp >= 22f) -0.015f else -0.005f
        }
        if (view is ViewGroup) {
            for (i in 0 until view.childCount) applyTypography(view.getChildAt(i))
        }
    }

    private fun gradient(top: Long, bottom: Long, radiusDp: Float, stroke: Int): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(top.toInt(), bottom.toInt())).apply {
            cornerRadius = radiusDp * 2.5f
            setStroke(1, stroke)
        }
}
