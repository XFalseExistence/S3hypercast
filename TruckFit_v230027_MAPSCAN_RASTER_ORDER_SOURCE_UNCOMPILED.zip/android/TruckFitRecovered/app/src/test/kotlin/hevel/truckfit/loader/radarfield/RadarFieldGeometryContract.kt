package hevel.truckfit.loader.radarfield

fun main() {
    check(kotlin.math.abs(RadarFieldGeometry.visibleFieldFeet(0.5) - 40.0) < 0.001)
    check(kotlin.math.abs(RadarFieldGeometry.visibleFieldFeet(1.0) - 20.0) < 0.001)
    check(kotlin.math.abs(RadarFieldGeometry.visibleFieldFeet(1.5) - 13.333333) < 0.001)
    check(kotlin.math.abs(RadarFieldGeometry.visibleFieldFeet(2.0) - 10.0) < 0.001)
    check(RadarFieldGeometry.masterWidthFt == 80.0)
    check(RadarFieldGeometry.zoomLevels == listOf(0.5, 1.0, 1.5, 2.0))
}
