package hevel.truckfit.loader.radarfield

fun main() {
    val center = GeoCenter(38.7796970, -121.3678215)
    val bounds = RadarFieldGeometry.boundsForFeet(center)
    val w = EsriTileWindow.forBounds(bounds, zoom = 21)
    check(w.zoom == 21)
    check(w.minTileX <= w.maxTileX)
    check(w.minTileY <= w.maxTileY)
    check(w.tileCount in 1..9) { "unexpected tile count ${w.tileCount}" }
    check(w.cropLeftPx >= 0.0 && w.cropTopPx >= 0.0)
    check(w.cropRightPx > w.cropLeftPx)
    check(w.cropBottomPx > w.cropTopPx)
    check(w.cropRightPx <= w.mosaicWidthPx + 0.001)
    check(w.cropBottomPx <= w.mosaicHeightPx + 0.001)
    val urls = w.tiles.map { EsriTileWindow.tileUrl(it) }
    check(urls.isNotEmpty())
    check(urls.all { it.startsWith("https://services.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/21/") })
    check(urls.none { it.contains("/export") })
    println("PASS esri tile window contract: ${w.tileCount} tiles, crop=${w.cropWidthPx}x${w.cropHeightPx}")
}
