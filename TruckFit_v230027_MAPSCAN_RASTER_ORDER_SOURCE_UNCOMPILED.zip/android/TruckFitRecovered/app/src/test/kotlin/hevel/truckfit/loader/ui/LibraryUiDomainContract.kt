package hevel.truckfit.loader.ui

fun main() {
    check(Hierarchy.parentOf("child", mapOf("child" to "parent")) == "parent")
    check(Hierarchy.pathToRoot("leaf", mapOf("leaf" to "child", "child" to "root", "root" to null)) == listOf("root", "child", "leaf"))
    check(!Hierarchy.canMove("root", "leaf", mapOf("leaf" to "child", "child" to "root", "root" to null)))
    check(Hierarchy.canMove("leaf", "root", mapOf("leaf" to "child", "child" to "root", "root" to null)))

    val t0 = CropTransform.fit(imageWidth = 1600f, imageHeight = 1200f, frameWidth = 800f, frameHeight = 800f)
    check(kotlin.math.abs(t0.scale - (800f / 1200f)) < 0.0001f)
    check(kotlin.math.abs(t0.offsetX - ((800f - 1600f * t0.scale) / 2f)) < 0.0001f)
    check(kotlin.math.abs(t0.offsetY) < 0.0001f)

    val zoomed = t0.zoomBy(1.5f, pivotX = 400f, pivotY = 400f)
    check(zoomed.scale > t0.scale)
    check(kotlin.math.abs((zoomed.offsetX - 400f) - (t0.offsetX - 400f) * 1.5f) < 0.01f)

    val dragged = zoomed.panBy(5000f, -5000f).clamp(1600f, 1200f, 800f, 800f)
    val scaledW = 1600f * dragged.scale
    val scaledH = 1200f * dragged.scale
    check(dragged.offsetX <= 0f && dragged.offsetX >= 800f - scaledW - 0.01f)
    check(dragged.offsetY <= 0f && dragged.offsetY >= 800f - scaledH - 0.01f)
}
