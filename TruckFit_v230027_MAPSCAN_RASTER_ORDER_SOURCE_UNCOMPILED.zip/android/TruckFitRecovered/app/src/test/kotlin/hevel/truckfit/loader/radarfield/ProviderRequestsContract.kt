package hevel.truckfit.loader.radarfield

fun main() {
    val center = GeoCenter(38.8, -121.3)
    val bounds = RadarFieldGeometry.boundsForFeet(center, 80.0, 80.0)
    check(kotlin.math.abs((bounds.north + bounds.south) / 2.0 - center.lat) < 1e-9)
    check(kotlin.math.abs((bounds.east + bounds.west) / 2.0 - center.lon) < 1e-9)
    check(bounds.north > bounds.south)
    check(bounds.east > bounds.west)

    val esri = RadarProviderRequests.requestFor(RadarProviderId.ESRI, center, bounds, ProviderCredentials())
    check(esri.url.contains("World_Imagery/MapServer/tile/{z}/{y}/{x}"))
    check(!esri.url.contains("/export"))

    val mapboxMissing = RadarProviderRequests.requestFor(RadarProviderId.MAPBOX, center, bounds, ProviderCredentials())
    check(mapboxMissing.unavailableReason != null)
    val mapbox = RadarProviderRequests.requestFor(RadarProviderId.MAPBOX, center, bounds, ProviderCredentials(mapboxToken = "pk.test"))
    check(mapbox.url.contains("mapbox/satellite-v9/static"))
    check(mapbox.url.contains("access_token=pk.test"))

    val googleOff = RadarProviderRequests.requestFor(RadarProviderId.GOOGLE, center, bounds, ProviderCredentials(googleKey = "g", googleEnabled = false))
    check(googleOff.unavailableReason != null)
    val google = RadarProviderRequests.requestFor(RadarProviderId.GOOGLE, center, bounds, ProviderCredentials(googleKey = "g", googleEnabled = true))
    check(google.url.contains("maptype=satellite"))
    check(google.url.contains("key=g"))

    val azure = RadarProviderRequests.requestFor(RadarProviderId.AZURE, center, bounds, ProviderCredentials(azureCredential = "abc", azureEnabled = true))
    check(azure.url.contains("tilesetId=microsoft.imagery"))
    check(azure.headers["subscription-key"] == "abc")
    check(azure.url.contains("width=640"))
}
