package hevel.truckfit.loader.ui

fun main() {
    check(SkinLibraryRules.previewWireName == "3D_REAR")
    check(SkinLibraryRules.displayName("SKN", "Vapor") == "Vapor")
    check(SkinLibraryRules.displayName("LZR", "Laser Grid") == "Laser Grid")
    check(SkinLibraryRules.displayName("SKN", "SKN • A605") == "A605")
    check(SkinLibraryRules.status(linked = 6, remote = 0) == "6/6 LINKED • 0 REMOTE")
}
