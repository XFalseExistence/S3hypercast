package hevel.truckfit.loader.ui

import org.junit.Assert.*
import org.junit.Test

class LibraryUiRulesTest {
    @Test fun nestedHierarchyRejectsMovingParentIntoDescendant() {
        val parents = mapOf("leaf" to "child", "child" to "root", "root" to null)
        assertFalse(Hierarchy.canMove("root", "leaf", parents))
        assertTrue(Hierarchy.canMove("leaf", "root", parents))
        assertEquals(listOf("root", "child", "leaf"), Hierarchy.pathToRoot("leaf", parents))
    }

    @Test fun cropUsesUniformScaleAndClampsToFrame() {
        val fitted = CropTransform.fit(1600f, 1200f, 800f, 800f)
        assertEquals(800f / 1200f, fitted.scale, 0.0001f)
        val moved = fitted.zoomBy(1.5f, 400f, 400f).panBy(5000f, -5000f).clamp(1600f, 1200f, 800f, 800f)
        assertTrue(moved.offsetX <= 0f)
        assertTrue(moved.offsetY <= 0f)
        assertTrue(moved.offsetX >= 800f - 1600f * moved.scale - 0.01f)
        assertTrue(moved.offsetY >= 800f - 1200f * moved.scale - 0.01f)
    }

    @Test fun skinCardsUseSouthPreviewAndNoBankPrefix() {
        assertEquals("3D_REAR", SkinLibraryRules.previewWireName)
        assertEquals("A605", SkinLibraryRules.displayName("SKN", "SKN • A605"))
        assertEquals("6/6 LINKED • 0 REMOTE", SkinLibraryRules.status(6, 0))
    }
}
