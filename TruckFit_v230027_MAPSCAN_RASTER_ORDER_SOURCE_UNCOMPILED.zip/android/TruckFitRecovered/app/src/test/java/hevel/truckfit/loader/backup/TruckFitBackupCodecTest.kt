package hevel.truckfit.loader.backup

import hevel.truckfit.loader.skin.*
import org.junit.Assert.*
import org.junit.Test

class TruckFitBackupCodecTest {
    @Test fun roundTripPreservesMetadataWithoutImageBytes() {
        val lib=RecoveredLibraryEnvelope(packs=listOf(RecoveredSkinPack(
            "abc","Vapor",SkinBank.SKN,order=3,menuOrder=4,folderId="folder-x",
            slots=mapOf(SkinSlot.TOP_3D to RecoveredSlot("3D_TOP","source","render","content://image",LocalSourceState.LOCAL_LINKED))
        )),folders=listOf(SkinFolder("folder-x","Laser",0)))
        val codec=TruckFitBackupCodec(); val text=codec.encode(lib)
        assertFalse(text.contains("iVBOR")); assertFalse(text.contains("imageBytes"))
        val round=codec.decode(text)
        assertEquals("abc",round.library.packs.single().id)
        assertEquals("source",round.library.packs.single().slots[SkinSlot.TOP_3D]!!.sourceSha)
        assertEquals("Laser",round.library.folders.single().name)
    }
}
