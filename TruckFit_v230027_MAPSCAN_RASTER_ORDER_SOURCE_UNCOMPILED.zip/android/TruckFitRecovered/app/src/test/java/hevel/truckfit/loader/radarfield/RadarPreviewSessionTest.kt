package hevel.truckfit.loader.radarfield

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class RadarPreviewSessionTest {
    @Test fun sameCenterPreservesPreviewsAcrossScreenRecreation() {
        RadarPreviewSession.clear()
        val center = GeoCenter(38.7796970, -121.3678215)
        RadarPreviewSession.begin(center)
        RadarPreviewSession.put(RadarProviderId.MAPBOX, "/cache/mapbox.img", "© Mapbox")
        RadarPreviewSession.begin(center)

        val restored = RadarPreviewSession.snapshot()
        assertEquals(center, restored.center)
        assertEquals("/cache/mapbox.img", restored.previews[RadarProviderId.MAPBOX]?.filePath)
    }

    @Test fun changingCenterDropsOldProviderImages() {
        RadarPreviewSession.clear()
        RadarPreviewSession.begin(GeoCenter(38.0, -121.0))
        RadarPreviewSession.put(RadarProviderId.ESRI, "/cache/esri.img", "Esri")
        RadarPreviewSession.begin(GeoCenter(39.0, -121.0))

        assertTrue(RadarPreviewSession.snapshot().previews.isEmpty())
    }
}
