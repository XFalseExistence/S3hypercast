package hevel.truckfit.loader.radarfield

import org.junit.Assert.*
import org.junit.Test

class RadarProviderRequestsTest {
    @Test fun allProvidersShareOneEightyFootCenterAndRequireOptInCredentials() {
        val center = GeoCenter(38.8, -121.3)
        val bounds = RadarFieldGeometry.boundsForFeet(center)
        assertEquals(center.lat, (bounds.north + bounds.south) / 2.0, 1e-9)
        assertEquals(center.lon, (bounds.east + bounds.west) / 2.0, 1e-9)

        val esri = RadarProviderRequests.requestFor(RadarProviderId.ESRI, center, bounds, ProviderCredentials())
        assertTrue(esri.url.contains("World_Imagery/MapServer/tile/{z}/{y}/{x}"))
        assertNull(esri.unavailableReason)

        val noMapbox = RadarProviderRequests.requestFor(RadarProviderId.MAPBOX, center, bounds, ProviderCredentials())
        assertNotNull(noMapbox.unavailableReason)
        val mapbox = RadarProviderRequests.requestFor(RadarProviderId.MAPBOX, center, bounds, ProviderCredentials(mapboxToken = "pk.test"))
        assertTrue(mapbox.url.contains("mapbox/satellite-v9/static"))
        assertTrue(mapbox.url.contains("access_token=pk.test"))

        val googleOff = RadarProviderRequests.requestFor(RadarProviderId.GOOGLE, center, bounds, ProviderCredentials(googleKey = "g", googleEnabled = false))
        assertNotNull(googleOff.unavailableReason)
        val google = RadarProviderRequests.requestFor(RadarProviderId.GOOGLE, center, bounds, ProviderCredentials(googleKey = "g", googleEnabled = true))
        assertTrue(google.url.contains("maptype=satellite"))
        assertTrue(google.url.contains("key=g"))

        val azureOff = RadarProviderRequests.requestFor(RadarProviderId.AZURE, center, bounds, ProviderCredentials(azureCredential = "a", azureEnabled = false))
        assertNotNull(azureOff.unavailableReason)
        val azure = RadarProviderRequests.requestFor(RadarProviderId.AZURE, center, bounds, ProviderCredentials(azureCredential = "a", azureEnabled = true))
        assertEquals("a", azure.headers["subscription-key"])
        assertTrue(azure.url.contains("width=640"))
    }

    @Test fun googleCoverageUsesAnIntegerZoomAndAtMost640LogicalPixels() {
        val (zoom, size) = RadarProviderRequests.googleZoomAndSize(38.8, 80.0)
        assertTrue(zoom in 0..22)
        assertTrue(size in 180..640)
    }
}
