package hevel.truckfit.loader.skin

import org.junit.Assert.*
import org.junit.Test

class SkinRepositoryTest {
    private class MemoryStore(var value: String? = null, var acceptWrites: Boolean = true) : LibraryStore {
        override fun read(): String? = value
        override fun write(value: String): Boolean { if (!acceptWrites) return false; this.value = value; return true }
    }

    @Test fun sixSlotsMatchW222WireOrderExactly() {
        assertEquals(listOf("3D_TOP","2D_TOP","3D_TACT","2D_TACT","3D_REAR","2D_REAR"), SkinSlot.entries.map { it.wireName })
    }

    @Test fun remoteOnlyAndFolderStateSurviveRestart() {
        val store = MemoryStore()
        val repo = SkinRepository(store)
        val pack = RecoveredSkinPack(
            id="abc123", name="Vapor", bank=SkinBank.SKN, order=0, menuOrder=2, folderId="folder-laser",
            slots=SkinSlot.entries.associateWith { RecoveredSlot(it.wireName, "sha-${it.wireName}", "render-${it.wireName}", null, LocalSourceState.REMOTE_ONLY) }
        )
        assertTrue(repo.replaceRecoveredCatalog(listOf(pack), listOf(SkinFolder("folder-laser","Laser",0))))
        val reloaded = SkinRepository(store)
        assertEquals(SkinBank.SKN, reloaded.get("abc123")!!.bank)
        assertEquals("folder-laser", reloaded.get("abc123")!!.folderId)
        assertEquals(LocalSourceState.REMOTE_ONLY, reloaded.get("abc123")!!.slots[SkinSlot.TOP_3D]!!.state)
        assertEquals("Laser", reloaded.folders().single().name)
    }

    @Test fun failedAtomicReplacementLeavesPriorCatalogUntouched() {
        val store = MemoryStore()
        val repo = SkinRepository(store)
        assertTrue(repo.replaceRecoveredCatalog(listOf(RecoveredSkinPack.empty("old","Old",SkinBank.LZR)), emptyList()))
        store.acceptWrites = false
        assertFalse(repo.replaceRecoveredCatalog(listOf(RecoveredSkinPack.empty("new","New",SkinBank.SKN)), emptyList()))
        store.acceptWrites = true
        assertNotNull(SkinRepository(store).get("old"))
        assertNull(SkinRepository(store).get("new"))
    }

    @Test fun orderingIsDeterministic() {
        val store = MemoryStore()
        val repo = SkinRepository(store)
        repo.replaceRecoveredCatalog(listOf(
            RecoveredSkinPack.empty("b","B",SkinBank.SKN).copy(order=1),
            RecoveredSkinPack.empty("a","A",SkinBank.SKN).copy(order=0),
            RecoveredSkinPack.empty("z","Z",SkinBank.LZR).copy(order=0)
        ), emptyList())
        assertEquals(listOf("z","a","b"), repo.all().map { it.id })
    }
}
