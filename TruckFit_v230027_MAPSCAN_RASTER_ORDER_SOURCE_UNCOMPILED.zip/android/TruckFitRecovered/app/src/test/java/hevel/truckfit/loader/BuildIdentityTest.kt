package hevel.truckfit.loader

import org.junit.Assert.assertEquals
import org.junit.Test

class BuildIdentityTest {
    @Test fun recoveredPackageIdentityIsPermanent() {
        assertEquals("hevel.truckfit.loader", BuildConfig.APPLICATION_ID)
    }
}
