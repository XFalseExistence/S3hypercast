package hevel.truckfit.loader.recovery

import hevel.truckfit.loader.hevel.HevelApiClient
import hevel.truckfit.loader.skin.*
import kotlinx.coroutines.test.runTest
import okhttp3.mockwebserver.MockResponse
import okhttp3.mockwebserver.MockWebServer
import org.junit.Assert.*
import org.junit.Test

class RemoteCatalogImporterTest {
    private class MemoryStore : LibraryStore { var raw:String?=null; override fun read()=raw; override fun write(value:String)=true.also{raw=value} }

    @Test fun importsSchema2FoldersAndContinuesPastMissingManifest() = runTest {
        val server=MockWebServer(); server.start()
        server.enqueue(MockResponse().setResponseCode(200).setBody("""{"schema":2,"lzr":["l1"],"skn":["s1","s2"],"menu":[{"type":"folder","name":"Laser","items":["l1"]},{"type":"skin","id":"s1"},{"type":"skin","id":"s2"}]}"""))
        server.enqueue(MockResponse().setResponseCode(200).setBody("""{"id":"l1","name":"Laser Red","bank":"LZR","slots":{"3D_TOP":{"sourceSha":"aaa","renderSha":"bbb"}}}"""))
        server.enqueue(MockResponse().setResponseCode(200).setBody("""{"id":"s1","name":"Vapor","bank":"SKN","slots":{"2D_TOP":{"sourceSha":"ccc","renderSha":"ddd"}}}"""))
        server.enqueue(MockResponse().setResponseCode(404).setBody("{}"))
        val repo=SkinRepository(MemoryStore())
        val result=RemoteCatalogImporter(HevelApiClient(server.url("/").toString()),repo).import()
        assertEquals(3,result.packs.size)
        assertEquals("Laser",result.folders.single().name)
        assertEquals("aaa",repo.get("l1")!!.slots[SkinSlot.TOP_3D]!!.sourceSha)
        assertEquals(LocalSourceState.REMOTE_METADATA_MISSING,repo.get("s2")!!.slots[SkinSlot.TOP_3D]!!.state)
        assertTrue(result.warnings.any{it.contains("s2")})
        repeat(4) {
            val path=server.takeRequest().path ?: ""
            assertFalse(path.contains("upload")); assertFalse(path.contains("clear")); assertFalse(path.contains("delete")); assertFalse(path.contains("activate"))
        }
        server.shutdown()
    }
}
