package hevel.truckfit.loader.radarfield

import org.junit.Assert.assertEquals
import org.junit.Test

class RadarFieldGeometryTest {
    @Test fun fixedZoomsUseFeetNotPixels() {
        assertEquals(40.0, RadarFieldGeometry.visibleFieldFeet(0.5), 0.001)
        assertEquals(20.0, RadarFieldGeometry.visibleFieldFeet(1.0), 0.001)
        assertEquals(13.333333, RadarFieldGeometry.visibleFieldFeet(1.5), 0.001)
        assertEquals(10.0, RadarFieldGeometry.visibleFieldFeet(2.0), 0.001)
        assertEquals(listOf(0.5, 1.0, 1.5, 2.0), RadarFieldGeometry.zoomLevels)
        assertEquals(80.0, RadarFieldGeometry.masterWidthFt, 0.001)
        assertEquals(68.0, RadarFieldGeometry.sensorEnvelopeLengthFt, 0.001)
        assertEquals(48.0, RadarFieldGeometry.sensorEnvelopeWidthFt, 0.001)
        assertEquals(20.0, RadarFieldGeometry.proximityCornerRadiusFt, 0.001)
    }
}
