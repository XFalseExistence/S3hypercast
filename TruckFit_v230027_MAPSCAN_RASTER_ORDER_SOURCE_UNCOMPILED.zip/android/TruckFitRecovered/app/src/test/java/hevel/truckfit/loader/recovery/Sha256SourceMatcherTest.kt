package hevel.truckfit.loader.recovery

import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.test.runTest
import org.junit.Assert.*
import org.junit.Test
import java.io.ByteArrayInputStream
import java.security.MessageDigest

class Sha256SourceMatcherTest {
    private fun sha(bytes:ByteArray)=MessageDigest.getInstance("SHA-256").digest(bytes).joinToString(""){"%02x".format(it)}
    @Test fun exactHashWinsRegardlessOfFilenameAndDuplicatesAreDeterministic()=runTest {
        val bytes="same-image".toByteArray(); val target=sha(bytes)
        val reader=SourceContentReader { c -> ByteArrayInputStream(if(c.uri.contains("match")) bytes else "nope".toByteArray()) }
        val cp=InMemoryRelinkCheckpointStore()
        val matcher=Sha256SourceMatcher(reader,cp)
        val result=matcher.match(setOf(target),flowOf(
            SourceCandidate("content://z-match","wrong-name.jpg"),
            SourceCandidate("content://a-match","other.png"),
            SourceCandidate("content://nonsense","same-name.png")
        ))
        assertEquals("content://a-match",result.matches[target])
        assertEquals(listOf("content://z-match"),result.alternatives[target])
        assertTrue(result.unresolved.isEmpty())
    }

    @Test fun checkpointedHashIsNotReadAgain()=runTest {
        val bytes="x".toByteArray(); val target=sha(bytes)
        val cp=InMemoryRelinkCheckpointStore().apply{save(target,"content://saved")}
        var opens=0
        val matcher=Sha256SourceMatcher(SourceContentReader { opens++; ByteArrayInputStream(bytes) },cp)
        val result=matcher.match(setOf(target),flowOf(SourceCandidate("content://new","whatever")))
        assertEquals(0,opens); assertEquals("content://saved",result.matches[target])
    }
}
