package hevel.truckfit.loader.transfer

import hevel.truckfit.loader.recovery.RemoteCatalogImporter
import org.junit.Assert.assertFalse
import org.junit.Test

class RecoverySafetyTest {
    @Test fun recoveryImporterTypeCannotCallMutatingTransferApi() {
        val names=RemoteCatalogImporter::class.java.declaredFields.map{it.type.name}.joinToString(" ")
        assertFalse(names.contains("SkinTransfer"))
        assertFalse(names.contains("HevelMutatingApi"))
    }
}
