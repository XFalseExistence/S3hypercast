package hevel.truckfit.loader.transfer

import hevel.truckfit.loader.skin.*
import org.junit.Assert.*
import org.junit.Test

class SyncPlannerTest {
    private fun pack(source:String?,render:String?,uri:String?)=RecoveredSkinPack(
        "skin1","Skin",SkinBank.SKN,slots=SkinSlot.entries.associateWith { s ->
            if(s==SkinSlot.TOP_3D) RecoveredSlot(s.wireName,source,render,uri,if(uri==null) LocalSourceState.REMOTE_ONLY else LocalSourceState.LOCAL_LINKED)
            else RecoveredSlot(s.wireName,state=LocalSourceState.EMPTY)
        })
    @Test fun unchangedHashesPlanZeroUploads() {
        val p=pack("aaa","bbb","content://one")
        val remote=RemoteManifestSnapshot(mapOf(SkinSlot.TOP_3D to RemoteSlotSnapshot("aaa","bbb")))
        assertTrue(SyncPlanner.plan(p,remote).isEmpty())
    }
    @Test fun oneChangedLocalSlotPlansExactlyOneUpload() {
        val p=pack("new","render-new","content://one")
        val remote=RemoteManifestSnapshot(mapOf(SkinSlot.TOP_3D to RemoteSlotSnapshot("old","old-render")))
        assertEquals(listOf(SkinSlot.TOP_3D),SyncPlanner.plan(p,remote).map{it.slot})
    }
    @Test fun remoteOnlySkinNeedsNoUploadToBeActivatable() {
        assertTrue(SyncPlanner.plan(pack("aaa","bbb",null),RemoteManifestSnapshot(emptyMap())).isEmpty())
    }
}
