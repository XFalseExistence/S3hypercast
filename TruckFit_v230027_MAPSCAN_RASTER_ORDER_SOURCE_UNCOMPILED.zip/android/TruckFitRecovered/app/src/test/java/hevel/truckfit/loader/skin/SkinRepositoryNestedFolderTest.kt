package hevel.truckfit.loader.skin

import org.junit.Assert.*
import org.junit.Test

class SkinRepositoryNestedFolderTest {
    private class MemoryStore(var value: String? = null) : LibraryStore {
        override fun read(): String? = value
        override fun write(value: String): Boolean { this.value = value; return true }
    }

    @Test fun legacyFolderJsonWithoutParentStillDecodesAtRoot() {
        val store = MemoryStore("""{"schemaVersion":1,"packs":[],"folders":[{"id":"f1","name":"OLD","order":0}]}""")
        val repo = SkinRepository(store)
        assertEquals(1, repo.folders(null).size)
        assertNull(repo.folders().single().parentId)
    }

    @Test fun nestedFoldersPersistAndCyclesAreRejected() {
        val repo = SkinRepository(MemoryStore())
        val root = requireNotNull(repo.createFolder("ROOT FOLDER", null))
        val child = requireNotNull(repo.createFolder("CHILD", root.id))
        assertEquals(root.id, repo.folders().first { it.id == child.id }.parentId)
        assertFalse(repo.moveFolder(root.id, child.id))
        assertNull(repo.folders().first { it.id == root.id }.parentId)
    }
}
