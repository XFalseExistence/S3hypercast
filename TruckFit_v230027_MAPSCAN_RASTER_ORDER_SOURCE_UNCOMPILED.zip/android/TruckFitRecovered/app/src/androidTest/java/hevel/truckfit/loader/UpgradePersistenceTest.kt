package hevel.truckfit.loader

import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import hevel.truckfit.loader.skin.SkinRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class UpgradePersistenceTest {
    @Test fun permanentPackageAndPreferencesNamespaceAreStable() {
        val context=ApplicationProvider.getApplicationContext<android.content.Context>()
        assertEquals("hevel.truckfit.loader",context.packageName)
        val prefs=context.getSharedPreferences(SkinRepository.PREFS_NAME,android.content.Context.MODE_PRIVATE)
        prefs.edit().putString("upgrade_probe","keep-me").commit()
        assertEquals("keep-me",context.getSharedPreferences(SkinRepository.PREFS_NAME,0).getString("upgrade_probe",null))
        assertTrue(SkinRepository.PREFS_NAME.contains("recovered"))
    }
}
