package hevel.truckfit.loader

import androidx.test.ext.junit.runners.AndroidJUnit4
import hevel.truckfit.loader.recovery.RecoveryActivity
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class RecoveryFlowTest {
    @Test fun rootFolderFallbackUsesSingleTreePicker() {
        assertEquals("android.intent.action.OPEN_DOCUMENT_TREE", RecoveryActivity.rootTreeIntent().action)
    }
}
