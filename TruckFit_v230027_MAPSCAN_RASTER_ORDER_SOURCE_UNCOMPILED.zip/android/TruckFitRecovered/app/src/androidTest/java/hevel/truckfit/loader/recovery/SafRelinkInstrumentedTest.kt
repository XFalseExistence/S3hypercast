package hevel.truckfit.loader.recovery

import android.content.Intent
import org.junit.Assert.assertEquals
import org.junit.Test

class SafRelinkInstrumentedTest {
    @Test fun oneTreePickerIsTheRecoveryFallback() {
        assertEquals(Intent.ACTION_OPEN_DOCUMENT_TREE, Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).action)
    }
}
