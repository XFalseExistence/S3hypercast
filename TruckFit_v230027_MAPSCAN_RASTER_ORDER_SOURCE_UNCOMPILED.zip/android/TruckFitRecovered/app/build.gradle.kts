plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.serialization")
}

android {
    namespace = "hevel.truckfit.loader"
    compileSdk = 36

    defaultConfig {
        applicationId = "hevel.truckfit.loader"
        minSdk = 26
        targetSdk = 36
        versionCode = 230025
        versionName = "23.0.25-auto-trim-center"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    val requestedRelease = gradle.startParameter.taskNames.any { it.contains("Release", ignoreCase = true) }
    val releaseStoreFile = providers.environmentVariable("TRUCKFIT_KEYSTORE_PATH").orNull
    val releaseStorePassword = providers.environmentVariable("TRUCKFIT_KEYSTORE_PASSWORD").orNull
    val releaseKeyAlias = providers.environmentVariable("TRUCKFIT_KEY_ALIAS").orNull
    val releaseKeyPassword = providers.environmentVariable("TRUCKFIT_KEY_PASSWORD").orNull
    if (requestedRelease && (releaseStoreFile == null || releaseStorePassword == null || releaseKeyAlias == null || releaseKeyPassword == null)) {
        throw GradleException("Permanent TruckFit signing variables are required for release builds")
    }
    if (releaseStoreFile != null && releaseStorePassword != null && releaseKeyAlias != null && releaseKeyPassword != null) {
        signingConfigs.create("release") {
            storeFile = file(releaseStoreFile)
            storePassword = releaseStorePassword
            keyAlias = releaseKeyAlias
            keyPassword = releaseKeyPassword
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.findByName("release")
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { viewBinding = true; buildConfig = true }
    testOptions { unitTests.isReturnDefaultValues = true }
}

dependencies {
    implementation("androidx.core:core-ktx:1.17.0")
    implementation("androidx.appcompat:appcompat:1.7.1")
    implementation("androidx.activity:activity-ktx:1.10.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.9.2")
    implementation("androidx.documentfile:documentfile:1.1.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.2")
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.9.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")

    testImplementation("junit:junit:4.13.2")
    testImplementation("org.jetbrains.kotlinx:kotlinx-coroutines-test:1.10.2")
    testImplementation("com.squareup.okhttp3:mockwebserver:4.12.0")

    androidTestImplementation("androidx.test:core:1.6.1")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.6.1")
}
