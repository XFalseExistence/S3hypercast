# SDD ledger — plan: docs/superpowers/plans/2026-09-19-hevel-skin-alt-android-app.md
Task 1: complete — core hierarchy contract passed; commit 53ac476
Task 2: complete — repository hierarchy contract passed; commit 7eb15e3
Task 3: complete — nested UI/repository/core contracts passed; commit da38c2b
Task 4: Ruling: current running S3_v0001.7 firmware parses only schema-1 lzr/skn index and keys all assets by `skin`; posting schema-2 index or reusing one parent ID for Base+ALT would overwrite assets or break cycling. Keep local library schema 2, but use unique wire IDs for ALT installs and post a schema-1-compatible remote index with additive hierarchy metadata. This preserves current firmware while allowing future ALT firmware to consume the hierarchy. Cost if wrong: future firmware must continue recognizing the synthetic wire-ID convention.
