from pathlib import Path
root = Path(__file__).resolve().parent.parent
api = (root/'app/src/main/java/hevel/skin/HevelApiClient.kt').read_text()
main = (root/'app/src/main/java/hevel/skin/MainActivity.kt').read_text()
transfer = (root/'app/src/main/java/hevel/skin/SkinTransfer.kt').read_text()
gradle = (root/'app/build.gradle.kts').read_text()
readme = (root/'README.md').read_text()
workflow_path = root/'.github/workflows/S3_v0001.9.yml'
workflow = workflow_path.read_text() if workflow_path.exists() else ''
checks = {
  'raw upload fixed length': 'setFixedLengthStreamingMode(bytes.size)' in api,
  'raw upload no multipart': 'multipart/form-data' not in api,
  'raw upload direct bytes': 'out.write(bytes)' in api,
  'all POST fixed length': 'setFixedLengthStreamingMode(payload.size)' in api,
  'manifest accepts variant': 'fun manifest(parentId: String, variant: SkinVariant)' in api,
  'post manifest accepts variant': 'fun postManifest(parentId: String, variant: SkinVariant' in api,
  'activate accepts variant': 'fun activate(parentId: String, variant: SkinVariant)' in api,
  'ALT activation uses LZR compatibility bank': 'if (variant.isBase) "SKN" else "LZR"' in api,
  'delete variant': 'fun deleteVariant(parentId: String, variant: SkinVariant)' in api,
  'clear variant slot': 'fun clearSlot(parentId: String, variant: SkinVariant, slot: SkinSlot)' in api,
  'upload variant': 'fun upload(parentId: String, variant: SkinVariant, slot: SkinSlot' in api,
  'default activation': 'fun activateDefault()' in api,
  'schema2 manifest': 'put("schema", 2)' in transfer or 'put("schema",2)' in transfer,
  'manifest parent': 'put("parentId", parent.id)' in transfer,
  'manifest variant': 'put("variant", if (variant.isBase) "BASE" else "ALT")' in transfer,
  'manifest alt id': 'put("altId"' in transfer,
  'shared wifi releases hotspot': 'releaseHotspotBinding()' in main and 'bindProcessToNetwork(null)' in main,
  'no mdns in app code': 'hevel-sub.local' not in main and 'hevel-sub.local' not in api,
  'shared wifi IP dialog': 'SHARED WIFI IP' in main,
  'version name 1.9': 'versionName = "S3_v0001.9"' in gradle,
  'version code 19': 'versionCode = 19' in gradle,
  'workflow 1.9 apk': 'S3_v0001.9.apk' in workflow,
}
failed = [k for k,v in checks.items() if not v]
if failed:
  raise SystemExit('FAIL: ' + ', '.join(failed))
print('S3_v0001.9 hierarchy compatibility contract PASS')
