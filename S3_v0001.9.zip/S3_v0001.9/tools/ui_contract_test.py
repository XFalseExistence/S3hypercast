from pathlib import Path
root = Path(__file__).resolve().parent.parent
main = (root/'app/src/main/java/hevel/skin/MainActivity.kt').read_text()
editor = (root/'app/src/main/java/hevel/skin/SkinEditorActivity.kt').read_text()
checks = {
    'create parent': 'CREATE SKN' in main,
    'add alt': 'ADD ALT' in main,
    'no LZR bank': 'LZR BANK' not in main and 'SkinBank' not in main,
    'nested render': 'renderAltCard' in main,
    'move alt': 'MOVE ALT' in main,
    'load parent': 'LOAD SKN' in main,
    'load alt': 'LOAD ALT' in main,
    'load all': 'LOAD ALL SKINS' in main,
    'selected variant keys': 'selectedVariants' in main,
    'base editor parent': 'parent_id' in editor,
    'base editor variant': 'variant_id' in editor,
    'editor updates variant': 'updateVariant' in editor,
}
failed = [k for k,v in checks.items() if not v]
if failed:
    raise SystemExit('FAIL: ' + ', '.join(failed))
print('Nested SKN ALT UI contract PASS')
