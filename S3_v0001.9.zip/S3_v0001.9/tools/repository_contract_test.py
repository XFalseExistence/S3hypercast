from pathlib import Path
repo = (Path(__file__).resolve().parent.parent/'app/src/main/java/hevel/skin/SkinRepository.kt').read_text()
checks = {
    'schema2': 'put("schema",2)' in repo or 'put("schema", 2)' in repo,
    'parents': '"parents"' in repo,
    'createParent': 'fun createParent(' in repo,
    'createAlt': 'fun createAlt(' in repo,
    'moveAlt': 'fun moveAlt(' in repo,
    'deleteParent': 'fun deleteParent(' in repo,
    'deleteAlt': 'fun deleteAlt(' in repo,
    'reorderParent': 'fun reorderParent(' in repo,
    'reorderAlt': 'fun reorderAlt(' in repo,
    'schema1 migration': 'optInt("schema", 1)' in repo,
    'old packs migration': 'prefs.getString("packs"' in repo,
    'remembered ALT': 'rememberedAltId' in repo,
    'remote compatibility index': 'hierarchySchema' in repo and 'val lzr = JSONArray()' in repo,
    'ALT wire IDs staged in LZR': 'lzr.put(HevelApi.wireId(parent.id, alt))' in repo,
}
failed = [k for k,v in checks.items() if not v]
if failed:
    raise SystemExit('FAIL: ' + ', '.join(failed))
print('SkinRepository hierarchy contract PASS')
