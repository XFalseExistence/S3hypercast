package hevel.skin

fun main() {
    check(SkinSlot.entries.map { it.wireName } == listOf("3D_TOP","2D_TOP","3D_TACT","2D_TACT","3D_REAR","2D_REAR"))

    val turtle = SkinParent.new("Turtle", 0)
    check(turtle.base.isBase)
    check(turtle.alts.isEmpty())
    check(turtle.name == "Turtle")

    val laser = SkinVariant.newAlt("Laser", 0)
    val withLaser = turtle.copy(alts = listOf(laser), rememberedAltId = laser.id)
    check(withLaser.activeVariant(laser.id).name == "Laser")
    check(withLaser.activeVariant("missing").isBase)

    val renamed = laser.rename("Night")
    check(renamed.id == laser.id)
    check(renamed.name == "Night")

    val slotted = laser.withSlot(SkinSlot.THREE_D_TOP, "content://laser-top")
    check(slotted.slotUris[SkinSlot.THREE_D_TOP] == "content://laser-top")
    check(slotted.withSlot(SkinSlot.THREE_D_TOP, null).slotUris.isEmpty())

    check(HevelApi.uploadPath(turtle.id, laser, SkinSlot.THREE_D_TOP, "render").contains("variant=ALT"))
    check(HevelApi.uploadPath(turtle.id, laser, SkinSlot.THREE_D_TOP, "render").contains("alt=${laser.id}"))
    check(HevelApi.uploadPath(turtle.id, turtle.base, SkinSlot.THREE_D_TOP, "render").contains("variant=BASE"))
    check(!HevelApi.uploadPath(turtle.id, turtle.base, SkinSlot.THREE_D_TOP, "render").contains("alt="))
    check(HevelApi.wireId(turtle.id, turtle.base) == turtle.id)
    check(HevelApi.wireId(turtle.id, laser) != turtle.id)
    check(HevelApi.uploadPath(turtle.id, laser, SkinSlot.THREE_D_TOP, "render").contains("skin=${HevelApi.wireId(turtle.id, laser)}"))

    val px = intArrayOf(
        0x00000000, 0x00000000, 0x00000000,
        0x00000000, 0xFFFF0000.toInt(), 0x00000000,
        0x00000000, 0x00000000, 0x00000000
    )
    val out = Rgb565aEncoder.encodeTrimmed(3, 3, px)
    check(out.width == 1 && out.height == 1)
    check(out.bytes.copyOfRange(0,4).decodeToString() == "HSK1")
    check(out.bytes.size == 19)

    val local = mapOf("3D_TOP" to "aaa", "2D_TOP" to "bbb")
    val remote = mapOf("3D_TOP" to "aaa")
    check(SyncPlanner.changedSlots(local, remote) == listOf("2D_TOP"))

    println("HevelSkinLoader core contract PASS")
}
